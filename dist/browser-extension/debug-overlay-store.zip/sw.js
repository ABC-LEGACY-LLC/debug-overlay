// Debug Overlay service worker — the store build.
// No fetch door: a store install is updated by the store.
// the toolbar button opens the side panel (declared, so it needs no handler);
// guarded because browsers without a side panel still run everything else
chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
