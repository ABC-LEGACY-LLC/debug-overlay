/* Debug Overlay v3.8.197 — the extension gate */

/*
HOW TO USE
  ----------
  Alt+Shift+D ......... power on/off (or click ⏻ on the panel)
  Hover ............... live badge for the element under the cursor
  Click ............... SELECT one element (orange, dashed). Its badge freezes
                        in place. No measuring, no green line. With 📌 pin
                        armed (the default) the selection is KEPT — numbered,
                        listed, reported; with 📌 off, the next click simply
                        replaces it and the page never accumulates anything.
  Shift+Click ......... PAIR (lime, solid): a selection pin. These group in
                        PAIRS: the 1st is "from" (cyan, marked 1…), the 2nd is
                        "to" — and whatever measures (📐) draws the dimension
                        between them. The 3rd starts a brand new pair — nothing
                        is ever chained off your previous selection unless you
                        say so, which is the next gesture:
  Ctrl+Shift+Click .... LINK (violet, solid): chain THIS to the previous pin.
                        Repeat it and a chain emerges — ①─②─③ — for reading a
                        rhythm (row gaps, list spacing) off one screenshot.
                        A technique is a GESTURE, not a mode: pairs and chains
                        mix freely in one session, so there is nothing to set
                        in advance and nothing to forget to set back.
  Drag ................ with ▭ lasso armed, press on the page and drag: a box
                        follows the pointer and everything it takes is pinned
                        at once on release. Set it to TOUCHED and the box need
                        not enclose anything — one pixel of overlap takes an
                        element, which is the only way to reach something
                        bigger than the drag. This reaches what a click cannot —
                        an element behind pointer-events: none, or one whose
                        painted shape the pointer misses — because a box asks
                        where things ARE rather than what is under a point.
                        Below a few pixels of movement no box is started, so a
                        press that wobbled is still an ordinary click.
  Click again ......... unpin (or click with another modifier to switch the
                        pin between note, pair and link)
  Hold X .............. REMOVE mode: a red ✕ appears on every pin and only pins
                        are clickable — click one to delete it. Works even for
                        pins whose element is hard to hit again. Release to exit.
  Right-click ......... the TARGET's menu: Copy selector / Copy text. Copy is
                        a take-away action like ⧉, so there is nothing to arm
                        and no button — it always works. (There used to be a
                        ⌖ pick tool guarding this behind Ctrl+click; an on/off
                        switch for "copy" guards nothing.)
                        Alt+right-click keeps the page's own context menu.
  Ctrl+C (⌘+C) ........ copy the hovered target's selector — the universal
                        copy key doing the obvious thing. Free to take while
                        the overlay is on (it already owns the mouse, so no
                        page text can be selected); inside a ⚙ field copy
                        stays the field's.
  Hold Alt ............ pass clicks through to the page (links keep working)
  Esc ................. closes the top layer: an open panel first, then remove
                        mode, then pins and the selection. It never powers the
                        tool off — that is
                        the ⏻ button and Alt+Shift+D, both of which say so.
  🏷 ................... the badge's own controls, two levels: press it and
                        the two AXES slide out — ◫ VIEW and ◈ FACETS — and
                        pressing an axis reveals its members. View: ▬ compact
                        / ▤ full (remembered, where ≡ used to forget on
                        reload). Facets: ＝ current (always on — it IS the
                        badge), ⚠ issue marks on/off, → recommendations
                        on/off. Facets gate badge ink ONLY: the copied report
                        always carries everything, and ⌕ findings are
                        untouched.
  ⌕ ................... audit the WHOLE page — every active rule runs over every
                        visible element, and the button shows how many distinct
                        problems came back. Each mark on the page is LABELLED
                        with the rule that made it (grid-off ×4), because a
                        dashed box that never says what is wrong is half a
                        finding — and no tooltip can say it, the overlay's
                        drawing layer takes no pointer events at all. Repeats collapse: a nav of 40
                        identical links is one finding, not forty. The result
                        rides along in the next report you copy, and every
                        finding is outlined on the page by the tool that found
                        it — dashed for a failure, dotted for a review. Turn a
                        tool off and its outlines go; its findings stay.
  ⚙ ................... tool settings — every option any tool declares, in one
                        list. Changing one takes effect immediately and is
                        remembered per site; it also drops the last ⌕ result,
                        because those findings were judged under the old
                        setting and nothing on screen would say so. Press ⌕
                        again to re-audit.
  ⧉ ................... copy structured report → paste into Claude with a screenshot
  Count chip .......... sits right under 📌 — the keeper and its count are one
                        home, and the number rests in the bar where a flyout
                        would have hidden it.
                        Its header carries pin's own ✕ — clear ALL pins while
                        the audit's marks stay (the bar's ✕ takes both).
                        Click the pin count to open the pin list: every pin and
                        measured pair in one place, even ones scrolled off
                        screen. Click a row to scroll to it and flash it; click
                        its ✕ to remove (a pair row removes both). Click the
                        chip again to close it before taking a screenshot.
  ✕ ................... clear pins AND the audit's outlines. Those outlines used
                        to have no exit at all: the ⌕ flash expires after a
                        second, so the bar looked idle while the page stayed
                        covered. ⌕ now keeps a green ring while an audit is
                        showing.
  Panel ............... drag by ⋮⋮; snaps to nearest edge; while OFF it tucks
                        away after ~2s leaving a 10px peek. Position remembered.
  Refresh ............. THE SESSION SURVIVES IT. Power is remembered per
                        SITE (this one stays on; other sites stay off), and
                        pins come back by their selector, same numbers, same
                        kinds — resolved against the page that exists now. A
                        pin whose element is gone is dropped and the Pins
                        header says how many. Honest limit: a selector is an
                        address, and on a changed page it can name a
                        different element. With ⚡ armed the report also
                        gains "## load — this navigation": server, DOM
                        ready, first paint, and the long tasks that ran
                        before the overlay was even awake (buffered
                        observers reach back).

  POWER vs TOOLS
  --------------
  ⏻ is the master switch: it only decides whether the overlay is listening
  at all. WHAT gets measured is decided by the tools below it, each an
  independent toggle you can mix freely:

    📌 pin       keep what you select. SELECTION chooses — one element at a
                 time, replaced by the next click; PIN is what makes a choice
                 persist as a numbered pin. On by default, so clicks pin the
                 way they always did. Switch it off to browse a page one
                 badge at a time with nothing to clean up afterwards — and
                 pins you already made stay until ✕, because a toggle must
                 not destroy a prepared screenshot.
    ⬚ group     how pinned elements group up. The technique rides on the
                 gesture — Shift+click pairs, Ctrl+Shift+click chains — and
                 grouping lives here and not in measure, so a new way of
                 selecting is one new file and everything that measures
                 picks it up.
    ▭ lasso     drag a box; keep what it takes. Off by default — every click
                 on the page already means something, and a gesture that
                 reinterprets drags is not one to switch on for somebody who
                 did not ask for it. Right-click it for two settings, which
                 are two separate questions:
                   A box takes what it … ENCLOSED (the default) is the usual
                 reading of a marquee, and it cannot take anything bigger than
                 the drag — a full-width wallpaper is unreachable, because
                 enclosing it means dragging a box around it and it may be
                 larger than the screen. TOUCHED takes anything the box
                 overlaps at all, down to one pixel, so a large element is
                 taken by dragging INSIDE it.
                   …and keeps the … OUTERMOST (the default) is "the things in
                 this region, not every node inside them". DEEPEST is the
                 other end — nothing kept that has a match inside it. EVERY
                 prunes nothing.
                   TOUCHED + DEEPEST is the pairing for one big element: every
                 wrapper above it overlaps too, and deepest is what drops
                 them. Under TOUCHED, outermost returns one page wrapper —
                 true, and rarely what you meant.
    📏 geometry  the geometry family — one button; click it and its members
                 slide out sideways:
       📐 measure  sizes, radius, padding/margin, gap, font, and the distance
                 between whatever the selection tools have grouped. Right-click
                 it to choose which of those the badge shows — a full badge is
                 a lot of ink over a page you came to read one number off. The
                 copied report always carries everything, because there the
                 line you did not want costs nothing and the one you did costs
                 a round trip.
    ▦ grid       marks any number another tool prints that is off the
                 spacing step (⚠ — 2px by default, change it under ⚙). The
                 🏷 recommendations facet adds the fix after each mark:
                 p 7⚠ becomes p 7⚠→8. Off by default — a suggestion doubles
                 every marked number. In ⌕ it
                 judges AUTHORED spacing only — padding, margin, gap — never
                 width or height, which layout produces rather than anyone
                 choosing, and nothing above CONFIG.GRID_MAX, where
                 margin:auto lands.
    🎨 colour    the colour family — one button; click it and its members
                 slide out sideways:
       ⛏ paint     WHICH ELEMENT actually paints the pixel you are pointing
                 at. Inspect answers "the topmost element here", which is a
                 different question: on a rounded card the topmost element is
                 often the one NOT painting, because the point sits in the
                 box but outside the rounded shape — and the colour you see
                 belongs to whatever is behind. Armed, the probe follows the
                 pointer and HOLDS when you move onto the panel, so ⧉ reports
                 the pixel you meant. The report carries the whole stack, top
                 to bottom — each row with its RECT, because a short selector
                 is often not unique and size is what tells two of them
                 apart — marked painted / box only — not painted here /
                 clipped away by an ancestor's overflow, each with its
                 colour — and painting is three answers, not one word: a
                 visible colour is PAINTS, alpha 0 is transparent —
                 contributes nothing, and part-way is PAINTS · alpha 0.06.
                 The layer the colour actually comes from is marked
                 ← the colour you see, so a twelve-deep stack is not
                 arithmetic you have to do. Plus ::before and ::after and any
                 backdrop-filter: the layers no hit test can see, and the two
                 that decide a frosted panel's colour. A pseudo prints WHERE
                 it sits, because inset 0 is a wallpaper and bottom 0 ·
                 auto × 1px is an edge ring, and "may paint here" said the
                 same thing about both.

                 Four things it cannot model are named rather than folded
                 in silently: backdrop-filter, the element's own filter,
                 mix-blend-mode, and an ancestor's opacity (which fades a
                 whole subtree as ONE group). Each would make the composite
                 quietly wrong.

                 It also lists the elements whose BOX holds the pixel that
                 the browser's hit test skipped — marked [—]. Hit-testing
                 respects the painted shape, so a point inside a card's box
                 but outside its rounded corner is not a hit on that card:
                 it never reaches the stack, and you meet it as "that area
                 is not selectable". Each says why — outside the painted
                 shape with its corner and radius, pointer-events: none,
                 clipped by an ancestor, or visibility: hidden.

                 It also says what it could NOT see, because a walk that
                 stops quietly is a partial answer wearing a complete one:
                 our own overlay layers removed from the top, a stack that
                 stopped at a shadow host (at least that many — a closed root
                 cannot be detected), and any frame it could not cross. The
                 composite is arithmetic, so by default it is labelled a
                 CLAIM — nothing has verified it. Turn on "Sample the real
                 pixel" under ⚙ and ⧉ reads the ACTUAL screen pixel and
                 prints both side by side with ΔRGB: the SIZE of any
                 disagreement is the finding, since a couple of units is a
                 saturate and forty is a whole layer nobody accounted for.

                 That reads the screen, so it is gated — off until you say
                 otherwise, only on an explicit ⧉ (a hover never captures),
                 one pixel read and the image dropped in the same breath,
                 nothing stored and nothing sent, and the report says when a
                 capture was taken. The permission is activeTab: granted by
                 pressing the toolbar button, covering that one tab, and
                 expiring — not a standing claim on every site you visit.

                 OFF by default — armed, it listens to every pointer move.
       ◐ contrast  WCAG text contrast ratio, against AA or AAA (⚙)
    ⌨ a11y       the name, role and keyboard reach of what you point at —
                 COMPUTED off the rendered page, not read out of the source.
                 <button><svg/></button> looks finished on screen and has no
                 accessible name at all. OFF by default: it answers a question
                 you have to think to ask, and three more rows on every hover
                 is a lot for people who never asked it. Its rules run in ⌕
                 either way — focusable with no name, focusable inside
                 aria-hidden="true", <img> with no alt. Where the real
                 algorithm would look somewhere this cannot see, it says
                 "not determined" rather than guessing.
    ⌗ dupid      the same id used more than once — a page-wide question
    ⚡ perf       freezes and jank, WHILE ARMED — the first tool with a
                 runtime. Arm it and a monitor starts: every badge gains the
                 page's pulse (⚡ 58fps · 2× worst 1.2s), the pin list logs
                 each main-thread freeze, and the report grows a
                 ## performance section that names its measuring tier —
                 frame attribution (Chrome names the script that ate the
                 frame), long tasks, or the everywhere-fallback heartbeat.
                 And the TARGETED half: PIN a component (or just select
                 it) and perf watches that subtree — its badge stops showing
                 the page and starts showing ITS cost: mut 140/s (DOM
                 mutations under it — a re-render loop reads in the
                 hundreds), resp 380ms (its slowest answered input), shift
                 0.02 (layout shift it caused). Past the churn threshold it
                 is a ⌕ finding on that element, and a freeze that happens
                 while a watched subtree churns is blamed in the log:
                 "during the 1.2s block: #cards ×412 mutations" — the
                 honest attribution, since per-element CPU%% does not exist
                 in the platform and this tool does not pretend otherwise.
                 OFF by default for cost, not caution: observers run only
                 on watched subtrees, only while armed, and a meter you did
                 not ask for is overhead pretending to be help. Freeze and
                 churn thresholds under ⚙.

  Every tool fills one or more of four ROLES, derived from the hooks it
  implements and shown in its tooltip: Select (what you are looking at),
  Inspect (what is shown about it), Detect (what counts as a problem), Act
  (what the overlay does to the page or the clipboard). A tool declares none
  of this — grid says "Inspect · Detect" because it annotates AND audits. The
  ⚙ list is grouped the same way: by what a setting CHANGES, not by which tool
  happens to own it.

  A tool's settings have two doors into the same room. ⚙ lists every one of
  them grouped by what it CHANGES; RIGHT-CLICK a tool's button for just that
  tool's, without everyone else's. The second is a filter of the first — the
  same options() call, the same control, the same value — so nothing can be set
  in one place and stale in the other. Neither is a menu a tool built for
  itself: a tool added tomorrow is configurable through both the moment it
  appears, with nothing installed or wired up.

  AI SESSION — a third door into the same room. An AI (Claude Code, or any
  MCP client) can drive the overlay itself instead of asking you to click
  and paste: arm tools, change settings, pin by selector, click, drag and
  point as a hand would, run ⌕, and read the report ⧉ would copy — as text,
  over a socket, with nobody relaying. Start the server beside the AI
  (`node mcp/` in the repo; mcp/README.md has the Claude Code line), then in
  the SIDE PANEL, under "AI session", enter the address and token it prints
  and press Connect. One server holds one token and accepts one browser, so
  a session is one process, one token, one browser — a second AI gets a
  second server on a second port, and nothing is shared for a session to
  cross into. The extension connects OUT, only when you press Connect, and
  only to the address you typed; nothing connects in. The AI sees this tab
  through the overlay's own answers and nothing else — no screenshots, no
  other tabs. Keep the side panel open while a session runs: the browser
  may stop the extension's worker, and the panel is what remembers.

  The rules between the buttons mark the PIPELINE, top to bottom: the input
  side (⬚ group, ▭ lasso, 📌 pin — what your input becomes), then the components
  (what describes the page), then ⌕ and ⚙, then the copy/clear band — the pin
  count sits up with 📌, whose home it is. A
  green dot on a tool means its rule feeds ⌕. Arming decides what you SEE;
  ⌕ checks every rule either way, so a toggle you forgot can never quietly
  shorten an audit.

  Active tools, panel position and everything under ⚙ are remembered for the
  SCRIPT, not for the site — set them once and every other site already agrees,
  and they follow the extension rather than the site you are on.

  ICONS — one set, Lucide (lucide.dev, ISC licence), inlined as SVG so the
  single-file build stays self-contained. Every tool declares its own icon
  as a literal beside its id, which is what the audit counts; the glyphs in
  this text (📌 ⬚ ▦ 🎨 ⌕ ⚙ …) are shorthand names for those buttons.

  ARCHITECTURE — real ES modules, one folder per component, bundled by
  esbuild into this single file. Execution order is the import graph, and a
  new capability is one new folder that nothing else has to name.

    banner.js          the guard, injected by the build around the bundle
    boot.js            entry: init order and wiring
    tools/<n>/         ⭐ one folder per armable tool — index registers, the
                       hook files sit beside it, service.js is its backend
    services/          badge, findings, report, settings — the collectors
    subjects/          a backend shared by two tools — geometry.js
    core/              config, state+Store, utils, geometry, registry
    ui/                styles, dom, controls, list, panel, placement, renderer
    app/               interactions, controller

  RULES that keep it from turning to mush:
    · UTILS is pure. It never reads State and never asks "is tool X on?" —
      callers hand in a decorator (see U.mark(n, dec)).
    · No tool names another tool. A "lens" (grid) decorates the numbers other
      tools print, reached through Tools.annotator() — never by id.
    · Tool-specific behaviour lives in that tool, never in RENDERER. If the
      renderer needs to know something, the tool exposes a hook and the
      renderer asks every active tool (see pendingIndex).
    · PANEL never touches State. It fires callbacks; CONTROLLER handles them.
    · MEASURE knows nothing about tools, panels or reports — only rectangles.
    · CONTROLLER is the one place modules are wired together.

  ADDING A NEW DEBUG TOOL — one object in section 5, nothing else:

    {
      id: 'zindex',
      icon: '⧉', title: 'Stacking — z-index & position',
      startsOn: false,             // optional, armed on a fresh install?
      badge:   (i) => `<span class="debug-overlay-sp">z ${i.cs.zIndex}</span>`,  // optional
      compact: (i) => null,                                       // optional
      report:  (i) => [`  z-index: ${i.cs.zIndex}`],              // optional
      draw:    (ctx) => {},                                       // optional
      reportTail: () => [],        // optional, summary lines after all pins
      pendingIndex: () => -1,      // optional, pin still being chosen
      annotate: (html, n, i) => html,   // optional, decorate other tools' numbers
      audit: (i) => [{ el, verdict, severity, rule, message, key }],  // optional
      auditPage: (all) => [],  // optional, once per sweep with every element
      options: () => [{ key: 'depth', label: 'Stack depth',   // optional
                        def: CONFIG.DEPTH, values: [1, 2, 3],
                        affects: 'inspect' }],
      intercept: ({ type, ev, el }) => false,   // optional, act on a click
      rules: { 'my-rule': { help, why, docs } },   // optional, what a rule IS
    }

    Every option declares `affects` — 'select', 'inspect', 'detect' or 'act' —
    and the ⚙ view files the row under that heading. It is the ONE category in
    this codebase that is declared rather than derived: a tool's roles come
    from its hooks and cannot go stale, but no hook can tell you whether a knob
    is a detection threshold or a display preference. audit.js fails an option
    without one.

    options() is how a tool becomes adjustable without a rebuild. Each entry
    gets a row under ⚙; `def` is the shipped default and belongs in CONFIG, so
    that file still answers "what does a fresh install do" while the panel
    answers "what is this one doing now". Read the live value back with
    Tools.setting(this, 'depth') — `this`, never an id, like every other
    question the registry answers. Do not cache it: the user can change it
    between two frames. Three kinds of option:

      values: [1, 2, 3]                     a picker
      type: 'number', min, max, step        a threshold you type
      type: 'toggle'                        on or off

    intercept() is the only hook that ACTS on the page rather than describing
    it. Armed tools are offered each click before it becomes a pin; return true
    to say it was yours, and no pin lands underneath. Return false and nothing
    changed. Claim narrowly — a modifier, a shape of element — because a tool
    that swallows every click has taken the overlay away from everything else.

    Whatever a tool puts in `title`, `icon` or an option `label` is the only
    thing a user ever sees of it, and audit.js now fails a tool that omits the
    first two — a panel button reading "undefined" is not a control surface.

    A tool declares no type. Its hooks are what it is, and it may have any
    combination of them — grid decorates other tools' numbers AND audits.

    audit() has three answers, not two: the element passed (say nothing), it
    failed, or it could not be measured. The last one has to be said out loud,
    with a reason, or a page nobody could read reports clean.
      verdict  ∈ fail | review
      severity ∈ error | warn | info   (CONFIG.SEVERITY — the sort order)
      rule      a rule id, not a tool id; one tool may own several
      key       which findings collapse into one line. Without one they
                collapse by rule + message.

    audit(info) sees one element. auditPage(all) runs once at the end of a
    sweep with every visible element's info, for the questions a single
    element cannot answer — a duplicated id, a spacing scale nobody kept to,
    two things that only conflict with each other. It is only gathered when
    some tool implements the hook, so a page with no relational rule pays
    nothing for one.

    `rules` documents a rule as opposed to one instance of it. The message
    says "2.76:1"; help/why/docs say what the rule is and where to read more.
    The report gathers them into a "## rules" section at the end — once per
    rule, not once per finding, which made a real report unreadable.

  The panel button, persistence, badge composition and report inclusion are
  all derived from the registry automatically.
*/

(function () {
  'use strict';
/* NOT a module and NOT bundled: build.js injects this text at the very top
   of the output IIFE, so its early returns abort the whole overlay before a
   single module evaluates. It cannot be an import — imports hoist, so a guard
   inside a module would run after everything it was guarding. */
  /**
   * NOT `window.top !== window.self`. That comparison can be true in the TOP
   * frame wherever `window` is a wrapper rather than the page's own — which
   * would disable the overlay everywhere, silently, on every site. It was the
   * userscript manager's sandbox that made it true here; the rule outlived
   * that gate because the failure it prevents is silent and total, and
   * frameElement is simply the correct question: null at top level in every
   * context, so it cannot misfire in the one direction that matters. The
   * manifest keeps us out of sub-frames to begin with (content_scripts
   * defaults to the top frame), the way @noframes used to.
   */
  let framed = false;
  try { framed = !!window.frameElement; } catch { framed = true; }
  if (framed) return;

  /**
   * Ask the DOCUMENT first. A re-injection on soft navigation can arrive in a
   * fresh sandbox — a new `window`, the same page — and a window flag alone
   * would have missed that and built a second panel fighting the first for the
   * same hotkey. The flag stays as the cheap path and as what the tests read.
   */
  /* BOTH spellings, deliberately. During an update an OLD instance can be
     live in the page while a new build injects into a fresh sandbox — the
     flag is gone but the old root is not. Looking only for the new id would
     miss it and build a second panel fighting the first for the hotkey. The
     legacy names cost two comparisons and can be dropped once no install
     predates the rename. */
  if (document.getElementById('__debug-overlay-root')) return;
  if (document.getElementById('__dbgov-root')) return;
  if (window.__DEBUG_OVERLAY__ || window.__DBG_OVERLAY__) return;
  window.__DEBUG_OVERLAY__ = true;

(() => {
  // src/core/config.js
  var CONFIG = {
    // Substituted by build.js at bundle time. A bundle cannot read the
    // manifest that ships it, and an overlay that cannot say which version it
    // is makes a stale install look exactly like a current one — which is the
    // failure this project has already had once, from the other end.
    VERSION: "3.8.197",
    // Substituted like VERSION, from release.json: the MANIFEST the extension
    // publishes, which is the one file that moves with every release. It was
    // the userscript's meta header until that gate was withdrawn — and that
    // file is frozen now, so asking it would have meant "newest = 3.8.174"
    // for ever, with nothing reporting the mistake.
    VERSION_URL: "https://raw.githubusercontent.com/ABC-LEGACY-LLC/debug-overlay/main/dist/browser-extension/manifest.json",
    // Where a PERSON reads what to do, as opposed to where the worker fetches
    // bytes from. Not the same question, so not the same URL.
    REPO_URL: "https://github.com/ABC-LEGACY-LLC/debug-overlay",
    // daily automatic floor; the manual "check now" row ignores it
    UPDATE: { EVERY: 864e5, BOOT_DELAY: 4e3 },
    Z: 2147483647,
    // The step the "grid" tool checks against. 2, not 4, because that is what
    // the scale in front of us actually is: Tailwind's default spacing has
    // half-steps (0.5 = 2px, 1.5 = 6px, 2.5 = 10px) and a real page used them
    // 2,681 times. A rule has to check the scale a project HAS; making the
    // project match the rule is the wrong way round. Set it to 4 or 8 for a
    // project that keeps to whole steps.
    GRID: 2,
    // Above this, a margin or padding is layout arithmetic rather than a
    // spacing token. getComputedStyle resolves `margin: auto` to the pixels it
    // worked out — 1127px on a real page — and nothing distinguishes that from
    // a value somebody typed. Nobody types 1127px; nobody types past this.
    GRID_MAX: 96,
    PEEK: 10,
    // px of panel visible when tucked
    TUCK_DELAY: 2200,
    // ms idle before the panel tucks away
    EDGE_MARGIN: 8,
    BADGE_MARGIN: 6,
    POS_KEY: "__debug_overlay_pos",
    // PER-ORIGIN, unlike everything else in the store: "debugging THIS site"
    // is a session fact about one origin, where a grid step is a fact about
    // the project. Global power would pop the overlay onto every site the
    // browser visits. Pins add the PATH: a pin on /live-map is not a pin on
    // /settings.
    /* The overlay's own root element. It lives in the page's own body, so
       anything sweeping the DOM has to be able to tell our chrome from the
       page — the lasso pinned its own buttons otherwise. */
    ROOT_ID: "__debug-overlay-root",
    POWER_KEY: "__debug_overlay_on",
    /* Whether the WEB PANEL's bar shows while the SIDE PANEL is driving.
       Off by default — two controls claiming one state is what docking
       solved — but it is a choice, because a screenshot for an AI wants
       the bar IN the picture, and the side panel is not in the picture. */
    WEBPANEL_KEY: "__debug_overlay_webpanel",
    PINS_KEY: "__debug_overlay_pins",
    TOOLS_KEY: "__debug_overlay_tools",
    SETTINGS_KEY: "__debug_overlay_settings",
    // Which tool ids this install has already met. Without it a saved armed
    // set answers for tools that no longer exist and stays silent about ones
    // shipped since — so a new capability arrives switched off and invisible.
    SEEN_KEY: "__debug_overlay_seen",
    /* Whether the one-line "what do I do now" hint has been earned away. It
       clears on the first pin — the moment the user has demonstrably learned
       the gesture it teaches. */
    TAUGHT_KEY: "__debug_overlay_taught",
    FLASH_MS: 1200,
    // how long a button shows a transient message
    LIST_GAP: 10,
    // px between the bar and the popover it opens
    LIST_PAD: 6,
    // px the popover keeps from the viewport edge
    // No DEFAULT_TOOLS list here any more. It named tool ids in a core file,
    // so shipping a tool that should start armed meant editing this — the one
    // place "a new tool is one new file" was not literally true. A tool says
    // `startsOn: true` about itself instead, and nothing central has to know
    // the name of anything.
    // A pin's "kind" names the SELECTION the user made, never a consumer —
    // 'pair' used to be 'measure', which claimed one tool owned selection's
    // pins and leaked that id into a CSS class and the report text. Defined
    // once here so the input layer, controller and renderer share one word.
    //
    // pair and link replaced the 'Pin grouping' MODE. A technique is a
    // GESTURE, not a mode: Shift+click pairs, Ctrl/⌘+Shift+click chains to
    // the previous pin, and the two mix in one session — a mode switch made
    // the same finger do different things on different days, and two clicks
    // looked identical until the third betrayed which mode was on.
    PIN_KIND: { PLAIN: "note", SHIFT: "pair", CHAIN: "link" },
    // The perf monitor's thresholds. FREEZE_MS is what counts as "stuck" —
    // 250ms is where humans stop reading an interaction as instant; a user
    // tunes it per project through the tool's own options().
    // CHURN is mutations/second on a WATCHED subtree before it counts as a
    // re-render storm (a React loop reads in the hundreds); RATE_WINDOW is
    // how far back the rolling rate looks.
    // How long one slice of a page sweep may run before it yields. Under half
    // a frame, so a sweep never owns the frame it lands in — the pass is
    // allowed to take longer in total, and is not allowed to block input.
    SWEEP_SLICE: 8,
    // RESYNC is how often the perf tool re-derives what it watches even when
    // the list looks unchanged — an element can leave the page without the
    // list changing, and re-deriving is what disconnects its observer.
    PERF: {
      FREEZE_MS: 250,
      LOG_MAX: 30,
      FPS_WINDOW: 1e3,
      CHURN: 60,
      RATE_WINDOW: 2e3,
      RESYNC: 1e3
    },
    // The badge service's VIEW axis, in order. 'compact' leads because it is
    // the shipped default — a full badge is a lot of ink over a page you came
    // to read one number off. A third view is one new entry here plus its
    // rendering; the 🏷 flyout and the ⚙ row both derive from this list.
    BADGE_MODES: ["compact", "full"],
    /* How far the pointer must travel before a press counts as a DRAG rather
       than a click that wobbled. Below it no rectangle is ever started, so a
       lasso being armed costs single-click pinning nothing — which is the
       condition for adding a gesture to a surface where every click already
       means something. Four, because a hand on a trackpad moves one or two
       pixels between press and release without intending to. */
    LASSO_MIN: 4,
    PICK_FLASH: 700,
    // ms an element stays outlined after being picked
    LANE_SEP: 16,
    // px between parallel dimension lines
    HOTKEY: { alt: true, shift: true, ctrl: false, code: "KeyD" },
    REMOVE_KEY: "KeyX",
    // hold to reveal ✕ on pins and click one to remove
    // `level` is the default the panel starts on; `levels` is what it offers.
    // The two thresholds move together — a rule that checked AAA for body text
    // and AA for headings would be neither.
    CONTRAST: {
      largePx: 24,
      largeBoldPx: 18.66,
      level: "AA",
      levels: { AA: { normal: 4.5, large: 3 }, AAA: { normal: 7, large: 4.5 } }
    },
    // Findings vocabulary, shared by every 'rule' tool. The number is only a
    // rank, so a list of findings reads worst-first.
    SEVERITY: { error: 3, warn: 2, info: 1 },
    // Marks drawn per tool per frame. A page can return thousands of findings
    // and this runs at 60fps, so it is a ceiling on cost, not on truth — the
    // list and the report still carry every one of them.
    MARK_LIMIT: 200
  };

  // src/core/state.js
  var Store = {
    _ext: null,
    // Map cache over chrome.storage.local, or null
    _extApi: null,
    /**
     * chrome.storage is async-only and every reader here is sync, so the
     * extension gate loads EVERYTHING into a cache once, before boot, and
     * writes through after. Returns a promise ONLY on that backend — the dev
     * page and the suite boot synchronously, and the suite asserts against
     * the DOM in the same breath as eval, so the sync paths must stay sync.
     */
    init() {
      const ext = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
      if (!ext) return null;
      return new Promise((res) => {
        try {
          ext.get(null, (all) => {
            Store._ext = new Map(Object.entries(all || {}));
            Store._extApi = ext;
            try {
              chrome.storage.onChanged.addListener((changes, area) => {
                if (area !== "local" || !Store._ext) return;
                for (const k of Object.keys(changes)) {
                  const v = changes[k].newValue;
                  if (v === void 0) Store._ext.delete(k);
                  else Store._ext.set(k, v);
                }
              });
            } catch {
            }
            res();
          });
        } catch {
          res();
        }
      });
    },
    /**
     * The stored string for `key`, or null. Never throws.
     *
     * Two adoptions layer here and they are different questions. `_read`
     * answers "does a BETTER BACKEND already hold this?" (the per-origin
     * localStorage life, migrated forward). This wrapper answers "was this
     * saved under the OLD NAME?" — every key was `__dbgov_*` before the
     * rename, and a rename that resets everyone's settings is a rename that
     * should not have shipped. Read once under the legacy name, write it
     * forward, and the legacy copy is never consulted again; it is dead
     * weight, not a competing answer, which is why it can be left in place
     * (GM storage has no delete without another grant).
     */
    get(key) {
      const v = Store._read(key);
      if (v !== null && v !== void 0) return v;
      const was = Store._legacy(key);
      if (was === key) return null;
      const old = Store._legacyRead(was);
      if (old === null || old === void 0) return null;
      Store.set(key, old);
      return old;
    },
    /** The pre-rename spelling of a key, or the key itself. Keys are built
     *  with suffixes (`…_on:https://site`), so this is a prefix swap. */
    _legacy: (key) => String(key).replace("__debug_overlay_", "__dbgov_"),
    /**
     * Read a legacy key WITHOUT adopting it. Deliberately not `_read`: that
     * one migrates what it finds into the better backend under the SAME
     * name, which for a legacy name means writing junk (`__dbgov_tools`
     * into chrome.storage) and deleting the only source. Two tabs booting
     * at once then disagreed — the first migrated and erased, the second
     * found nothing and fell back to defaults. Leaving the old value where
     * it is makes every boot reach the same answer, and the new key wins on
     * every read after the first, so there is no second answer to be wrong.
     */
    _legacyRead(key) {
      try {
        if (Store._ext) {
          const v = Store._ext.get(key);
          if (v !== void 0 && v !== null) return String(v);
        }
        return localStorage.getItem(key);
      } catch {
        return null;
      }
    },
    _read(key) {
      try {
        if (Store._ext) {
          const v = Store._ext.get(key);
          if (v !== void 0 && v !== null) return String(v);
          const old = localStorage.getItem(key);
          if (old !== null) {
            Store._ext.set(key, old);
            try {
              Store._extApi.set({ [key]: old });
            } catch {
            }
            try {
              localStorage.removeItem(key);
            } catch {
            }
            return old;
          }
          return null;
        }
        return localStorage.getItem(key);
      } catch {
        return null;
      }
    },
    /** Persist `value` (a string). Storage being unavailable is not an error. */
    set(key, value) {
      try {
        if (Store._ext) {
          Store._ext.set(key, value);
          try {
            Store._extApi.set({ [key]: value });
          } catch {
          }
          return;
        }
        localStorage.setItem(key, value);
      } catch {
      }
    }
  };
  var State = {
    enabled: false,
    // master power
    // no `detail` flag any more: the badge VIEW is a value in settings —
    // State.settings.badge.view — chosen from CONFIG.BADGE_MODES and
    // persisted like everything else the user picks. The ≡ boolean it
    // replaced forgot itself on every reload.
    tools: /* @__PURE__ */ new Set(),
    // active tool ids — filled by CONTROLLER on boot
    // { toolId: { key: value } } for every option any tool declares. Filled
    // once on boot from the tools' own defaults, then overlaid with whatever
    // was saved, so the hot path is a lookup and never a hook call: grid asks
    // for its step once per number on a page with thousands of them.
    settings: {},
    pins: [],
    // [{ el, id, kind }] — kind ∈ CONFIG.PIN_KIND
    // The CURRENT selection — the element a click chose while nothing armed
    // was keeping selections. One at most: the next click replaces it. It is
    // NOT a pin (no number, never in the list); a pin is a selection some
    // armed tool KEPT, and this is the one nothing did.
    current: null,
    hoverEl: null,
    removeMode: false,
    // true while the remove key is held
    removeTarget: null,
    // pin object under the cursor in remove mode
    flashPins: null,
    // pins briefly highlighted after "reveal" from the list
    // Last whole-page sweep: { findings, rules, elements }, or null if none
    // has been run. It carries what RAN, not only what was found, because a
    // zero that means "nothing was checked" and a zero that means "nothing is
    // wrong" must not print the same sentence. Cleared on power off: the DOM
    // moves on, and a stale page audit is worse than no audit.
    sweep: null
  };

  // src/core/registry.js
  var ROLES = [
    {
      key: "select",
      label: "Select",
      note: "how what you click becomes what you are looking at",
      /* NOT listRows: a row in the panel's list is a service contribution —
               perf's freeze log proved it, when the old predicate filed a monitor
               under Select and sat it at the top of the bar.
      
               `selects` is here because the first three are all about what a CLICK
               becomes, and the lasso proved that is not the whole of selecting: it
               pins by a gesture of its own and changes what a click means not at
               all, so every one of them was false and a tool whose entire product
               is pins derived the role Act — off its `intercept`, which only
               suppresses the click its own drag caused. The panel then gave it the
               component shape over the comment promising a lasso the input shape,
               and filed its `affects: 'select'` option under a heading its own
               role contradicted. No hook could tell you this, which is what makes
               it a declaration rather than a repeat — the same reason `keeps` is
               one. */
      has: (t) => !!(t.groups || t.pendingIndex || t.keeps || t.selects)
    },
    {
      key: "inspect",
      label: "Inspect",
      note: "what gets shown about it",
      has: (t) => !!(t.badge || t.compact || t.annotate)
    },
    {
      key: "detect",
      label: "Detect",
      note: "what counts as a problem",
      has: (t) => !!(t.audit || t.auditPage)
    },
    {
      key: "act",
      label: "Act",
      note: "what the overlay does to the page or the clipboard",
      has: (t) => !!t.intercept
    }
  ];
  var role = (key) => ROLES.find((r) => r.key === key);
  var byRole = (a, b) => {
    const rank = (t) => {
      const i = ROLES.findIndex((r) => r.has(t));
      return i < 0 ? ROLES.length : i;
    };
    return rank(a) - rank(b) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  };
  var SUBJECTS = [];
  var defineSubject = (s) => {
    SUBJECTS.push(s);
    return s;
  };
  var TOOLS = [];
  var defineTool = (t) => {
    TOOLS.push(t);
    return t;
  };
  var SERVICES = [];
  var defineService = (s) => {
    SERVICES.push(s);
    return s;
  };
  var ordered = () => TOOLS.slice().sort(byRole);
  var Tools = {
    all: TOOLS,
    ordered,
    byId: (id) => TOOLS.find((t) => t.id === id),
    active: () => ordered().filter((t) => State.tools.has(t.id)),
    /**
     * Tools are asked what they can DO, never what they are. A `kind` field
     * used to answer this, and it could only ever repeat what the hooks
     * already said — audit.js checked it by grepping for the hook, which is
     * the tell. Worse, one label per tool forced roles to be exclusive, so
     * grid could decorate numbers or produce findings but not both, for no
     * reason beyond the shape of the label.
     *
     * `armed` matters for anything the user SEES and not for anything that
     * gets CHECKED, so the caller says which it wants.
     */
    withHook: (h, armed) => ordered().filter((t) => t[h] && (!armed || State.tools.has(t.id))),
    /**
     * The tools, split into runs for the panel to draw with a rule between
     * them. Two toggles that look identical and mean different things is the
     * problem here: arming one changes what the page audit finds and arming
     * the other does not, and nothing said so.
     *
     * The split lives here because this is the file that knows what a hook
     * is. The panel renders the runs it is handed and never learns what
     * separates them — a third run would need no panel change at all.
     */
    /**
     * The bar's bands, top to bottom, ARE the pipeline: the input side
     * (SOURCE · ACTION — what turns your clicks into something), then the
     * COMPONENTS (what describes the page). The old axis — "does it feed ⌕" —
     * used to be the separator's meaning, which filed measure between the two
     * input tools and said nothing the green dot was not already saying.
     * That fact still shows, per tool, through feedsAudit(); one mark per
     * fact, and the separator is free to mean position in the pipeline.
     *
     * Derived at build like everything else, so a tool that changes species
     * moves band at next boot — being wrong costs an ordering, never a
     * verdict.
     */
    runs() {
      const input = (t) => role("select").has(t) || role("act").has(t);
      const inOrder = ordered();
      const comps = inOrder.filter((t) => !input(t));
      const clump = (list) => {
        const out = [];
        const seen = /* @__PURE__ */ new Set();
        for (const t of list) {
          if (!t.family) {
            out.push(t);
            continue;
          }
          if (seen.has(t.family)) continue;
          seen.add(t.family);
          out.push(...list.filter((x) => x.family === t.family));
        }
        return out;
      };
      return [
        { name: "Choose what to inspect", tools: clump(inOrder.filter(input)) },
        // plain read-outs first, then the dotted ones — inside the band the
        // dot still deserves the eye-track it always had
        {
          name: "Describe what you chose",
          tools: clump([
            ...comps.filter((t) => !role("detect").has(t)),
            ...comps.filter((t) => role("detect").has(t))
          ])
        }
      ].filter((r) => r.tools.length);
    },
    /** Does this tool's rule run in the page audit? The green dot, and the
     *  tooltip note — per tool, where the fact lives. */
    feedsAudit: (t) => role("detect").has(t),
    /**
     * The family's MARK — the subject wearing the family's id. A family earns
     * a bar presence of its own only when its head exists to carry the mark;
     * geometry has no subject (its backend is core), so measure stays a direct
     * button until that day.
     */
    familyMark: (name) => SUBJECTS.find((su) => su.id === name)?.icon || null,
    /**
     * What one of a tool's own options is currently set to.
     *
     * A tool asks with `this`, never with an id, so this stays as id-free as
     * every other question the registry answers. CONTROLLER has already
     * resolved defaults into State.settings by the time anything calls this —
     * deliberately, because the callers are hot: grid asks per number, and
     * re-deriving the answer from options() there would run the hook thousands
     * of times per sweep to be told the same thing.
     */
    /**
     * What one of an owner's own options is currently set to. The owner is a
     * tool or a subject — anything with an id that declared the option. Asked
     * with `this`, never with an id, so this stays as id-free as every other
     * question the registry answers.
     */
    setting: (t, key) => State.settings[t.id]?.[key],
    /**
     * Everything that declares settings, subjects first.
     *
     * Subjects lead because a setting that governs a shared measurement is the
     * more general fact: "the spacing step is 2px" is true of the project, and
     * what any one component does with it comes after.
     */
    /**
     * Everything that declares settings, in ONE principled order: the bar's.
     *
     * It used to be [...SUBJECTS, ...tools] — and SUBJECTS register in folder
     * order, which is alphabetical, so "WCAG level" sat above "Grid step" only
     * because contrast/ sorts before grid/. It matched the bar by luck.
     * Now each subject is anchored to the FIRST tool (in bar order) that
     * declares it via `uses:`, just ahead of that tool — the project's facts,
     * then the tool's own preferences — and an orphan subject, if one ever
     * exists, comes last rather than vanishing.
     */
    settingOwners: () => {
      const out = [];
      const seen = /* @__PURE__ */ new Set();
      for (const t of TOOLS.slice().sort(byRole)) {
        for (const su of t.uses || []) {
          if (!seen.has(su)) {
            seen.add(su);
            out.push(su);
          }
        }
        out.push(t);
      }
      for (const su of SUBJECTS) if (!seen.has(su)) out.push(su);
      for (const sv of SERVICES) out.push(sv);
      return out.filter((o) => o.options);
    },
    /** Every role a tool fills, in ROLES order. Plural by construction. */
    rolesOf: (t) => ROLES.filter((r) => r.has(t)).map((r) => r.label),
    /**
     * Every grouping the armed selection tools have formed.
     *
     * WHY THIS EXISTS: measure used to pair pins itself, which made it a
     * read-out AND the thing that decides what is selected — two roles in one
     * tool, and no way to add a second way of selecting without editing it.
     * Anything that draws or reports BETWEEN elements asks this instead, so a
     * lasso or a select-by-query reaches every consumer the day it lands and
     * no consumer ever learns who made the group.
     */
    groups() {
      const out = [];
      for (const t of Tools.withHook("groups", true))
        out.push(...t.groups.call(t) || []);
      return out;
    },
    /**
     * WHY THIS EXISTS: measure used to ask whether one specific NAMED tool was
     * switched on before it printed a padding, which made this file's claim
     * that tools are independent a lie. It asks this instead — "how does a
     * number want decorating here?" — and neither side learns the other's id,
     * because the only thing that knows both of them is the registry.
     *
     * Returns null when no lens is on, which is what keeps undecorated output
     * byte-for-byte what it was. Lenses fold in registry order (= filename
     * order), each one wrapping the previous one's html.
     */
    annotator(info) {
      if (info.facets && info.facets.issues === false) return null;
      const lenses = Tools.withHook("annotate", true);
      if (!lenses.length) return null;
      return (n) => lenses.reduce(
        (html, t) => t.annotate?.call(t, html, n, info) || html,
        `${n}`
      );
    }
  };

  // src/subjects/colour.js
  var Colour = defineSubject({
    id: "colour",
    was: "contrast",
    // its settings lived under this id before the subject existed
    // the FAMILY's mark, not contrast's — ◐ is the read-out's glyph, and the
    // "WCAG level" row wearing it made the subject look like one of its tools
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z" /><circle cx="13.5" cy="6.5" r=".5" fill="currentColor" /><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" /><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" /><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" /></svg>',
    // lucide 'palette' (ISC) — the colour family's mark
    /**
     * AA is the level nearly everyone is held to; AAA is what accessibility
     * commitments and public-sector procurement actually ask for. Both
     * thresholds move together — a check wanting AAA of body text and AA of
     * headings would be reporting against no standard at all.
     */
    options() {
      return [{
        key: "level",
        label: "WCAG level",
        def: CONFIG.CONTRAST.level,
        values: Object.keys(CONFIG.CONTRAST.levels),
        affects: "detect"
      }];
    },
    cache: /* @__PURE__ */ new Map(),
    // 20-50 distinct colours per page, 1000s of nodes
    ctx: void 0,
    // undefined = not tried yet, null = no canvas
    /** A 1×1 scratch context, or null where canvas is unavailable. */
    paint() {
      if (this.ctx !== void 0) return this.ctx;
      try {
        const c = document.createElement("canvas");
        c.width = c.height = 1;
        this.ctx = c.getContext("2d", { willReadFrequently: true }) || null;
      } catch {
        this.ctx = null;
      }
      return this.ctx;
    },
    /**
     * Any CSS colour → sRGB, by asking the browser to paint one pixel of it.
     * That covers oklch(), lab(), color(display-p3 …) and whatever ships
     * next, without this file knowing the maths for any of them.
     *
     * Guessing is what made this necessary: scraping the numbers out of
     * oklch(0.985 0 0) read near-white as near-black and reported 1.00:1
     * for text measuring 10.9:1. Anything still unreadable returns null,
     * and null must stay "unknown" all the way up.
     */
    colour(str) {
      const s = String(str || "");
      if (!s) return null;
      if (this.cache.has(s)) return this.cache.get(s);
      let out = null;
      const m = /^rgba?\(/.test(s) && s.match(/[\d.]+/g);
      if (m && m.length >= 3) {
        out = { r: +m[0], g: +m[1], b: +m[2], a: m[3] !== void 0 ? +m[3] : 1 };
      } else {
        const ctx = this.paint();
        if (ctx) {
          ctx.fillStyle = "#000";
          ctx.fillStyle = s;
          const a = ctx.fillStyle;
          ctx.fillStyle = "#fff";
          ctx.fillStyle = s;
          const b = ctx.fillStyle;
          if (a === b) {
            ctx.clearRect(0, 0, 1, 1);
            ctx.fillRect(0, 0, 1, 1);
            const d = ctx.getImageData(0, 0, 1, 1).data;
            out = { r: d[0], g: d[1], b: d[2], a: d[3] / 255 };
          }
        }
      }
      this.cache.set(s, out);
      return out;
    },
    /** Composite `over` (with alpha) onto the opaque colour `base`. */
    over(over, base2) {
      const a = over.a == null ? 1 : over.a;
      return {
        r: over.r * a + base2.r * (1 - a),
        g: over.g * a + base2.g * (1 - a),
        b: over.b * a + base2.b * (1 - a),
        a: 1
      };
    },
    /**
     * What the text is actually painted on, or `{ unknown }` naming what
     * stopped it — the caller turns that into a finding rather than silence.
     *
     * Starts at the element, not its parent: an element that sets its own
     * background paints it behind its own text, so every button, chip and
     * alert was previously scored against whatever was behind the card
     * instead. Translucent layers are collected and composited rather than
     * taken as if opaque — the first layer over 5% alpha used to be returned
     * outright, which is a different colour from what a reader sees.
     */
    bg(el2) {
      const layers = [];
      let e = el2;
      while (e && e.nodeType === 1) {
        const cs = getComputedStyle(e);
        if (cs.backgroundImage && cs.backgroundImage !== "none") return { unknown: "bg-image" };
        const raw = cs.backgroundColor;
        const c = this.colour(raw);
        if (!c) {
          if (raw && raw !== "transparent")
            return { unknown: this.paint() ? "bg-colour" : "no-canvas" };
        } else if (c.a >= 0.999) {
          return layers.reduceRight((base2, l) => this.over(l, base2), c);
        } else if (c.a > 0) layers.push(c);
        e = e.parentElement;
      }
      return layers.reduceRight(
        (base2, l) => this.over(l, base2),
        { r: 255, g: 255, b: 255, a: 1 }
      );
    },
    lum({ r, g, b }) {
      const f = (v) => {
        v /= 255;
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
      };
      return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
    },
    ratio(fg, bg) {
      const a = fg.a == null ? 1 : fg.a;
      const mixed = {
        r: fg.r * a + bg.r * (1 - a),
        g: fg.g * a + bg.g * (1 - a),
        b: fg.b * a + bg.b * (1 - a)
      };
      const l1 = this.lum(mixed), l2 = this.lum(bg);
      const hi = Math.max(l1, l2), lo = Math.min(l1, l2);
      return (hi + 0.05) / (lo + 0.05);
    },
    // Walked rather than spread: this is the first thing asked of every
    // element in a page sweep, and [...childNodes] allocates an array for
    // each one only to look at the first text node.
    ownText(el2) {
      for (let n = el2.firstChild; n; n = n.nextSibling)
        if (n.nodeType === 3 && n.nodeValue.trim()) return true;
      return false;
    },
    // Why a measurement could not be made. These reach the user, so they say
    // what happened rather than naming the branch that produced them.
    why: {
      "fg-colour": "the text colour is in a colour space this cannot read",
      "bg-colour": "the background colour is in a colour space this cannot read",
      "bg-image": "it sits on an image or gradient, so the pixel under the text is unknown",
      "no-canvas": "no canvas is available to resolve colours"
    },
    measure({ el: el2, cs }) {
      if (!this.ownText(el2)) return null;
      const fg = this.colour(cs.color);
      if (!fg) return { unknown: this.paint() ? "fg-colour" : "no-canvas" };
      const bg = this.bg(el2);
      if (bg.unknown) return bg;
      const faded = { ...fg, a: (fg.a == null ? 1 : fg.a) * this.opacityOf(el2) };
      const ratio = this.ratio(faded, bg);
      const size = parseFloat(cs.fontSize);
      const bold = parseInt(cs.fontWeight, 10) >= 700;
      const isLarge = size >= CONFIG.CONTRAST.largePx || bold && size >= CONFIG.CONTRAST.largeBoldPx;
      const level = Tools.setting(this, "level");
      const want = CONFIG.CONTRAST.levels[level];
      const need = isLarge ? want.large : want.normal;
      return { ratio, need, pass: ratio >= need, isLarge, fg: faded, bg, level, want };
    },
    /** Cumulative CSS opacity: every ancestor multiplies what is painted. */
    opacityOf(el2) {
      let o = 1;
      for (let e = el2; e && e.nodeType === 1; e = e.parentElement) {
        const v = parseFloat(getComputedStyle(e).opacity);
        if (Number.isFinite(v) && v < 1) o *= Math.max(0, v);
        if (o === 0) break;
      }
      return o;
    },
    rgb: (c) => `${Math.round(c.r)},${Math.round(c.g)},${Math.round(c.b)}`
  });

  // src/core/utils.js
  var U = {
    /**
     * Math.round breaks ties toward +Infinity, so +2.5 became 3 (off a 2px
     * grid) and -2.5 became -2 (on it) — the SIGN of a half-pixel decided the
     * verdict rather than its distance from the grid. Fractional computed
     * margins are ordinary on fractional-DPR displays. Half away from zero
     * treats a margin and its mirror image alike.
     */
    px: (v) => {
      const n = parseFloat(v) || 0;
      return Math.sign(n) * Math.round(Math.abs(n));
    },
    /**
     * Anything the PAGE controls has to come through here before it is
     * interpolated into badge markup, because badges reach the DOM through
     * innerHTML. An element's id is page-authored text, and a hostile — or
     * merely careless — one closed the span and opened a tag of its own.
     */
    esc: (s) => String(s).replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
    ),
    // `dec` is a decorator, (n) => html, handed in by the caller. UTILS never
    // reads State, and never learns what decorating a number means.
    mark: (n, dec) => dec ? dec(n) : `${n}`,
    four(cs, prop, dec) {
      const t = U.px(cs[prop + "Top"]), r = U.px(cs[prop + "Right"]), b = U.px(cs[prop + "Bottom"]), l = U.px(cs[prop + "Left"]);
      if (!t && !r && !b && !l) return null;
      if (t === b && r === l)
        return t === r ? [U.mark(t, dec)] : [U.mark(t, dec), U.mark(r, dec)];
      return [U.mark(t, dec), U.mark(r, dec), U.mark(b, dec), U.mark(l, dec)];
    },
    fourPlain(cs, prop) {
      return {
        t: U.px(cs[prop + "Top"]),
        r: U.px(cs[prop + "Right"]),
        b: U.px(cs[prop + "Bottom"]),
        l: U.px(cs[prop + "Left"])
      };
    },
    radius(cs) {
      const c = ["TopLeft", "TopRight", "BottomRight", "BottomLeft"].map((k) => U.px(cs["border" + k + "Radius"]));
      if (!c.some(Boolean)) return null;
      return c.every((v) => v === c[0]) ? `${c[0]}` : c.join("/");
    },
    /**
     * An id a person chose is the best address there is. A generated one is
     * the worst: React and base-ui emit things like `base-ui-:r1t9:`, which
     * changes on the next render, so a report that says #base-ui-:r1t9: names
     * an element nobody can find twice. A bare CSS identifier is the test —
     * a colon is not legal in one unescaped, so nobody typed it.
     */
    stableId: (id) => /^[A-Za-z][\w-]*$/.test(id),
    selectorOf(el2) {
      const part = (e2) => {
        if (e2.id && U.stableId(e2.id)) return "#" + e2.id;
        let s = e2.tagName.toLowerCase();
        const cls = [...e2.classList].filter((c) => !c.startsWith("debug-overlay-")).slice(0, 2);
        if (cls.length) s += "." + cls.join(".");
        if (e2.parentElement) {
          let idx = 1, more = false;
          for (let x = e2.previousElementSibling; x; x = x.previousElementSibling)
            if (x.tagName === e2.tagName) idx++;
          for (let x = e2.nextElementSibling; x && !more; x = x.nextElementSibling)
            if (x.tagName === e2.tagName) more = true;
          if (idx > 1 || more) s += `:nth-of-type(${idx})`;
        }
        return s;
      };
      const chain = [];
      let e = el2;
      while (e && e.tagName && chain.length < 3) {
        chain.unshift(part(e));
        if (e.id && U.stableId(e.id)) break;
        e = e.parentElement;
      }
      return chain.join(" > ");
    },
    // human-readable name for a pin row: the element's own text, else a selector
    labelOf(el2) {
      const t = (el2.innerText || el2.textContent || "").trim().replace(/\s+/g, " ");
      if (t) return t.length <= 34 ? t : t.slice(0, 31) + "…";
      const cls = [...el2.classList].filter((c) => !c.startsWith("debug-overlay-"))[0];
      return el2.tagName.toLowerCase() + (el2.id ? "#" + el2.id : cls ? "." + cls : "");
    },
    /**
     * `r` is a getter: a rule that only reads colours never pays for a
     * layout read, which over a whole page is thousands of them. `cs` can be
     * handed in by a caller that has already read it.
     */
    info(el2, cs) {
      let r = null;
      return {
        el: el2,
        cs: cs || getComputedStyle(el2),
        get r() {
          return r || (r = el2.getBoundingClientRect());
        }
      };
    },
    gap(a, b) {
      const dx = Math.max(a.left - b.right, b.left - a.right, 0);
      const dy = Math.max(a.top - b.bottom, b.top - a.bottom, 0);
      return { dx: Math.round(dx), dy: Math.round(dy), d: Math.round(Math.hypot(dx, dy)) };
    },
    rectOf: (x, y, w, h) => ({ l: x, t: y, r: x + w, b: y + h }),
    overlap: (a, b) => Math.max(0, Math.min(a.r, b.r) - Math.max(a.l, b.l)) * Math.max(0, Math.min(a.b, b.b) - Math.max(a.t, b.t))
  };

  // src/subjects/geometry.js
  var Measure = defineSubject({
    id: "geometry",
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z" /><path d="m14.5 12.5 2-2" /><path d="m11.5 9.5 2-2" /><path d="m8.5 6.5 2-2" /><path d="m17.5 15.5 2-2" /></svg>',
    // lucide 'ruler' (ISC) — the geometry family's mark
    // --- lanes: keep parallel dimension lines off each other -------------
    lanes: { v: [], h: [] },
    resetLanes() {
      Measure.lanes = { v: [], h: [] };
    },
    /**
     * Reserve a column (vertical span) or row (horizontal span) at `pos`.
     * If another span already occupies that position AND their spans overlap
     * along the measured axis, shift sideways in LANE_SEP steps until clear.
     * Returns the position actually granted.
     */
    reserveLane(vertical, pos, from, to) {
      const SEP = CONFIG.LANE_SEP;
      const list = vertical ? Measure.lanes.v : Measure.lanes.h;
      const lo = Math.min(from, to), hi = Math.max(from, to);
      const offsets = [0];
      for (let s = 1; s <= 10; s++) offsets.push(s * SEP, -s * SEP);
      for (const off of offsets) {
        const cand = pos + off;
        const clash = list.some((L) => Math.abs(L.pos - cand) < SEP - 1 && !(hi < L.lo - 2 || lo > L.hi + 2));
        if (!clash) {
          list.push({ pos: cand, lo, hi });
          return cand;
        }
      }
      list.push({ pos, lo, hi });
      return pos;
    },
    // Which axis does this gap actually live on?
    axisOf(ra, rb) {
      const xOv = Math.min(ra.right, rb.right) - Math.max(ra.left, rb.left);
      const yOv = Math.min(ra.bottom, rb.bottom) - Math.max(ra.top, rb.top);
      if (xOv > 0 && yOv > 0) return { kind: "overlap", label: "overlap", xOv, yOv };
      if (xOv > 0) return { kind: "vertical", label: "vertical gap", xOv, yOv };
      if (yOv > 0) return { kind: "horizontal", label: "horizontal gap", xOv, yOv };
      return { kind: "diagonal", label: "diagonal gap", xOv, yOv };
    },
    // one straight measured span: tick at the start, arrowhead at the target
    span(layer2, Place2, { x1, y1, x2, y2, text, vertical, endArrow = true }) {
      const len = vertical ? Math.abs(y2 - y1) : Math.abs(x2 - x1);
      const dir = vertical ? y2 >= y1 ? "down" : "up" : x2 >= x1 ? "right" : "left";
      const line = document.createElement("div");
      line.className = "debug-overlay-line";
      if (vertical) {
        Place2.put(line, Math.round(x1) - 1, Math.min(y1, y2), 2, Math.max(len, 1));
        Place2.claim(Math.round(x1) - 5, Math.min(y1, y2), 10, Math.max(len, 1));
      } else {
        Place2.put(line, Math.min(x1, x2), Math.round(y1) - 1, Math.max(len, 1), 2);
        Place2.claim(Math.min(x1, x2), Math.round(y1) - 5, Math.max(len, 1), 10);
      }
      layer2.append(line);
      const tick = document.createElement("div");
      tick.className = "debug-overlay-cap";
      if (vertical) Place2.put(tick, Math.round(x1) - 6, Math.round(y1) - 1, 12, 2);
      else Place2.put(tick, Math.round(x1) - 1, Math.round(y1) - 6, 2, 12);
      layer2.append(tick);
      if (endArrow) {
        const a = document.createElement("div");
        a.className = "debug-overlay-arrow debug-overlay-" + dir;
        const P = {
          up: [Math.round(x2) - 5, Math.round(y2)],
          down: [Math.round(x2) - 5, Math.round(y2) - 7],
          left: [Math.round(x2), Math.round(y2) - 5],
          right: [Math.round(x2) - 7, Math.round(y2) - 5]
        }[dir];
        Place2.put(a, P[0], P[1]);
        layer2.append(a);
      } else {
        const c = document.createElement("div");
        c.className = "debug-overlay-cap";
        if (vertical) Place2.put(c, Math.round(x2) - 6, Math.round(y2) - 1, 12, 2);
        else Place2.put(c, Math.round(x2) - 1, Math.round(y2) - 6, 2, 12);
        layer2.append(c);
      }
      const mx = vertical ? x1 + 12 : (x1 + x2) / 2;
      const my = vertical ? (y1 + y2) / 2 : y1 - 12;
      const lbl = document.createElement("div");
      lbl.className = "debug-overlay-dist" + (vertical ? " debug-overlay-vert" : "");
      lbl.textContent = text;
      layer2.append(lbl);
      Place2.smart(
        lbl,
        { left: mx, top: my, right: mx, bottom: my, width: 0, height: 0 },
        { leader: true }
      );
    },
    // thin dashed line extending an element's edge out to the measured span
    extension(layer2, Place2, { x1, y1, x2, y2 }) {
      if (Math.round(x1) === Math.round(x2) && Math.round(y1) === Math.round(y2)) return;
      const e = document.createElement("div");
      const horizontal = Math.abs(x2 - x1) >= Math.abs(y2 - y1);
      e.className = "debug-overlay-ext" + (horizontal ? "" : " debug-overlay-v");
      if (horizontal) Place2.put(e, Math.min(x1, x2), Math.round(y1), Math.abs(x2 - x1) || 1, 1);
      else Place2.put(e, Math.round(x1), Math.min(y1, y2), 1, Math.abs(y2 - y1) || 1);
      layer2.append(e);
    },
    // dashed guides running along each element's edge out to a shifted lane
    guideTo(layer2, Place2, rect, vertical, pos, edgeCoord) {
      if (vertical) {
        const clamped = Math.max(rect.left, Math.min(pos, rect.right));
        Measure.extension(layer2, Place2, { x1: clamped, y1: edgeCoord, x2: pos, y2: edgeCoord });
      } else {
        const clamped = Math.max(rect.top, Math.min(pos, rect.bottom));
        Measure.extension(layer2, Place2, { x1: edgeCoord, y1: clamped, x2: edgeCoord, y2: pos });
      }
    },
    dimension(layer2, Place2, ra, rb, tag) {
      const axis = Measure.axisOf(ra, rb);
      const g = U.gap(ra, rb);
      if (axis.kind === "overlap") {
        const lbl = document.createElement("div");
        lbl.className = "debug-overlay-dist";
        lbl.textContent = `${tag} · overlapping`;
        layer2.append(lbl);
        const mx = (Math.max(ra.left, rb.left) + Math.min(ra.right, rb.right)) / 2;
        const my = (Math.max(ra.top, rb.top) + Math.min(ra.bottom, rb.bottom)) / 2;
        Place2.smart(lbl, { left: mx, top: my, right: mx, bottom: my, width: 0, height: 0 });
        return;
      }
      if (axis.kind === "vertical") {
        const down2 = rb.top >= ra.bottom;
        const y1 = down2 ? ra.bottom : ra.top;
        const y2 = down2 ? rb.top : rb.bottom;
        const mid = (Math.max(ra.left, rb.left) + Math.min(ra.right, rb.right)) / 2;
        const x = Measure.reserveLane(true, mid, y1, y2);
        Measure.guideTo(layer2, Place2, ra, true, x, y1);
        Measure.guideTo(layer2, Place2, rb, true, x, y2);
        Measure.span(layer2, Place2, {
          x1: x,
          y1,
          x2: x,
          y2,
          vertical: true,
          text: `${tag} · ${down2 ? "↓" : "↑"} ${g.dy} px`
        });
        return;
      }
      if (axis.kind === "horizontal") {
        const right2 = rb.left >= ra.right;
        const x1 = right2 ? ra.right : ra.left;
        const x2 = right2 ? rb.left : rb.right;
        const mid = (Math.max(ra.top, rb.top) + Math.min(ra.bottom, rb.bottom)) / 2;
        const y = Measure.reserveLane(false, mid, x1, x2);
        Measure.guideTo(layer2, Place2, ra, false, y, x1);
        Measure.guideTo(layer2, Place2, rb, false, y, x2);
        Measure.span(layer2, Place2, {
          x1,
          y1: y,
          x2,
          y2: y,
          vertical: false,
          text: `${tag} · ${right2 ? "→" : "←"} ${g.dx} px`
        });
        return;
      }
      const right = rb.left >= ra.right;
      const down = rb.top >= ra.bottom;
      const hx1 = right ? ra.right : ra.left;
      const hx2 = right ? rb.left : rb.right;
      const hy = Measure.reserveLane(false, (ra.top + ra.bottom) / 2, hx1, hx2);
      const vy1 = down ? ra.bottom : ra.top;
      const vy2 = down ? rb.top : rb.bottom;
      const vx = Measure.reserveLane(true, right ? rb.left : rb.right, vy1, vy2);
      Measure.guideTo(layer2, Place2, ra, false, hy, hx1);
      Measure.guideTo(layer2, Place2, rb, false, hy, hx2);
      Measure.guideTo(layer2, Place2, ra, true, vx, vy1);
      Measure.guideTo(layer2, Place2, rb, true, vx, vy2);
      Measure.span(layer2, Place2, {
        x1: hx1,
        y1: hy,
        x2: hx2,
        y2: hy,
        vertical: false,
        text: `${tag} · ${right ? "→" : "←"} ${g.dx} px`
      });
      Measure.span(layer2, Place2, {
        x1: vx,
        y1: vy1,
        x2: vx,
        y2: vy2,
        vertical: true,
        text: `${tag} · ${down ? "↓" : "↑"} ${g.dy} px`
      });
    }
  });

  // src/tools/a11y/service.js
  function textOf(el2, depth = 0) {
    if (!el2 || depth > 6) return "";
    if (el2.getAttribute && el2.getAttribute("aria-hidden") === "true") return "";
    const own = el2.getAttribute && el2.getAttribute("aria-label");
    if (own && own.trim()) return own.trim();
    let out = "";
    for (const n of el2.childNodes) {
      if (n.nodeType === 3) out += n.nodeValue;
      else if (n.nodeType === 1) {
        if (n.tagName === "IMG") {
          out += " " + (n.getAttribute("alt") || "");
          continue;
        }
        if (n.tagName === "svg" || n.tagName === "SVG") {
          const ti = n.querySelector && n.querySelector("title");
          out += " " + (ti ? ti.textContent : "");
          continue;
        }
        out += " " + textOf(n, depth + 1);
      }
    }
    return out.replace(/\s+/g, " ").trim();
  }
  function labelFor(el2) {
    if (el2.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el2.id)}"]`);
      if (l) return textOf(l);
    }
    const wrap = el2.closest && el2.closest("label");
    return wrap ? textOf(wrap) : "";
  }
  var FIELD = /^(INPUT|SELECT|TEXTAREA|METER|PROGRESS|OUTPUT)$/;
  var FROM_CONTENT = /* @__PURE__ */ new Set([
    "button",
    "link",
    "heading",
    "option",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "tab",
    "treeitem",
    "cell",
    "columnheader",
    "rowheader",
    "gridcell",
    "switch",
    "checkbox",
    "radio",
    "tooltip",
    "legend"
  ]);
  var BY_TAG = {
    A: (el2) => el2.hasAttribute("href") ? "link" : "generic",
    AREA: (el2) => el2.hasAttribute("href") ? "link" : "generic",
    BUTTON: () => "button",
    IMG: (el2) => el2.getAttribute("alt") === "" ? "presentation" : "img",
    SELECT: (el2) => el2.multiple || el2.size > 1 ? "listbox" : "combobox",
    TEXTAREA: () => "textbox",
    NAV: () => "navigation",
    MAIN: () => "main",
    ASIDE: () => "complementary",
    FORM: () => "form",
    SEARCH: () => "search",
    DIALOG: () => "dialog",
    UL: () => "list",
    OL: () => "list",
    LI: () => "listitem",
    TABLE: () => "table",
    TR: () => "row",
    TD: () => "cell",
    TH: () => "columnheader",
    P: () => "paragraph",
    HR: () => "separator",
    PROGRESS: () => "progressbar",
    H1: () => "heading",
    H2: () => "heading",
    H3: () => "heading",
    H4: () => "heading",
    H5: () => "heading",
    H6: () => "heading",
    HEADER: (el2) => el2.closest("article, aside, main, nav, section") ? "generic" : "banner",
    FOOTER: (el2) => el2.closest("article, aside, main, nav, section") ? "generic" : "contentinfo",
    DIV: () => "generic",
    SPAN: () => "generic",
    INPUT: (el2) => ({
      button: "button",
      submit: "button",
      reset: "button",
      image: "button",
      checkbox: "checkbox",
      radio: "radio",
      range: "slider",
      number: "spinbutton",
      search: "searchbox",
      email: "textbox",
      tel: "textbox",
      text: "textbox",
      url: "textbox",
      password: null,
      hidden: null
    })[(el2.getAttribute("type") || "text").toLowerCase()] ?? "textbox"
  };
  var A11y = {
    /** The role the browser exposes: what was declared, or what the tag means. */
    role(el2) {
      const explicit = (el2.getAttribute("role") || "").trim().split(/\s+/)[0];
      if (explicit) return explicit.toLowerCase();
      const fn = BY_TAG[el2.tagName];
      return fn ? fn(el2) : null;
    },
    /**
     * Is it in the TAB ORDER — reachable by keyboard, not merely focusable by
     * script. `tabindex="-1"` is a deliberate "focus me from code only", which
     * is not a defect and must not be reported as one.
     */
    focusable(el2, cs) {
      if (el2.disabled || el2.hasAttribute("inert") || el2.closest("[inert]")) return false;
      if (cs && (cs.display === "none" || cs.visibility === "hidden")) return false;
      return typeof el2.tabIndex === "number" && el2.tabIndex >= 0;
    },
    /** True when an ancestor (or the element) is hidden from the tree. */
    hidden(el2) {
      return !!(el2.closest && el2.closest('[aria-hidden="true"]'));
    },
    /**
     * The accessible name, in the spec's order, stopping at the first source
     * that yields text. Returns `{ name, from, unsure }` — `unsure` is set
     * only when a source was ATTEMPTED and could not be read from here.
     */
    name(el2) {
      const lb = (el2.getAttribute("aria-labelledby") || "").trim();
      let tried = null;
      if (lb) {
        const ids = lb.split(/\s+/).filter(Boolean);
        const seen = ids.map((id) => document.getElementById(id)).filter(Boolean);
        const s = seen.map((n) => textOf(n)).join(" ").replace(/\s+/g, " ").trim();
        if (s) return { name: s, from: "aria-labelledby", unsure: null };
        if (!seen.length) tried = "labelledby";
      }
      const al = (el2.getAttribute("aria-label") || "").trim();
      if (al) return { name: al, from: "aria-label", unsure: null };
      if (el2.tagName === "IMG" || el2.tagName === "AREA" || el2.tagName === "INPUT" && (el2.getAttribute("type") || "").toLowerCase() === "image") {
        const alt = el2.getAttribute("alt");
        if (alt !== null) return { name: alt.trim(), from: "alt", unsure: null };
        return { name: "", from: null, unsure: null };
      }
      if (FIELD.test(el2.tagName)) {
        const l = labelFor(el2);
        if (l) return { name: l, from: "label", unsure: null };
        const ph = (el2.getAttribute("placeholder") || "").trim();
        if (ph) return { name: ph, from: "placeholder", unsure: null };
      }
      if (el2.tagName === "FIELDSET") {
        const lg = el2.querySelector("legend");
        if (lg) return { name: textOf(lg), from: "legend", unsure: null };
      }
      if (el2.tagName === "TABLE") {
        const cap = el2.querySelector("caption");
        if (cap) return { name: textOf(cap), from: "caption", unsure: null };
      }
      const role2 = A11y.role(el2);
      if (role2 && FROM_CONTENT.has(role2)) {
        const s = textOf(el2);
        if (s) return { name: s, from: "content", unsure: null };
      }
      const ti = (el2.getAttribute("title") || "").trim();
      if (ti) return { name: ti, from: "title", unsure: null };
      return { name: "", from: null, unsure: tried };
    },
    /** Everything the badge and the rules need, computed once per element. */
    of(el2, cs) {
      const n = A11y.name(el2);
      return {
        name: n.name,
        from: n.from,
        unsure: n.unsure,
        role: A11y.role(el2),
        focusable: A11y.focusable(el2, cs)
      };
    },
    why: {
      labelledby: "aria-labelledby names ids that are not in this document — either they are wrong, or they sit inside a shadow root this pass cannot read"
    }
  };

  // src/tools/a11y/badge.js
  function badge({ el: el2, cs }) {
    const a = A11y.of(el2, cs);
    const rows = [];
    if (Tools.setting(this, "name")) {
      rows.push(a.name ? `<span class="debug-overlay-a11y-k">name</span> ${esc(a.name)}<span class="debug-overlay-a11y-src">${a.from || ""}</span>` : `<span class="debug-overlay-a11y-k">name</span><span class="debug-overlay-a11y-none">${a.unsure ? "not determined" : "none"}</span>`);
    }
    if (Tools.setting(this, "role")) {
      rows.push(`<span class="debug-overlay-a11y-k">role</span> ${esc(a.role || "—")}`);
    }
    if (Tools.setting(this, "focus")) {
      rows.push(`<span class="debug-overlay-a11y-k">tab</span><span class="${a.focusable ? "debug-overlay-a11y-yes" : "debug-overlay-a11y-no"}">${a.focusable ? "reachable" : "not in tab order"}</span>`);
    }
    return rows.length ? rows.join("<br>") : null;
  }
  function compact({ el: el2, cs }) {
    const a = A11y.of(el2, cs);
    if (!a.focusable || a.name || a.unsure) return null;
    return `<span class="debug-overlay-a11y-no">⌨ no name</span>`;
  }
  function legend() {
    return [{
      mark: "⌨ no name",
      means: "red: reachable by Tab, and a screen reader has nothing to announce"
    }];
  }
  function esc(s) {
    return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  }

  // src/tools/a11y/report.js
  function report({ el: el2, cs }) {
    const a = A11y.of(el2, cs);
    const name = a.name ? `"${a.name}"` : a.unsure ? "(not determined)" : "(none)";
    return [`a11y: name ${name}${a.from ? ` via ${a.from}` : ""} · role ${a.role || "—"} · ${a.focusable ? "in the tab order" : "not in the tab order"}`];
  }

  // src/tools/a11y/rule.js
  var rules = {
    "a11y-name": {
      help: "Anything reachable by Tab must have an accessible name — from its own text, an aria-label, a <label>, or alt text.",
      why: 'A screen reader announces the name and nothing else. Without one it says "button", and the only way to find out which button is to press it and see what happens.',
      docs: "https://www.w3.org/WAI/WCAG22/Understanding/name-role-value"
    },
    "a11y-hidden-focus": {
      help: 'A focusable element must not sit inside aria-hidden="true".',
      why: "It stays in the tab order while being absent from the accessibility tree, so keyboard focus lands on something the screen reader cannot describe — the cursor vanishes and nothing says where it went.",
      docs: "https://www.w3.org/WAI/WCAG22/Understanding/name-role-value"
    },
    "a11y-img-alt": {
      help: 'Every <img> needs an alt attribute. Decorative images take alt="".',
      why: 'With no attribute at all a screen reader falls back to the file name, so the page reads out "IMG_20240817_final_2.png". alt="" is the way to say an image carries nothing.',
      docs: "https://www.w3.org/WAI/tutorials/images/decision-tree/"
    }
  };
  function audit(i) {
    const el2 = i.el;
    const out = [];
    const a = A11y.of(el2, i.cs);
    if (el2.tagName === "IMG" && el2.getAttribute("alt") === null) {
      out.push({
        el: el2,
        verdict: "fail",
        severity: "warn",
        rule: "a11y-img-alt",
        message: 'no alt attribute — decorative images need alt=""',
        // one line for the whole page: a gallery of 200 images missing alt is
        // one thing the author has to decide, not 200
        key: "a11y-img-alt"
      });
    }
    if (!a.focusable) return out;
    if (A11y.hidden(el2)) {
      out.push({
        el: el2,
        verdict: "fail",
        severity: "error",
        rule: "a11y-hidden-focus",
        message: `${el2.tagName.toLowerCase()} is in the tab order inside aria-hidden="true"`,
        key: "a11y-hidden-focus"
      });
    }
    if (a.unsure) {
      out.push({
        el: el2,
        verdict: "review",
        severity: "info",
        rule: "a11y-name",
        message: `name not determined — ${A11y.why[a.unsure]}`,
        // grouped by REASON, page-wide — the same discipline contrast uses for
        // its unmeasurable colours
        key: `a11y-name|review|${a.unsure}`
      });
    } else if (!a.name) {
      out.push({
        el: el2,
        verdict: "fail",
        severity: "error",
        rule: "a11y-name",
        message: `${a.role || el2.tagName.toLowerCase()} with no accessible name`,
        // by ROLE, not by element: a toolbar of 40 unnamed icon buttons is one
        // problem with one fix
        key: `a11y-name|${a.role || el2.tagName.toLowerCase()}`
      });
    }
    return out;
  }

  // src/tools/a11y/draw.js
  function draw({ marks, found }) {
    marks(found);
  }

  // src/tools/a11y/index.js
  defineTool({
    css: `
  .debug-overlay-badge .debug-overlay-a11y-k {
    color: var(--debug-overlay-muted); margin-right: 6px;
  }
  .debug-overlay-badge .debug-overlay-a11y-src {
    color: var(--debug-overlay-muted); margin-left: 6px; font-size: 10px;
  }
  .debug-overlay-badge .debug-overlay-a11y-none,
  .debug-overlay-badge .debug-overlay-a11y-no { color: #ff8a65; font-weight: 700; }
  .debug-overlay-badge .debug-overlay-a11y-yes { color: var(--debug-overlay-accent); }
  `,
    id: "a11y",
    // lucide 'accessibility' (ISC)
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="16" cy="4" r="1"/><path d="m18 19 1-7-6 1"/><path d="m5 8 3-3 5.5 3-2.36 3.5"/><path d="M4.24 14.5a5 5 0 0 0 6.88 6"/><path d="M13.76 17.5a5 5 0 0 0-6.88-6"/></svg>',
    // what this tool EXAMINES — it owns its subject alone, so it says so here
    subject: "a11y",
    title: "Accessibility — the name, role and keyboard reach of what you point at",
    /* NOT startsOn. The other read-outs describe what a page LOOKS like, which
       is what someone reaches for the overlay to see. This answers a question
       you have to think to ask, and its badge rows would otherwise crowd every
       hover for people who never asked it. The RULES still run in every sweep
       regardless — arming decides what is drawn, never what is checked. */
    badge,
    legend,
    compact,
    report,
    rules,
    audit,
    draw,
    options() {
      return [
        {
          key: "name",
          label: "Accessible name",
          def: true,
          type: "toggle",
          affects: "inspect"
        },
        {
          key: "role",
          label: "Role",
          def: true,
          type: "toggle",
          affects: "inspect"
        },
        {
          key: "focus",
          label: "Keyboard reach",
          def: true,
          type: "toggle",
          affects: "inspect"
        }
      ];
    }
  });

  // src/tools/colour/contrast/badge.js
  function badge2(i) {
    const c = Colour.measure(i);
    if (!c) return null;
    if (c.unknown) return `<span class="debug-overlay-unk">contrast ?</span>`;
    const cls = c.pass ? "debug-overlay-ok" : "debug-overlay-bad";
    return `<span class="${cls}">${c.ratio.toFixed(2)}:1 ${c.level}${c.pass ? "✓" : "✗"}</span>`;
  }
  function compact2(i) {
    const c = Colour.measure(i);
    if (!c || c.unknown || c.pass) return null;
    return `<span class="debug-overlay-bad">${c.ratio.toFixed(1)}:1 ✗</span>`;
  }
  function legend2() {
    return [
      { mark: "ratio ✓", means: "green: meets the WCAG level set above" },
      { mark: "ratio ✗", means: "red: below it" },
      { mark: "contrast ?", means: "blue italic: not measurable - a gradient, an image, an unreadable colour space" }
    ];
  }

  // src/tools/colour/contrast/report.js
  function report2(i) {
    const c = Colour.measure(i);
    if (!c) return [];
    if (c.unknown) return [`  contrast: not measured — ${Colour.why[c.unknown]}`];
    return [`  contrast: ${c.ratio.toFixed(2)}:1 vs required ${c.need} (${c.isLarge ? "large" : "normal"} text) → ${c.pass ? "PASS" : "FAIL"}`];
  }

  // src/tools/colour/contrast/rule.js
  var rules2 = {
    "contrast-aa": {
      help: "Body text needs 4.5:1 against its background, or 7:1 at AAA; 3:1 once it is 24px or 18.66px bold, or 4.5:1 at AAA. Which level this checks is in the panel under ⚙.",
      why: "Below that, text stops being readable in bright light, on a bad screen, or to anyone with reduced contrast sensitivity — which is most people eventually.",
      docs: "https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum"
    }
  };
  function audit2(i) {
    const c = Colour.measure(i);
    if (!c) return [];
    if (c.unknown) return [{
      el: i.el,
      // Not a failure: a failure is a fact, this is an absence of one. It
      // used to be folded into the same empty array as "passed", so a page
      // of gradient-backed text audited clean. Whatever else this tool
      // gets wrong, it must not report a verdict it never reached.
      verdict: "review",
      severity: "info",
      rule: "contrast-aa",
      message: `not measured — ${Colour.why[c.unknown]}`,
      // one row per reason, page-wide: 200 elements over one gradient are
      // one thing to go and look at, not 200
      key: `contrast-aa|review|${c.unknown}`
    }];
    if (c.pass) return [];
    return [{
      el: i.el,
      verdict: "fail",
      // below the large-text floor nobody can read it; above it, a near
      // miss that a size or weight change might fix
      severity: c.ratio < c.want.large ? "error" : "warn",
      rule: "contrast-aa",
      message: `${c.ratio.toFixed(2)}:1 — ${c.level} needs ${c.need} for ${c.isLarge ? "large" : "normal"} text`,
      // one line per colour pair, not per element: a 40-link nav is ONE
      // problem. Only the rule knows what "the same problem" means.
      key: `contrast-aa|${Colour.rgb(c.fg)}|${Colour.rgb(c.bg)}|${c.isLarge}`
    }];
  }

  // src/tools/colour/contrast/draw.js
  function draw2({ marks, found }) {
    marks(found);
  }

  // src/tools/colour/contrast/index.js
  defineTool({
    // visuals owned by this tool — appended to the stylesheet at boot
    css: `
    .debug-overlay-badge .debug-overlay-ok  { color: var(--debug-overlay-accent); }
    .debug-overlay-badge .debug-overlay-bad { color: #ff6b6b; font-weight: 700; }
    .debug-overlay-badge .debug-overlay-unk { color: #8ab4f8; font-style: italic; }
    `,
    id: "contrast",
    family: "colour",
    // audited: must match the domain folder this sits in
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><circle cx="12" cy="12" r="10" /><path d="M12 18a6 6 0 0 0 0-12v12z" /></svg>',
    // lucide 'contrast' (ISC)
    // the level is the user's choice now, so it cannot be stated here
    title: "Contrast — WCAG text contrast ratio",
    uses: [Colour],
    // its settings are Colour's, and belong on its own menu
    badge: badge2,
    legend: legend2,
    compact: compact2,
    report: report2,
    rules: rules2,
    audit: audit2,
    draw: draw2
  });

  // src/tools/colour/paint/shape.js
  function radii(cs, w, h) {
    const pair = (v) => {
      const p = String(v || "0").trim().split(/\s+/);
      const n = (s, base2) => String(s).endsWith("%") ? (parseFloat(s) || 0) / 100 * base2 : parseFloat(s) || 0;
      return [Math.max(0, n(p[0], w)), Math.max(0, n(p[1] === void 0 ? p[0] : p[1], h))];
    };
    const r = {
      tl: pair(cs.borderTopLeftRadius),
      tr: pair(cs.borderTopRightRadius),
      br: pair(cs.borderBottomRightRadius),
      bl: pair(cs.borderBottomLeftRadius)
    };
    const ratio = (sum, len) => sum > 0 ? len / sum : Infinity;
    const f = Math.min(
      ratio(r.tl[0] + r.tr[0], w),
      ratio(r.bl[0] + r.br[0], w),
      ratio(r.tl[1] + r.bl[1], h),
      ratio(r.tr[1] + r.br[1], h),
      1
    );
    if (f < 1) for (const k of ["tl", "tr", "br", "bl"]) r[k] = [r[k][0] * f, r[k][1] * f];
    return r;
  }
  function inRounded(x, y, b, rad) {
    if (x < b.left || x > b.right || y < b.top || y > b.bottom) return false;
    const corner = (zone, cx, cy, rx, ry) => {
      if (!zone || rx <= 0 || ry <= 0) return true;
      const dx = (x - cx) / rx, dy = (y - cy) / ry;
      return dx * dx + dy * dy <= 1;
    };
    return corner(
      x < b.left + rad.tl[0] && y < b.top + rad.tl[1],
      b.left + rad.tl[0],
      b.top + rad.tl[1],
      rad.tl[0],
      rad.tl[1]
    ) && corner(
      x > b.right - rad.tr[0] && y < b.top + rad.tr[1],
      b.right - rad.tr[0],
      b.top + rad.tr[1],
      rad.tr[0],
      rad.tr[1]
    ) && corner(
      x > b.right - rad.br[0] && y > b.bottom - rad.br[1],
      b.right - rad.br[0],
      b.bottom - rad.br[1],
      rad.br[0],
      rad.br[1]
    ) && corner(
      x < b.left + rad.bl[0] && y > b.bottom - rad.bl[1],
      b.left + rad.bl[0],
      b.bottom - rad.bl[1],
      rad.bl[0],
      rad.bl[1]
    );
  }
  function padBox(b, bw) {
    return {
      left: b.left + bw.l,
      top: b.top + bw.t,
      right: b.right - bw.r,
      bottom: b.bottom - bw.b
    };
  }
  function padRadii(rad, bw) {
    const sub = (v, n) => Math.max(0, v - n);
    return {
      tl: [sub(rad.tl[0], bw.l), sub(rad.tl[1], bw.t)],
      tr: [sub(rad.tr[0], bw.r), sub(rad.tr[1], bw.t)],
      br: [sub(rad.br[0], bw.r), sub(rad.br[1], bw.b)],
      bl: [sub(rad.bl[0], bw.l), sub(rad.bl[1], bw.b)]
    };
  }
  function cornerAt(x, y, b, rad) {
    const zones = [
      ["top-left", x < b.left + rad.tl[0] && y < b.top + rad.tl[1], rad.tl],
      ["top-right", x > b.right - rad.tr[0] && y < b.top + rad.tr[1], rad.tr],
      ["bottom-right", x > b.right - rad.br[0] && y > b.bottom - rad.br[1], rad.br],
      ["bottom-left", x < b.left + rad.bl[0] && y > b.bottom - rad.bl[1], rad.bl]
    ];
    const hit = zones.find(([, inZone]) => inZone);
    return hit ? { corner: hit[0], r: Math.round(hit[2][0]) } : null;
  }
  function sideAt(x, y, b, bw) {
    if (bw.t && y < b.top + bw.t) return "top";
    if (bw.b && y > b.bottom - bw.b) return "bottom";
    if (bw.l && x < b.left + bw.l) return "left";
    if (bw.r && x > b.right - bw.r) return "right";
    return null;
  }
  function shadowAt(x, y, b, cs) {
    const raw = String(cs.boxShadow || "none");
    if (raw === "none" || !raw) return null;
    const parts = raw.split(/,(?![^(]*\))/);
    for (const part of parts) {
      const s = part.trim();
      if (/\binset\b/.test(s)) continue;
      const nums = (s.match(/-?[\d.]+px/g) || []).map(parseFloat);
      if (nums.length < 2) continue;
      const [dx, dy, , spread = 0] = nums;
      const r = {
        left: b.left + dx - spread,
        top: b.top + dy - spread,
        right: b.right + dx + spread,
        bottom: b.bottom + dy + spread
      };
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return s;
    }
    return null;
  }

  // src/tools/colour/paint/ancestry.js
  function ancestry(x, y, els) {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    const faders = [];
    for (const el2 of els) {
      for (let e = el2.parentElement; e && e.nodeType === 1; e = e.parentElement) {
        if (seen.has(e)) break;
        seen.add(e);
        const cs = getComputedStyle(e);
        const op = parseFloat(cs.opacity);
        if (Number.isFinite(op) && op < 1) faders.push({ el: e, sel: U.selectorOf(e), v: op });
        const clips = /\b(hidden|clip|auto|scroll|overlay)\b/.test(cs.overflow || "") || cs.clipPath && cs.clipPath !== "none";
        if (!clips) continue;
        if (cs.clipPath && cs.clipPath !== "none") {
          out.push({ el: e, sel: U.selectorOf(e), why: `clip-path: ${cs.clipPath}`, sure: false });
          continue;
        }
        const r = e.getBoundingClientRect();
        const bw = {
          t: parseFloat(cs.borderTopWidth) || 0,
          r: parseFloat(cs.borderRightWidth) || 0,
          b: parseFloat(cs.borderBottomWidth) || 0,
          l: parseFloat(cs.borderLeftWidth) || 0
        };
        if (!inRounded(x, y, padBox(r, bw), padRadii(radii(cs, r.width, r.height), bw))) {
          out.push({ el: e, sel: U.selectorOf(e), why: `overflow: ${cs.overflow}`, sure: true });
        }
      }
    }
    return { blockers: out, faders };
  }
  var clippedBy = (el2, blockers) => blockers.find((b) => b.el !== el2 && b.el.contains(el2)) || null;

  // src/tools/colour/paint/pseudo.js
  function pseudo(el2, which) {
    let cs = null;
    try {
      cs = getComputedStyle(el2, which);
    } catch {
      return null;
    }
    if (!cs) return null;
    const content = cs.content;
    if (!content || content === "none" || content === "normal") return null;
    const bits = [];
    bits.push(`content ${cs.content}`);
    const bg = cs.backgroundColor;
    if (bg && bg !== "transparent" && !/^rgba\(0, 0, 0, 0\)$/.test(bg)) bits.push(`bg ${bg}`);
    if (cs.backgroundImage && cs.backgroundImage !== "none") bits.push("background-image");
    if (cs.maskImage && cs.maskImage !== "none") bits.push("mask");
    if (parseFloat(cs.borderTopWidth) || parseFloat(cs.borderLeftWidth)) bits.push("border");
    if (cs.boxShadow && cs.boxShadow !== "none") bits.push(`box-shadow ${cs.boxShadow}`);
    const paints = bits.length > 1 || !/^["'](?:)?["']$/.test(cs.content);
    return paints ? { which, bits, geo: geometry(cs) } : null;
  }
  function geometry(cs) {
    const size = `${cs.width || "auto"} × ${cs.height || "auto"}`;
    const set = ["top", "right", "bottom", "left"].map((k) => [k, cs[k]]).filter(([, v]) => v && v !== "auto");
    if (!set.length) return `no inset · ${size}`;
    const vals = set.map(([, v]) => v);
    if (set.length === 4 && vals.every((v) => v === vals[0])) return `inset ${vals[0]} · ${size}`;
    return `${set.map(([k, v]) => `${k} ${v}`).join(" ")} · ${size}`;
  }

  // src/tools/colour/paint/probe.js
  var EMPTY = { layers: [], dropped: 0, hosts: [], frames: [] };
  var CACHE_MS = 250;
  var alphaOf = (v) => {
    const c = Colour.colour(v);
    return c ? c.a == null ? 1 : c.a : null;
  };
  function ownFade(cs, el2) {
    const v = parseFloat(cs.opacity);
    return Number.isFinite(v) && v < 1 ? { el: el2, sel: U.selectorOf(el2), v } : null;
  }
  var Probe = {
    at: null,
    // { px, py } in page coordinates, or null
    _cache: null,
    // the last walk, keyed by the point it answered for
    set(clientX, clientY) {
      Probe.at = { px: clientX + scrollX, py: clientY + scrollY };
      Probe._cache = null;
    },
    /** The probe in viewport coordinates, or null. */
    point() {
      if (!Probe.at) return null;
      return { x: Probe.at.px - scrollX, y: Probe.at.py - scrollY };
    },
    /**
     * Everything the OVERLAY drew is not the page. Our root is appended to
     * documentElement rather than body — the same fact the sweep leans on to
     * exclude itself without a per-element check — so containment in body is
     * exactly the test, and no id is spelled here.
     */
    ofPage: (el2) => !!(document.body && document.body.contains(el2)),
    /**
     * EVERY element that clips this point away, found once.
     *
     * Whether a clipper excludes a point is a fact about the CLIPPER, not about
     * each layer beneath it — and asking it per layer walked the whole ancestor
     * chain once for every layer in the stack. On a 27-deep stack that is 800
     * getComputedStyle calls for one frame, and the frame runs on every pointer
     * move: ~48 000 style resolutions a second, which is a page that feels
     * stuck. Reading properties is the cost in this codebase; this counts them.
     *
     * Walked once per element, and a chain already seen ends the walk — if an
     * element has been tested, everything above it has too, because every walk
     * goes to the root.
     */
    /**
     * The stack at a viewport point, top → bottom, each layer judged.
     *
     * elementsFromPoint is hit-testing, so it already answers "is the point in
     * the box" — and answers nothing else. Everything below is the difference
     * between that and what is painted.
     */
    stack(x, y) {
      return Probe.walk(x, y).layers;
    },
    /**
     * The stack, AND EVERY WAY IT IS INCOMPLETE. A walk that stops silently is
     * the worst answer this tool can give: the reader takes a partial stack for
     * the whole one and reasons from a wrong picture. Same discipline the page
     * sweep already lives by — say what was not checked, or the count reads as
     * the whole page.
     */
    walk(x, y) {
      const now = performance.now();
      const c = Probe._cache;
      if (c && c.x === x && c.y === y && now - c.at < CACHE_MS) return c.value;
      let els = [];
      try {
        els = document.elementsFromPoint(x, y) || [];
      } catch {
        return EMPTY;
      }
      const page = els.filter(Probe.ofPage);
      const anc = ancestry(x, y, page);
      const layers = page.map((el2) => Probe.layer(el2, x, y, anc));
      const value = {
        layers,
        // our own root hangs off documentElement, so anything dropped here is
        // the overlay's own furniture sitting over the pixel
        dropped: els.length - page.length,
        /* elementsFromPoint retargets to the HOST and never enters a shadow
           tree, so a stack that meets a web component stops there. An open root
           can at least be named; a CLOSED one cannot be detected at all, which
           is why the report says "at least". */
        hosts: layers.filter((L) => L.el.shadowRoot).map((L) => L.sel),
        // a frame is a whole document this walk cannot cross into, and a
        // cross-origin one could not be read even with permission
        frames: layers.filter((L) => /^(IFRAME|FRAME)$/.test(L.el.tagName)).map((L) => L.sel)
      };
      Probe._cache = { x, y, at: now, value };
      return value;
    },
    /**
     * ONE element, judged at one point. Split out because the badge asks it of
     * whatever you are pointing at — which may not be in the stack at all — and
     * two copies of this judgement is how a badge comes to disagree with the
     * report about the same pixel.
     */
    layer(el2, x, y, anc) {
      const cs = getComputedStyle(el2);
      const r = el2.getBoundingClientRect();
      const bw = {
        t: parseFloat(cs.borderTopWidth) || 0,
        r: parseFloat(cs.borderRightWidth) || 0,
        b: parseFloat(cs.borderBottomWidth) || 0,
        l: parseFloat(cs.borderLeftWidth) || 0
      };
      const rad = radii(cs, r.width, r.height);
      const inShape = inRounded(x, y, r, rad);
      const A = anc || ancestry(x, y, [el2]);
      const clip = clippedBy(el2, A.blockers);
      const side = inShape ? sideAt(x, y, r, bw) : null;
      const bgImage = cs.backgroundImage && cs.backgroundImage !== "none" ? cs.backgroundImage : null;
      const backdrop = [cs.backdropFilter, cs.webkitBackdropFilter].find((v) => v && v !== "none") || null;
      return {
        el: el2,
        cs,
        sel: U.selectorOf(el2),
        /* THE RECT, because a short selector is often not unique — one real
           app has dozens of div.flex.flex-1.min-h-0, and from the text alone
           there is no telling which one this is. Size and position tell them
           apart, and they are already measured here. */
        rect: {
          x: Math.round(r.left),
          y: Math.round(r.top),
          w: Math.round(r.width),
          h: Math.round(r.height)
        },
        paints: inShape && !clip,
        inBox: true,
        // elementsFromPoint said so
        inShape,
        clip,
        side,
        // the border wins where the point is in it: that is the colour the
        // pixel gets, and a card's ring is exactly where a wedge tends to be
        colour: side ? cs[`border${side[0].toUpperCase()}${side.slice(1)}Color`] : cs.backgroundColor,
        from: side ? `border-${side}-color` : "background-color",
        bgImage,
        backdrop,
        /* THE ALPHA, resolved once. "PAINTS" over rgba(0,0,0,0) is a lie —
           a transparent layer contributes nothing, and calling it a painter
           puts it in the blend count too, where it makes the count mean
           nothing. null is a colour this cannot read, which is its own
           answer and not a zero. */
        alpha: alphaOf(side ? cs[`border${side[0].toUpperCase()}${side.slice(1)}Color`] : cs.backgroundColor),
        /* The same class as backdrop-filter: things the fold cannot model,
           each of which makes the composite quietly wrong if left unsaid.
           `filter` is the element's OWN — it transforms everything the
           element paints, after the fact. */
        filter: cs.filter && cs.filter !== "none" ? cs.filter : null,
        blend: cs.mixBlendMode && cs.mixBlendMode !== "normal" ? cs.mixBlendMode : null,
        /* The NEAREST element that actually sets opacity — itself or an
           ancestor — rather than this layer's cumulative value. One faded
           wrapper made every layer beneath it report the same number, which
           is four lines for one fact: the same repetition Sweep.group exists
           to collapse. Named by its owner, it collapses to one. */
        /* The nearest element at or above this one that sets opacity below 1
           — itself, or the first fader above it. Opacity fades a whole
           subtree AS ONE GROUP, which is precisely what a colour-over-colour
           fold cannot express, so the element that SETS it is the fact worth
           reporting, once. */
        fader: ownFade(cs, el2) || A.faders.find((f) => f.el.contains(el2)) || null,
        shadow: inShape ? null : shadowAt(x, y, r, cs),
        pseudo: [pseudo(el2, "::before"), pseudo(el2, "::after")].filter(Boolean),
        radius: U.radius(cs)
      };
    }
  };

  // src/tools/colour/paint/badge.js
  function badge3(i) {
    const p = Probe.point();
    if (!p) return null;
    const r = i.r;
    if (p.x < r.left || p.x > r.right || p.y < r.top || p.y > r.bottom) return null;
    const L = Probe.layer(i.el, p.x, p.y);
    if (L.clip) {
      return `<span class="debug-overlay-paint-no">⛏ clipped here</span><span class="debug-overlay-paint-k"> by ${esc2(L.clip.sel)}</span>`;
    }
    if (!L.inShape) {
      const why = L.radius ? `outside r ${esc2(L.radius)}` : "outside the painted shape";
      return `<span class="debug-overlay-paint-no">⛏ box only — not painted here</span><span class="debug-overlay-paint-k"> ${why}</span>`;
    }
    const where = `<span class="debug-overlay-paint-k"> ${esc2(L.from.replace("background-color", "bg"))} ${esc2(L.colour)}</span>`;
    if (L.alpha === null) return `<span class="debug-overlay-paint-no">⛏ colour not read</span>${where}`;
    if (L.alpha === 0 && !L.bgImage) {
      return `<span class="debug-overlay-paint-no">⛏ transparent here</span><span class="debug-overlay-paint-k"> contributes nothing</span>`;
    }
    const a = L.alpha < 1 ? `<span class="debug-overlay-paint-k"> alpha ${L.alpha}</span>` : "";
    return `<span class="debug-overlay-paint-yes">⛏ paints here</span>${a}${where}`;
  }
  function compact3(i) {
    const p = Probe.point();
    if (!p) return null;
    const r = i.r;
    if (p.x < r.left || p.x > r.right || p.y < r.top || p.y > r.bottom) return null;
    const L = Probe.layer(i.el, p.x, p.y);
    if (L.clip) return `<span class="debug-overlay-paint-no">⛏ clipped</span>`;
    if (!L.inShape) return `<span class="debug-overlay-paint-no">⛏ box only</span>`;
    if (L.alpha === 0 && !L.bgImage) return `<span class="debug-overlay-paint-no">⛏ transparent</span>`;
    return null;
  }
  function legend3() {
    return [
      { mark: "⛏ paints here", means: "green: this element really does paint the probed pixel" },
      { mark: "⛏ box only", means: "amber: the probe is inside its box but outside its rounded shape — the colour there is somebody else’s" },
      { mark: "⛏ clipped here", means: "amber: an ancestor’s overflow removes this element at that point" },
      { mark: "⛏ transparent here", means: "amber: its box is over the pixel, but it contributes no colour at all" },
      { mark: "alpha 0.06", means: "it paints, but only partly — what you see is a blend of it and what is behind" }
    ];
  }
  function gestures() {
    return [{
      keys: "Point at a pixel (⛏ armed)",
      does: "the paint probe follows, and HOLDS when you move onto the panel — so ⧉ reports the pixel you meant"
    }];
  }
  function esc2(s) {
    return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  }

  // src/tools/colour/paint/verdict.js
  function base(layers) {
    let at = -1;
    const opaque = (L) => {
      if (!L.paints || L.bgImage) return false;
      const c = Colour.colour(L.colour);
      return !!c && (c.a == null || c.a >= 0.999);
    };
    for (let i = layers.length - 1; i >= 0; i--) if (opaque(layers[i])) at = i;
    const over = at < 0 ? 0 : layers.slice(0, at).filter((L) => L.paints && (L.bgImage || L.alpha != null && L.alpha > 0)).length;
    return { at, over };
  }
  function composite(layers) {
    const doubts = [];
    const floor = base(layers).at;
    let out = { r: 255, g: 255, b: 255, a: 1 };
    for (let i = layers.length - 1; i >= 0; i--) {
      const L = layers[i];
      if (!L.paints) continue;
      const at = `[${i + 1}] `;
      if (floor >= 0 && i <= floor) {
        for (const ps of L.pseudo) {
          doubts.push(`${at}${L.sel} has a ${ps.which} (${ps.bits.join(", ")} · ${ps.geo}) — a pseudo paints OVER its element and no hit test reaches it, so this fold leaves it out`);
        }
      }
      if (L.bgImage) doubts.push(`${at}${L.sel} paints a background-image — its pixel here is unknown`);
      if (L.backdrop) doubts.push(`${at}${L.sel} has backdrop-filter: ${L.backdrop} — the pixel here is FILTERED, not composited`);
      if (L.filter) doubts.push(`${at}${L.sel} has filter: ${L.filter} — it transforms everything the element paints, after the fact`);
      if (L.blend) doubts.push(`${at}${L.sel} has mix-blend-mode: ${L.blend} — it does not composite as colour over colour`);
      if (L.fader) doubts.push(`${L.fader.sel} has opacity ${L.fader.v} — it fades its whole subtree as ONE group, which a colour-over-colour fold cannot express`);
      const c = Colour.colour(L.colour);
      if (!c) {
        doubts.push(`${L.sel} ${L.from} is a colour space this cannot read`);
        continue;
      }
      if (c.a === 0) continue;
      out = Colour.over(c, out);
    }
    return { colour: out, doubts: [...new Set(doubts)] };
  }

  // src/tools/colour/paint/skipped.js
  function skipped(x, y, inStack) {
    const hit = new Set(inStack);
    const out = [];
    let all = [];
    try {
      all = document.body ? document.body.querySelectorAll("*") : [];
    } catch {
      return out;
    }
    for (const el2 of all) {
      if (hit.has(el2)) continue;
      const r = el2.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      if (x < r.left || x > r.right || y < r.top || y > r.bottom) continue;
      const cs = getComputedStyle(el2);
      const why = reason(el2, cs, r, x, y);
      if (why) out.push({ el: el2, sel: U.selectorOf(el2), r, why });
    }
    return out.sort((a, b) => a.r.width * a.r.height - b.r.width * b.r.height);
  }
  function reason(el2, cs, r, x, y) {
    if (cs.visibility === "hidden") return "visibility: hidden — laid out, and not hit-testable";
    if (cs.pointerEvents === "none") return "pointer-events: none — it declines the hit test";
    for (let e = el2.parentElement; e && e.nodeType === 1; e = e.parentElement) {
      if (getComputedStyle(e).pointerEvents === "none") {
        return `pointer-events: none on ${U.selectorOf(e)} — inherited, so this declines too`;
      }
    }
    const clip = clippedBy(el2, ancestry(x, y, [el2]).blockers);
    if (clip) return `clipped away by ${clip.sel} (${clip.why})`;
    const rad = radii(cs, r.width, r.height);
    if (!inRounded(x, y, r, rad)) {
      const c = cornerAt(x, y, r, rad);
      return "outside its painted shape" + (c ? ` (r ${c.r}, ${c.corner} corner)` : "") + " — the browser skips it for the same reason, which is why it is not in the stack";
    }
    return "skipped, and no cause this can name — worth looking at by hand";
  }

  // src/tools/colour/paint/sample.js
  var Sample = {
    at: null,
    // { px, py, rgb } — the last pixel read, for the point it was read at
    why: null,
    // why the last attempt could not answer
    /** Is this build even able to ask? A store or sideload build has the
     *  permission; the dev page and the suite do not, and must say so rather
     *  than appear to have measured something. */
    capable: () => typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id),
    forget() {
      Sample.at = null;
      Sample.why = null;
    },
    /** The pixel for the CURRENT probe point, or null. Never recomputed from a
     *  stale point: a sample belongs to the pixel it was taken at. */
    current() {
      const p = Probe.at;
      if (!p || !Sample.at) return null;
      return Sample.at.px === p.px && Sample.at.py === p.py ? Sample.at : null;
    }
  };
  function prepare() {
    Sample.forget();
    const p = Probe.point();
    if (!p) return null;
    if (!Tools.setting(this, "sample")) return null;
    if (!Sample.capable()) {
      Sample.why = "this build has no extension runtime to capture through";
      return null;
    }
    return (async () => {
      try {
        const url = await ask();
        const rgb = await pixel(url, p.x, p.y);
        if (rgb) Sample.at = { px: Probe.at.px, py: Probe.at.py, rgb };
        else Sample.why = "the capture arrived but that pixel could not be read";
      } catch (e) {
        Sample.why = explain(String(e && e.message || e));
      }
    })();
  }
  function explain(raw) {
    if (/activeTab|all_urls|permission/i.test(raw)) {
      return `activeTab has not been granted for this tab — press the Debug Overlay icon in CHROME'S TOOLBAR (not the bar on the page, not anything in the side panel), then copy again. That click is what invokes the extension; it covers this one tab and is dropped when the tab changes origin. If the panel was already open, press it anyway: the click is the grant, not the panel. (Chrome said: ${raw})`;
    }
    return raw || "the tab could not be captured";
  }
  function ask() {
    return new Promise((resolve, reject) => {
      let done = false;
      const give = (fn, v) => {
        if (!done) {
          done = true;
          fn(v);
        }
      };
      setTimeout(() => give(reject, new Error("the worker did not answer in time")), 4e3);
      try {
        chrome.runtime.sendMessage({ type: "debug-overlay-capture" }, (r) => {
          if (chrome.runtime.lastError) return give(reject, new Error(chrome.runtime.lastError.message));
          if (!r || !r.ok) return give(reject, new Error(r && r.error || "the tab could not be captured"));
          give(resolve, r.url);
        });
      } catch (e) {
        give(reject, e);
      }
    });
  }
  function pixel(url, x, y) {
    return new Promise((resolve) => {
      let img = new Image();
      let settled = false;
      const done = (v) => {
        if (settled) return;
        settled = true;
        if (img) {
          img.onload = img.onerror = null;
          img.src = "";
          img = null;
        }
        resolve(v);
      };
      setTimeout(() => done(null), 4e3);
      img.onerror = () => done(null);
      img.onload = () => {
        try {
          const c = document.createElement("canvas");
          c.width = c.height = 1;
          const g = c.getContext("2d", { willReadFrequently: true });
          const r = devicePixelRatio || 1;
          g.drawImage(img, -Math.round(x * r), -Math.round(y * r));
          const d = g.getImageData(0, 0, 1, 1).data;
          done({ r: d[0], g: d[1], b: d[2] });
        } catch {
          done(null);
        }
      };
      img.src = url;
    });
  }

  // src/tools/colour/paint/report.js
  function reportTail() {
    const p = Probe.point();
    if (!p) return [
      "",
      "## paint — no probe yet",
      "Armed, but the pointer has not been over the page since. Point at the pixel",
      "in question; the stack at that point appears here."
    ];
    const L = [];
    L.push("", `## paint — the pixel at (${Math.round(p.x)}, ${Math.round(p.y)})`);
    L.push(`page coordinates (${Math.round(Probe.at.px)}, ${Math.round(Probe.at.py)}) · dpr ${devicePixelRatio}`);
    const { layers, dropped, hosts, frames } = Probe.walk(p.x, p.y);
    if (!layers.length) {
      L.push("nothing in the page is under that point.");
      L.push(...scope(dropped, hosts, frames));
      return L;
    }
    const { at, over } = base(layers);
    const covered = at >= 0 && layers.slice(0, at + 1).some((x) => x.pseudo.length);
    const w = Math.min(40, Math.max(...layers.map((x) => x.sel.length)));
    const boxes = layers.map((x) => `(${x.rect.x}, ${x.rect.y}, ${x.rect.w} × ${x.rect.h})`);
    const bw = Math.max(...boxes.map((b) => b.length));
    L.push("stack, top → bottom:");
    layers.forEach((x, i) => {
      const sel = x.sel.length > w ? "…" + x.sel.slice(-(w - 1)) : x.sel.padEnd(w);
      let verdict;
      if (x.clip) {
        verdict = `clipped away here by ${x.clip.sel} (${x.clip.why})${x.clip.sure ? "" : " — not evaluated, assume it may clip"}`;
      } else if (!x.inShape) {
        verdict = `box only — not painted here` + (x.radius ? ` (outside r ${x.radius})` : "") + (x.shadow ? ` · box-shadow reaches here: ${x.shadow}` : "");
      } else {
        const a = x.alpha;
        const img = x.bgImage ? ` · background-image ${x.bgImage}` : "";
        if (a === null) verdict = `colour NOT READ (${x.colour}) — a colour space this cannot resolve${img}`;
        else if (a === 0 && !x.bgImage) verdict = `transparent — contributes nothing · ${x.from} ${x.colour}`;
        else if (a < 1) verdict = `PAINTS · alpha ${a} · ${x.from} ${x.colour}${img}`;
        else verdict = `PAINTS · ${x.from} ${x.colour}${img}`;
      }
      if (x.el.shadowRoot) verdict += " · shadow content NOT walked";
      if (/^(IFRAME|FRAME)$/.test(x.el.tagName)) verdict += " · frame contents NOT walked";
      const notes = [];
      if (over) notes.push(`${over} layer${over === 1 ? "" : "s"} blend over it`);
      if (covered) notes.push("a pseudo paints over it, unseen");
      const win = i !== at ? "" : notes.length ? `  ← base · ${notes.join(" · ")}` : "  ← the colour you see";
      L.push(`  [${i + 1}] ${sel}  ${boxes[i].padEnd(bw)}  ${verdict}${win}`);
      if (x.backdrop) {
        L.push(`      backdrop-filter: ${x.backdrop} — the pixel here is FILTERED, not`);
        L.push(`      composited; the walk below cannot account for it`);
      }
      for (const ps of x.pseudo) {
        L.push(`      ${ps.which} — ${ps.bits.join(" · ")}`);
        L.push(`      ${" ".repeat(ps.which.length)}   ${ps.geo} — NOT in the stack; no hit test reaches it`);
      }
    });
    const gone = skipped(p.x, p.y, layers.map((x) => x.el));
    if (gone.length) {
      L.push("in the box, NOT in the stack — the hit test skipped these:");
      for (const g of gone) {
        const sel = g.sel.length > w ? "…" + g.sel.slice(-(w - 1)) : g.sel.padEnd(w);
        const box = `(${Math.round(g.r.left)}, ${Math.round(g.r.top)}, ${Math.round(g.r.width)} × ${Math.round(g.r.height)})`;
        L.push(`  [—] ${sel}  ${box.padEnd(bw)}  box contains the point, hit test SKIPPED it`);
        L.push(`      ${g.why}`);
      }
    }
    const { colour, doubts } = composite(layers);
    L.push(`composited bottom → top: rgb(${Colour.rgb(colour)})`);
    if (at < 0) {
      L.push("no fully opaque layer in the stack — the page canvas (white) shows through,");
      L.push("   which is where the composite above starts.");
    }
    const agreed = agreement(colour);
    L.push(...sampleLines(agreed));
    L.push(...doubtLines(doubts, agreed));
    L.push(...scope(dropped, hosts, frames));
    return L;
  }
  function agreement(colour) {
    const got = Sample.current();
    if (!got) return null;
    const c = { r: Math.round(colour.r), g: Math.round(colour.g), b: Math.round(colour.b) };
    const d = {
      r: Math.abs(c.r - got.rgb.r),
      g: Math.abs(c.g - got.rgb.g),
      b: Math.abs(c.b - got.rgb.b)
    };
    return { got, c, d, worst: Math.max(d.r, d.g, d.b) };
  }
  function doubtLines(doubts, a) {
    if (!doubts.length) return [];
    let head;
    if (!a) {
      head = "not accounted for — nothing has verified the composite, so any of these may be why it is wrong:";
    } else if (a.worst === 0) {
      head = "not accounted for — flagged, but the sample AGREES exactly, so none of these painted at this pixel:";
    } else if (a.worst <= 3) {
      head = `not accounted for — the sample agrees to within ${a.worst}, so these probably did not paint here; a gap that small is more likely a rounding or a colour-space conversion:`;
    } else {
      head = `not accounted for — the sample DISAGREES by ${a.worst}, and ` + (doubts.length === 1 ? "this is the likely cause:" : `these ${doubts.length} are the candidates:`);
    }
    return [head, ...doubts.map((d) => `   ${d}`)];
  }
  function sampleLines(a) {
    if (!a) {
      const L2 = [
        "sampled pixel: not taken — the composite above is a CLAIM computed",
        "   from the walk, and nothing here has verified it."
      ];
      if (Sample.why) {
        L2.push("   why: " + Sample.why.replace(/(.{88}) /g, "$1\n        "));
      } else {
        L2.push('   Turn on "Sample the real pixel" under ⚙ to have ⧉ read the screen.');
      }
      return L2;
    }
    const { got, c, d, worst } = a;
    const L = [
      `sampled pixel: rgb(${got.rgb.r},${got.rgb.g},${got.rgb.b})   (capture taken, one pixel read, discarded)`,
      `   composite   rgb(${c.r},${c.g},${c.b})`,
      `   ΔRGB        ${d.r},${d.g},${d.b}   worst ${worst}`
    ];
    if (worst === 0) L.push("   they agree — the walk accounted for everything that paints here");
    else if (worst <= 3) L.push("   near-agreement: a rounding, a colour-space conversion, or a saturate");
    else L.push(`   THEY DISAGREE by ${worst} — something paints here that the walk did not account for; the notes below are the candidates`);
    return L;
  }
  function scope(dropped, hosts, frames) {
    const parts = [];
    if (dropped) {
      parts.push(`${dropped} overlay layer${dropped === 1 ? "" : "s"} of our own removed from the top — they are not the page`);
    }
    if (hosts.length) {
      parts.push(
        `stack STOPPED at ${hosts.length} shadow host${hosts.length === 1 ? "" : "s"} (${hosts.join(", ")}) — elementsFromPoint retargets to the`,
        "   host and never enters the tree. AT LEAST that many: a closed root",
        "   cannot be detected at all, so this is a floor, not a total."
      );
    }
    if (frames.length) {
      parts.push(
        `${frames.length} frame${frames.length === 1 ? "" : "s"} not entered (${frames.join(", ")}) — a separate document, and a`,
        "   cross-origin one could not be read even with permission."
      );
    }
    return parts.length ? ["not walked:", ...parts.map((x) => x.startsWith("   ") ? x : `   ${x}`)] : [];
  }

  // src/tools/colour/paint/draw.js
  function draw3({ layer: layer2, Place: Place2 }) {
    const p = Probe.point();
    if (!p) return;
    const dot = document.createElement("div");
    dot.className = "debug-overlay-paint-dot";
    Place2.put(dot, p.x - 5, p.y - 5, 10, 10);
    Place2.claim(p.x - 7, p.y - 7, 14, 14);
    layer2.append(dot);
    const layers = Probe.walk(p.x, p.y).layers;
    const painter = layers[base(layers).at];
    if (!painter || !document.contains(painter.el)) return;
    const r = painter.el.getBoundingClientRect();
    const box = document.createElement("div");
    box.className = "debug-overlay-box debug-overlay-paint-box";
    Place2.put(box, r.left, r.top, r.width, r.height);
    layer2.append(box);
  }

  // src/tools/colour/paint/follow.js
  function watch(ctx) {
    Probe.redraw = ctx && ctx.redraw;
    Probe.onMove = (e) => {
      if (!document.body || !document.body.contains(e.target)) return;
      const p = Probe.point();
      if (p && Math.round(p.x) === Math.round(e.clientX) && Math.round(p.y) === Math.round(e.clientY)) return;
      Probe.set(e.clientX, e.clientY);
      Probe.redraw?.();
    };
    addEventListener("pointermove", Probe.onMove, true);
  }
  function unwatch() {
    if (Probe.onMove) removeEventListener("pointermove", Probe.onMove, true);
    Probe.onMove = null;
    Probe.redraw = null;
    Probe.at = null;
    Probe._cache = null;
  }

  // src/tools/colour/paint/index.js
  defineTool({
    css: `
  .debug-overlay-paint-dot { position: fixed; pointer-events: none;
    border-radius: 50%; border: 2px solid var(--debug-overlay-info);
    box-shadow: 0 0 0 1px rgba(0,0,0,.6); }
  .debug-overlay-paint-box { outline: 2px dashed var(--debug-overlay-info); }
  .debug-overlay-badge .debug-overlay-paint-yes { color: var(--debug-overlay-accent); font-weight: 700; }
  .debug-overlay-badge .debug-overlay-paint-no  { color: var(--debug-overlay-warn); font-weight: 700; }
  .debug-overlay-badge .debug-overlay-paint-k   { color: var(--debug-overlay-muted); }
  `,
    id: "paint",
    family: "colour",
    // audited: must match the domain folder this sits in
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 22 1-1h3l9-9"/><path d="M3 21v-3l9-9"/><path d="m15 6 3.4-3.4a2.1 2.1 0 1 1 3 3L18 9l.4.4a2.1 2.1 0 1 1-3 3l-3.8-3.8a2.1 2.1 0 1 1 3-3l.4.4Z"/></svg>',
    // lucide 'pipette' (ISC)
    title: "Paint — which element actually paints the pixel you clicked",
    /* NOT startsOn, and honestly off for COST as well as caution: armed, it
       listens to every pointer move and rebuilds the stack under the cursor.
       A meter you did not ask for is overhead pretending to be help. */
    watch,
    unwatch,
    prepare,
    /**
     * THE ONE SETTING, and it is a privacy decision rather than a preference.
     *
     * Everything else this tool prints is derived from the DOM. This reads the
     * PIXEL, which means capturing the visible tab — and the pages it runs on
     * carry names, locations and phone numbers. So it is off until somebody
     * says otherwise, the label says what it does rather than what it gives,
     * and the capture happens only on an explicit ⧉ copy: a hover never takes
     * one, whatever is armed.
     *
     * Filed under INSPECT, because it changes what you are SHOWN about the
     * pixel rather than what counts as a problem — so turning it on must not
     * throw away a page audit that was judged under the same rules.
     */
    options() {
      return [
        {
          key: "sample",
          label: "Sample the real pixel — captures the tab on ⧉",
          def: false,
          type: "toggle",
          affects: "inspect"
        }
      ];
    },
    badge: badge3,
    compact: compact3,
    legend: legend3,
    gestures,
    draw: draw3,
    reportTail
  });

  // src/tools/dupid/badge.js
  function badge4({ el: el2 }) {
    if (!el2.id) return null;
    const n = document.querySelectorAll(
      `[id="${CSS.escape ? CSS.escape(el2.id) : el2.id}"]`
    ).length;
    return n > 1 ? `<span class="debug-overlay-dup">⌗ id ×${n}</span>` : null;
  }
  function compact4(i) {
    return this.badge(i);
  }
  function legend4() {
    return [{ mark: "⌗ id ×2", means: "orange: this id is used more than once in the document" }];
  }

  // src/tools/dupid/report.js
  function report3({ el: el2 }) {
    if (!el2.id) return [];
    const n = document.querySelectorAll(`[id="${CSS.escape ? CSS.escape(el2.id) : el2.id}"]`).length;
    return n > 1 ? [`  ⧉ id "${el2.id}" is used ${n} times on this page`] : [];
  }

  // src/tools/dupid/rule.js
  var rules3 = {
    "dup-id": {
      help: "An id must be unique in a document.",
      why: "getElementById, label[for], aria-labelledby and every #anchor resolve to the first match and silently ignore the rest, so the bug shows up as a control that does nothing rather than an error.",
      docs: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/id"
    }
  };
  function auditPage(all) {
    const by = /* @__PURE__ */ new Map();
    for (const i of all) {
      const id = i.el.id;
      if (!id) continue;
      (by.get(id) || by.set(id, []).get(id)).push(i.el);
    }
    const out = [];
    for (const [id, els] of by) {
      if (els.length < 2) continue;
      out.push({
        el: els[0],
        verdict: "fail",
        // a broken label or anchor is a control that does nothing, and
        // nothing on screen says so
        severity: "error",
        rule: "dup-id",
        message: `id "${id}" is used ${els.length} times`,
        // by id, not by element: the duplicates are one mistake
        key: `dup-id|${id}`
      });
    }
    return out;
  }

  // src/tools/dupid/draw.js
  function draw4({ marks, found }) {
    marks(found);
  }

  // src/tools/dupid/index.js
  defineTool({
    // visuals owned by this tool — appended to the stylesheet at boot
    css: `
    .debug-overlay-badge .debug-overlay-dup { color: #ff8a65; font-weight: 700; }
    `,
    id: "dupid",
    // not ⧉ — the copy button already uses that glyph, and two identical
    // icons in one bar is a bar you have to read twice
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><line x1="4" x2="20" y1="9" y2="9" /><line x1="4" x2="20" y1="15" y2="15" /><line x1="10" x2="8" y1="3" y2="21" /><line x1="16" x2="14" y1="3" y2="21" /></svg>',
    // lucide 'hash' (ISC)
    // what this tool EXAMINES. A tool in a domain folder says it with
    // family:; one that owns its subject alone says it here, and every
    // tool must say it one way or the other — the side panel prints it
    // as a column, and a column is not a column if some rows are blank.
    subject: "ids",
    title: "Duplicate ids — the same id used more than once",
    badge: badge4,
    legend: legend4,
    compact: compact4,
    report: report3,
    rules: rules3,
    auditPage,
    draw: draw4
  });

  // src/tools/geometry/measure/badge.js
  function badge5(i) {
    const { el: el2, r, cs } = i;
    const dec = Tools.annotator(i);
    const on = (k) => Tools.setting(this, k);
    const bits = [];
    if (on("size")) bits.push(`<span class="debug-overlay-sz">${Math.round(r.width)}×${Math.round(r.height)}</span>`);
    if (on("radius")) {
      const rad = U.radius(cs);
      if (rad) bits.push(`<span class="debug-overlay-rad">r ${rad}</span>`);
    }
    if (on("padding")) {
      const p = U.four(cs, "padding", dec);
      if (p) bits.push(`<span class="debug-overlay-sp">p ${p.join(" ")}</span>`);
    }
    if (on("margin")) {
      const m = U.four(cs, "margin", dec);
      if (m) bits.push(`<span class="debug-overlay-sp">m ${m.join(" ")}</span>`);
    }
    if (on("layout") && (cs.display.includes("flex") || cs.display.includes("grid"))) {
      const g = U.px(cs.columnGap) || U.px(cs.gap);
      bits.push(`<span class="debug-overlay-sp">${U.esc(cs.display)}${g ? " gap " + U.mark(g, dec) : ""}</span>`);
    }
    if (on("font")) bits.push(`<span class="debug-overlay-fnt">${U.px(cs.fontSize)}/${U.px(cs.lineHeight) || "–"} ${cs.fontWeight}</span>`);
    if (on("tag")) bits.push(`<span class="debug-overlay-tag">${el2.tagName.toLowerCase()}${el2.id ? "#" + U.esc(el2.id) : ""}</span>`);
    return bits.join(" · ");
  }
  function compact5(i) {
    const { r, cs } = i;
    const dec = Tools.annotator(i);
    const on = (k) => Tools.setting(this, k);
    const bits = [];
    if (on("size")) bits.push(`<span class="debug-overlay-sz">${Math.round(r.width)}×${Math.round(r.height)}</span>`);
    if (on("radius")) {
      const rad = U.radius(cs);
      if (rad) bits.push(`<span class="debug-overlay-rad">r ${rad}</span>`);
    }
    if (on("padding")) {
      const p = U.four(cs, "padding", dec);
      if (p) bits.push(`<span class="debug-overlay-sp">p ${p.join(" ")}</span>`);
    }
    return bits.join(" · ");
  }
  function options() {
    return [
      { key: "size", label: "Size", def: true, type: "toggle", affects: "inspect" },
      { key: "radius", label: "Radius", def: true, type: "toggle", affects: "inspect" },
      { key: "padding", label: "Padding", def: true, type: "toggle", affects: "inspect" },
      { key: "margin", label: "Margin", def: true, type: "toggle", affects: "inspect" },
      { key: "layout", label: "Display & gap", def: true, type: "toggle", affects: "inspect" },
      { key: "font", label: "Font", def: true, type: "toggle", affects: "inspect" },
      { key: "tag", label: "Tag & id", def: true, type: "toggle", affects: "inspect" }
    ];
  }
  function legend5() {
    return [
      { mark: "92×24", means: "width × height, rounded" },
      { mark: "r 13", means: "border-radius" },
      { mark: "p / m", means: "padding / margin - top right bottom left, collapsed when equal" },
      { mark: "gap 12", means: "flex or grid gap" },
      { mark: "12/16 400", means: "font-size / line-height, weight" }
    ];
  }

  // src/tools/geometry/measure/report.js
  function report4({ r, cs }) {
    const pad = U.fourPlain(cs, "padding"), mar = U.fourPlain(cs, "margin");
    return [
      `  box: ${Math.round(r.width)}×${Math.round(r.height)} @ (${Math.round(r.left)}, ${Math.round(r.top)})`,
      `  padding: ${pad.t} ${pad.r} ${pad.b} ${pad.l} | margin: ${mar.t} ${mar.r} ${mar.b} ${mar.l} | radius: ${U.radius(cs) || 0}`,
      `  display: ${cs.display}${U.px(cs.gap) ? " gap:" + U.px(cs.gap) : ""} | position: ${cs.position} | overflow: ${cs.overflow}`,
      `  font: ${U.px(cs.fontSize)}px/${U.px(cs.lineHeight) || "normal"} ${cs.fontWeight} ${cs.fontFamily.split(",")[0]}`,
      `  color: ${cs.color} | bg: ${cs.backgroundColor}`
    ];
  }
  function reportTail2() {
    return this._pairs().map(([A, B]) => {
      const ra = A.el.getBoundingClientRect(), rb = B.el.getBoundingClientRect();
      const g = U.gap(ra, rb);
      const axis = Measure.axisOf(ra, rb);
      return `[#${A.id} → #${B.id}] ${axis.label}: ` + (axis.kind === "overlap" ? "elements overlap" : axis.kind === "diagonal" ? `horizontal ${g.dx}px + vertical ${g.dy}px` : `${axis.kind === "vertical" ? g.dy : g.dx}px`);
    });
  }

  // src/tools/geometry/measure/draw.js
  function draw5({ layer: layer2, Place: Place2 }) {
    Measure.resetLanes();
    for (const [A, B] of this._pairs()) {
      Measure.dimension(
        layer2,
        Place2,
        A.el.getBoundingClientRect(),
        B.el.getBoundingClientRect(),
        `#${A.id}→#${B.id}`
      );
    }
  }

  // src/tools/geometry/measure/index.js
  defineTool({
    // visuals owned by this tool — appended to the stylesheet at boot
    css: `
    .debug-overlay-leader { position: fixed; pointer-events: none; background: rgba(255,255,255,.55); }
    .debug-overlay-line { position: fixed; pointer-events: none; background: rgba(181,232,83,.85);
      border-radius: 1px; box-shadow: 0 0 0 .5px rgba(0,0,0,.4); }
    .debug-overlay-cap { position: fixed; pointer-events: none; background: var(--debug-overlay-accent);
      border-radius: 1px; box-shadow: 0 0 0 .5px rgba(0,0,0,.5); }
    .debug-overlay-arrow { position: fixed; pointer-events: none; width: 0; height: 0;
      filter: drop-shadow(0 0 .5px rgba(0,0,0,.6)); }
    .debug-overlay-arrow.debug-overlay-up    { border-left: 5px solid transparent; border-right: 5px solid transparent;
                         border-bottom: 7px solid var(--debug-overlay-accent); }
    .debug-overlay-arrow.debug-overlay-down  { border-left: 5px solid transparent; border-right: 5px solid transparent;
                         border-top: 7px solid var(--debug-overlay-accent); }
    .debug-overlay-arrow.debug-overlay-left  { border-top: 5px solid transparent; border-bottom: 5px solid transparent;
                         border-right: 7px solid var(--debug-overlay-accent); }
    .debug-overlay-arrow.debug-overlay-right { border-top: 5px solid transparent; border-bottom: 5px solid transparent;
                         border-left: 7px solid var(--debug-overlay-accent); }
    .debug-overlay-ext { position: fixed; pointer-events: none;
      background: repeating-linear-gradient(to right,
        rgba(181,232,83,.7) 0 4px, transparent 4px 8px); }
    .debug-overlay-ext.debug-overlay-v { background: repeating-linear-gradient(to bottom,
        rgba(181,232,83,.7) 0 4px, transparent 4px 8px); }
    .debug-overlay-dist { position: fixed; pointer-events: none;
      background: rgba(24,28,14,.95); color: var(--debug-overlay-accent); border-radius: var(--debug-overlay-r-inner);
      padding: 3px 8px; font-size: 12px; font-weight: 700; white-space: nowrap; }
    .debug-overlay-dist.debug-overlay-vert { border-left: 2px solid var(--debug-overlay-accent); }
    `,
    id: "measure",
    family: "geometry",
    // audited: must match the domain folder this sits in
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M13 7 8.7 2.7a2.41 2.41 0 0 0-3.4 0L2.7 5.3a2.41 2.41 0 0 0 0 3.4L7 13" /><path d="m8 6 2-2" /><path d="m18 16 2-2" /><path d="m17 11 4.3 4.3c.94.94.94 2.46 0 3.4l-2.6 2.6c-.94.94-2.46.94-3.4 0L11 17" /><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z" /><path d="m15 5 4 4" /></svg>',
    // lucide 'pencil-ruler' (ISC)
    title: "Measure — size, radius, spacing, font, distances",
    startsOn: true,
    // the read-out is what the overlay is FOR
    /**
     * A pair has a distance; a group of five does not have one distance.
     * Anything that is not two elements is something this tool has nothing
     * to say about, and it says so by drawing nothing rather than guessing
     * which two of them were meant.
     */
    _pairs: () => Tools.groups().filter((g) => g.length === 2),
    badge: badge5,
    legend: legend5,
    compact: compact5,
    options,
    report: report4,
    reportTail: reportTail2,
    draw: draw5
  });

  // src/tools/grid/service.js
  var Scale = defineSubject({
    id: "scale",
    was: "grid",
    // its settings lived under this id before the subject existed
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="m18 8 4 4-4 4" /><path d="M2 12h20" /><path d="m6 8-4 4 4 4" /></svg>',
    // lucide 'move-horizontal' (ISC) — scale is spacing, not the grid tool
    options() {
      return [
        // 2, not 4, because that is what the scale in front of us actually is:
        // Tailwind's default spacing has half-steps (0.5 = 2px, 1.5 = 6px) and
        // a real page used them 2,681 times. A rule has to check the scale a
        // project HAS; making the project match the rule is the wrong way round.
        {
          key: "step",
          label: "Grid step",
          def: CONFIG.GRID,
          values: [1, 2, 4, 8],
          suffix: "px",
          affects: "detect"
        },
        // Where a spacing token stops and layout arithmetic begins.
        // getComputedStyle resolves `margin: auto` to the pixels it worked out
        // — 1127px on a real page — and nothing distinguishes that from a value
        // somebody typed. Nobody types 1127px.
        {
          key: "max",
          label: "Ignore above",
          def: CONFIG.GRID_MAX,
          type: "number",
          min: 8,
          max: 2e3,
          step: 8,
          suffix: "px",
          affects: "detect"
        },
        // OFF, and it stays off by default: width and height are what layout
        // produced, not what anyone typed, and judging them turned one real
        // signal into 2,215 findings about icon geometry on a real page.
        {
          key: "boxes",
          label: "Judge width & height",
          def: false,
          type: "toggle",
          affects: "detect"
        }
      ];
    },
    step() {
      return Tools.setting(this, "step");
    },
    max() {
      return Tools.setting(this, "max");
    },
    boxes() {
      return Tools.setting(this, "boxes");
    },
    /** 0 is never off the grid, or every padding:0 would light up. */
    off(n) {
      const step = this.step();
      return n !== 0 && n % step !== 0;
    },
    /**
     * Off the grid AND close enough to be something somebody typed.
     *
     * The ceiling used to live only in the rule, so a resolved `margin: auto`
     * of 1127px got a ⚠ on the badge and no finding in the sweep — the badge
     * and the audit disagreeing about one number, which is the exact
     * contradiction this subject exists to make impossible. Every consumer
     * asks this, so there is one answer.
     */
    judges(n) {
      return this.off(n) && Math.abs(n) <= this.max();
    },
    /**
     * The nearest value that WOULD pass — the RECOMMENDATION facet's answer.
     *
     * On the subject, not in the lens, for the same reason judges() is: the
     * ⚠ and the →8 must come from one place or they could disagree about the
     * same number. Half away from zero, matching U.px, so 7 on a 2px step
     * suggests 8 and -7 suggests -8 — a margin and its mirror image get
     * mirror advice.
     */
    nearest(n) {
      const step = this.step();
      return Math.sign(n) * Math.round(Math.abs(n) / step) * step;
    },
    /**
     * Off-grid numbers on one element, as [name, value] pairs. `boxes` adds
     * width and height — true when somebody pointed at this element and asked,
     * false when a sweep is judging the page.
     */
    scan(info, boxes) {
      const cs = info.cs;
      const pad = U.fourPlain(cs, "padding"), mar = U.fourPlain(cs, "margin");
      const out = [];
      const check = (n, v) => {
        if (this.judges(v)) out.push([n, v]);
      };
      if (boxes) {
        const r = info.r;
        const box = (n, v) => {
          if (this.off(v)) out.push([n, v]);
        };
        box("w", Math.round(r.width));
        box("h", Math.round(r.height));
      }
      ["t", "r", "b", "l"].forEach((k) => {
        check("pad-" + k, pad[k]);
        check("mar-" + k, mar[k]);
      });
      const row = U.px(cs.rowGap), col = U.px(cs.columnGap);
      if (row || col) {
        if (row) check("gap-row", row);
        if (col) check("gap-col", col);
      } else {
        const gap = U.px(cs.gap);
        if (gap) check("gap", gap);
      }
      return out;
    }
  });

  // src/tools/grid/badge.js
  function badge6(i) {
    const bad = Scale.scan(i, true);
    if (!bad.length) return null;
    const vals = [...new Set(bad.map(([, v]) => v))];
    return `<span class="debug-overlay-warn">⚠ ${vals.join(" ")} off ${Scale.step()}px</span>`;
  }
  function compact6(i) {
    const bad = Scale.scan(i, true);
    return bad.length ? `<span class="debug-overlay-warn">⚠${bad.length}</span>` : null;
  }
  function legend6() {
    return [
      { mark: "7⚠", means: "amber: this number is off the spacing step" },
      { mark: "7⚠→8", means: "the nearest on-step value - the Recommendation facet" }
    ];
  }

  // src/tools/grid/lens.js
  function annotate(html, n, info) {
    if (!Scale.judges(n)) return html;
    const fix = info?.facets?.suggest ? `→${Scale.nearest(n)}` : "";
    return `<span class="debug-overlay-warn">${html}⚠${fix}</span>`;
  }

  // src/tools/grid/report.js
  function report5(i) {
    const bad = Scale.scan(i, true);
    return bad.length ? [`  ⚠ off ${Scale.step()}px grid: ${bad.map(([n, v]) => `${n}:${v}`).join(", ")}`] : [];
  }

  // src/tools/grid/rule.js
  var rules4 = {
    "grid-off": {
      help: "Spacing should be a multiple of the grid step — change which step this checks in the panel under ⚙.",
      why: "One-off values are how a spacing scale erodes: each looks harmless alone, and together they are why nothing lines up."
    }
  };
  function audit3(i) {
    if (!(i.el instanceof HTMLElement)) return [];
    return Scale.scan(i, Scale.boxes()).map(([n, v]) => ({
      el: i.el,
      verdict: "fail",
      // a spacing system is a convention, not a rule anyone can be hurt
      // by breaking — it ranks below anything a reader actually suffers
      severity: "info",
      rule: "grid-off",
      // the VALUE, not the side it appeared on: these group by value, and
      // "pad-t ×24" would read as 24 top paddings when it is one number
      // used in twenty-four places. The sides are in the per-pin report.
      message: `${v}px is off the ${Scale.step()}px grid`,
      key: `grid-off|${v}`
    }));
  }

  // src/tools/grid/draw.js
  function draw6({ marks, found }) {
    marks(found);
  }

  // src/tools/grid/index.js
  defineTool({
    id: "grid",
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><rect width="18" height="18" x="3" y="3" rx="2" /><path d="M3 9h18" /><path d="M3 15h18" /><path d="M9 3v18" /><path d="M15 3v18" /></svg>',
    // lucide 'grid-3x3' (ISC)
    // No number in the title: the step is the user's now, and a title baked
    // at boot would still be claiming 2px long after they picked 8.
    // what this tool EXAMINES. A tool in a domain folder says it with
    // family:; one that owns its subject alone says it here, and every
    // tool must say it one way or the other — the side panel prints it
    // as a column, and a column is not a column if some rows are blank.
    subject: "spacing",
    title: "Grid — flag values off the spacing grid",
    startsOn: true,
    // the ⚠ on a badge is what makes the read-out useful
    uses: [Scale],
    // its settings are Scale's, and belong on its own menu
    badge: badge6,
    legend: legend6,
    compact: compact6,
    annotate,
    report: report5,
    rules: rules4,
    audit: audit3,
    draw: draw6
    // no options of its own any more: 'Suggest nearest step' was the
    // RECOMMENDATION facet wearing this tool's name, and it moved to the
    // badge face (was: 'grid' there adopts what anyone saved). The step
    // and ceiling were never grid's either — they are Scale's, reached
    // through uses: above.
  });

  // src/tools/input/group/service.js
  function groups() {
    return this._form().groups;
  }
  function pendingIndex() {
    const { pending } = this._form();
    return pending ? State.pins.indexOf(pending) : -1;
  }
  function gestures2() {
    return [{
      keys: "Ctrl/⌘+Shift+click",
      does: "chain to the previous pin — repeat for ①─②─③"
    }];
  }

  // src/tools/input/group/form.js
  function form(pins) {
    const K = CONFIG.PIN_KIND;
    const sel = pins.filter((p) => p.kind === K.SHIFT || p.kind === K.CHAIN);
    const runs = [];
    for (const p of sel) {
      const last2 = runs[runs.length - 1];
      if (last2 && (p.kind === K.CHAIN || last2.length === 1)) last2.push(p);
      else runs.push([p]);
    }
    const groups2 = [];
    for (const run of runs)
      for (let k = 0; k + 1 < run.length; k++) groups2.push([run[k], run[k + 1]]);
    const lastRun = runs[runs.length - 1];
    const pending = lastRun && lastRun.length === 1 ? lastRun[0] : null;
    return { groups: groups2, pending };
  }

  // src/tools/input/group/rows.js
  function listRows() {
    const { groups: groups2, pending } = this._form();
    const rows = groups2.map(([A, B]) => {
      const ra = A.el.getBoundingClientRect(), rb = B.el.getBoundingClientRect();
      const g = U.gap(ra, rb);
      const axis = Measure.axisOf(ra, rb);
      const detail = axis.kind === "overlap" ? "overlapping" : axis.kind === "diagonal" ? `→ ${g.dx} · ↓ ${g.dy} px` : axis.kind === "vertical" ? `↕ ${g.dy} px` : `↔ ${g.dx} px`;
      return {
        tag: `#${A.id}→#${B.id}`,
        label: `${U.labelOf(A.el)} ↔ ${U.labelOf(B.el)}`,
        detail,
        pins: [A, B]
      };
    });
    if (pending) rows.push({
      tag: `#${pending.id}…`,
      label: U.labelOf(pending.el),
      detail: "pick its pair, or chain to it",
      pins: [pending]
    });
    return rows;
  }
  function reportTail3() {
    const { pending } = this._form();
    return pending ? [`[#${pending.id}] waiting for its pair`] : [];
  }

  // src/tools/input/group/index.js
  defineTool({
    id: "group",
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M5 3a2 2 0 0 0-2 2" /><path d="M19 3a2 2 0 0 1 2 2" /><path d="M21 19a2 2 0 0 1-2 2" /><path d="M5 21a2 2 0 0 1-2-2" /><path d="M9 3h1" /><path d="M9 21h1" /><path d="M14 3h1" /><path d="M14 21h1" /><path d="M3 9v1" /><path d="M21 9v1" /><path d="M3 14v1" /><path d="M21 14v1" /></svg>',
    // lucide 'box-select' (ISC)
    family: "input",
    // audited: must match the domain folder this sits in
    title: "Group — how pinned elements pair and chain",
    startsOn: true,
    /** The single place grouping is decided — see form.js. */
    _form() {
      return form(State.pins);
    },
    groups,
    pendingIndex,
    gestures: gestures2,
    listRows,
    reportTail: reportTail3
  });

  // src/tools/input/lasso/inside.js
  var REACH = {
    /** Entirely inside it. What a marquee usually means, and useless for an
     *  element bigger than the drag — or bigger than the viewport. */
    enclosed: (r, b) => b.left >= r.left && b.right <= r.right && b.top >= r.top && b.bottom <= r.bottom,
    /** Overlapping it at all, down to one pixel. This is how you take something
     *  large by dragging INSIDE it, which enclosed can never do. */
    touched: (r, b) => !(r.right < b.left || r.left > b.right || r.bottom < b.top || r.top > b.bottom)
  };
  var KEEP = {
    /* A rectangle over one card matches the card AND every node inside it — on
       a real page dozens of pins for one drag, with the one you wanted buried
       among them. Dropping anything whose ancestor also matched leaves "the
       things in this region". Under `touched` this reads differently and says
       so: every ancestor up to <body> overlaps, so outermost returns the
       outermost of THOSE — one page wrapper. That is a true answer to a
       question few people are asking, which is why it is not the default. */
    outermost: (hit, taken) => hit.filter((el2) => {
      for (let e = el2.parentElement; e; e = e.parentElement) if (taken.has(e)) return false;
      return true;
    }),
    /* The deepest matches — nothing kept that has a match inside it. Paired
       with `touched` this is the answer for a large element: drag inside the
       wallpaper and the wallpaper is the deepest thing the box reaches, while
       every wrapper above it is dropped for having a matched child. */
    deepest: (hit, taken) => hit.filter((el2) => ![...el2.children].some((c) => taken.has(c))),
    /** The honest raw answer, pruned by nothing. */
    every: (hit) => hit
  };
  function inside(rect, { keep, reach } = {}) {
    let all = [];
    try {
      all = document.body ? [...document.body.querySelectorAll("*")] : [];
    } catch {
      return [];
    }
    const ours = document.getElementById(CONFIG.ROOT_ID);
    const fits = REACH[reach] || REACH.enclosed;
    const hit = [];
    for (const el2 of all) {
      if (ours && (el2 === ours || ours.contains(el2))) continue;
      const b = el2.getBoundingClientRect();
      if (!b.width || !b.height) continue;
      if (fits(rect, b)) hit.push(el2);
    }
    return (KEEP[keep] || KEEP.outermost)(hit, new Set(hit));
  }
  var modeOf = (tool2) => ({
    keep: Tools.setting(tool2, "take"),
    reach: Tools.setting(tool2, "reach")
  });

  // src/tools/input/lasso/drag.js
  var Drag = {
    from: null,
    // page coords where the press landed
    rect: null,
    // the live rectangle in viewport coords, or null
    drew: false,
    // a rectangle was completed — the click that follows is ours
    _ctx: null,
    /** Viewport rect from two page points, normalised so either drag direction
     *  gives the same box. */
    box(a, b) {
      return {
        left: Math.min(a.px, b.px) - scrollX,
        right: Math.max(a.px, b.px) - scrollX,
        top: Math.min(a.py, b.py) - scrollY,
        bottom: Math.max(a.py, b.py) - scrollY
      };
    }
  };
  function watch2(ctx) {
    Drag._ctx = ctx;
    const page = (e) => !!(document.body && document.body.contains(e.target));
    Drag._down = (e) => {
      if (!State.enabled || e.button !== 0 || e.altKey || !page(e)) return;
      Drag.from = { px: e.clientX + scrollX, py: e.clientY + scrollY };
      Drag.rect = null;
      Drag.drew = false;
    };
    Drag._move = (e) => {
      if (!Drag.from) return;
      const now = { px: e.clientX + scrollX, py: e.clientY + scrollY };
      if (!Drag.rect && Math.hypot(now.px - Drag.from.px, now.py - Drag.from.py) < CONFIG.LASSO_MIN) return;
      Drag.rect = Drag.box(Drag.from, now);
      ctx.redraw?.();
    };
    Drag._up = () => {
      const r = Drag.rect;
      Drag.from = null;
      Drag.rect = null;
      if (!r) return;
      Drag.drew = true;
      const els = inside(r, modeOf(Drag.tool));
      ctx.pin?.(els);
      ctx.redraw?.();
    };
    addEventListener("pointerdown", Drag._down, true);
    addEventListener("pointermove", Drag._move, true);
    addEventListener("pointerup", Drag._up, true);
    addEventListener("blur", Drag._up);
  }
  function unwatch2() {
    removeEventListener("pointerdown", Drag._down, true);
    removeEventListener("pointermove", Drag._move, true);
    removeEventListener("pointerup", Drag._up, true);
    removeEventListener("blur", Drag._up);
    Drag.from = Drag.rect = null;
    Drag.drew = false;
    Drag._ctx = null;
  }
  function intercept({ type }) {
    if (type !== "click" || !Drag.drew) return false;
    Drag.drew = false;
    return true;
  }

  // src/tools/input/lasso/draw.js
  function draw7({ layer: layer2, Place: Place2 }) {
    const r = Drag.rect;
    if (!r) return;
    const box = document.createElement("div");
    box.className = "debug-overlay-lasso";
    Place2.put(box, r.left, r.top, Math.max(1, r.right - r.left), Math.max(1, r.bottom - r.top));
    layer2.append(box);
  }

  // src/tools/input/lasso/index.js
  var tool = defineTool({
    css: `
  .debug-overlay-lasso { position: fixed; pointer-events: none;
    border: 1px solid var(--debug-overlay-accent);
    background: rgba(181,232,83,.10); border-radius: var(--debug-overlay-r-inner); }
  `,
    id: "lasso",
    family: "input",
    // audited: must match the domain folder this sits in
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11V8a2 2 0 0 0-2-2h-6l-2-2H5a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h3"/><path d="M14 13v8"/><path d="M10 17h8"/></svg>',
    // lucide 'folder-plus' turned marquee
    title: "Lasso — drag a box and keep everything inside it",
    /* NOT startsOn. Every click on the page already means something, and a
       gesture that reinterprets drags is not one to switch on for somebody who
       did not ask for it. */
    watch: watch2,
    unwatch: unwatch2,
    intercept,
    draw: draw7,
    /**
     * THE DECLARATION THAT CANNOT BE DERIVED. Everything else this tool
     * implements is generic — a runtime, a claim on one click, a rectangle —
     * and none of it says the product is PINS. Without this the role came out
     * Act, off the `intercept` that exists only to swallow the click its own
     * drag caused, and the panel dressed a selection tool as a component.
     */
    selects() {
      return true;
    },
    /**
     * WHAT A BOX TAKES — two questions, and they are independent.
     *
     * REACH is which boxes count. `enclosed` is what a marquee usually means
     * and it cannot take anything bigger than the drag: a full-width wallpaper
     * is unreachable, because enclosing it means dragging a box around it, and
     * it may be larger than the viewport. `touched` takes anything the box
     * overlaps at all, down to one pixel, so a big element is taken by dragging
     * INSIDE it.
     *
     * KEEP is which of those survive, and it is a separate axis because under
     * `touched` every ancestor up to <body> overlaps too. These shipped as one
     * four-valued setting, which made choosing overlap also mean "prune
     * nothing" — every wrapper between <body> and the thing you wanted.
     *
     * `touched` + `deepest` is the pairing for a large element, and neither
     * half of it can be said with one setting.
     */
    options() {
      return [
        {
          key: "reach",
          label: "A box takes what it",
          def: "enclosed",
          values: ["enclosed", "touched"],
          affects: "select"
        },
        {
          key: "take",
          label: "…and keeps the",
          def: "outermost",
          values: ["outermost", "deepest", "every"],
          affects: "select"
        }
      ];
    },
    /** The gesture this adds — declared where it lives, so the KEYS legend
     *  learns it without any core file holding a list. */
    gestures() {
      return [{
        keys: "Drag on the page (▭ armed)",
        does: "keep everything the box takes — including what a click cannot reach"
      }];
    }
  });
  Drag.tool = tool;

  // src/tools/input/pin/keep.js
  function keeps() {
    return true;
  }

  // src/tools/input/pin/index.js
  defineTool({
    id: "pin",
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M12 17v5" /><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z" /></svg>',
    // lucide 'pin' (ISC)
    family: "input",
    // audited: must match the domain folder this sits in
    title: "Pin — keep what you select; off, selections replace each other",
    startsOn: true,
    keeps
  });

  // src/tools/perf/target.js
  var Targets = {
    map: /* @__PURE__ */ new Map(),
    // el -> { mo, times: [ts…], worstEvt, shift }
    /** Rolling mutations/second over the rate window. */
    rate(el2) {
      const t = Targets.map.get(el2);
      if (!t) return null;
      const cut = Date.now() - CONFIG.PERF.RATE_WINDOW;
      while (t.times.length && t.times[0] < cut) t.times.shift();
      return Math.round(t.times.length * 1e3 / CONFIG.PERF.RATE_WINDOW);
    },
    /** Mutations inside [from, to] — the freeze-correlation question. */
    countIn(el2, from, to) {
      const t = Targets.map.get(el2);
      if (!t) return 0;
      return t.times.reduce((n, ts) => n + (ts >= from && ts <= to ? 1 : 0), 0);
    },
    stats(el2) {
      const t = Targets.map.get(el2);
      if (!t) return null;
      return { rate: Targets.rate(el2), worstEvt: t.worstEvt, shift: t.shift };
    },
    /** Reconcile with what is targeted NOW. Cheap: pins are user-made
     *  and few, and this only ever attaches/detaches the difference. */
    sync(els) {
      const want = new Set(els.filter((el2) => el2 && document.contains(el2)));
      for (const [el2, t] of Targets.map) {
        if (want.has(el2)) continue;
        t.mo.disconnect();
        Targets.map.delete(el2);
      }
      for (const el2 of want) {
        if (Targets.map.has(el2)) continue;
        const rec = { mo: null, times: [], worstEvt: null, shift: 0 };
        rec.mo = new MutationObserver((muts) => {
          const now = Date.now();
          for (let i = 0; i < muts.length; i++) rec.times.push(now);
          const cut = now - CONFIG.PERF.RATE_WINDOW;
          while (rec.times.length && rec.times[0] < cut) rec.times.shift();
        });
        rec.mo.observe(el2, {
          subtree: true,
          childList: true,
          attributes: true,
          characterData: true
        });
        Targets.map.set(el2, rec);
      }
    },
    /** A slow-input or layout-shift entry, attributed if its node sits
     *  inside a watched subtree. Called by service.js's observers. */
    attribute(node, kind, value) {
      if (!node) return;
      for (const [el2, t] of Targets.map) {
        if (el2 !== node && !el2.contains(node)) continue;
        if (kind === "event" && value > (t.worstEvt || 0)) t.worstEvt = value;
        if (kind === "shift") t.shift += value;
      }
    },
    clear() {
      for (const [, t] of Targets.map) t.mo.disconnect();
      Targets.map.clear();
    }
  };

  // src/tools/perf/service.js
  var Monitor = {
    running: false,
    tier: null,
    // 'frame-attribution' | 'long-tasks' | 'heartbeat'
    log: [],
    // ring buffer, oldest first: { t, ms, src, via }
    fps: null,
    // rolling frames-per-second, null until measured
    startedAt: 0,
    _owner: null,
    // the tool, for Tools.setting — set by watch()
    _obs: null,
    _obs2: [],
    _raf: 0,
    _last: 0,
    _frames: 0,
    _fpsT: 0,
    _onVis: null,
    _redraw: null,
    _drewT: 0,
    _watch: [],
    _watchT: 0,
    // what is targeted, and when it was last re-derived
    load: null,
    // this navigation's timings — static per page
    pre: [],
    // long tasks from BEFORE arming (buffered entries)
    threshold() {
      const v = Monitor._owner && Tools.setting(Monitor._owner, "freeze");
      return Number(v) || CONFIG.PERF.FREEZE_MS;
    },
    push(ev) {
      let worst = null;
      for (const [el2] of Targets.map) {
        const n = Targets.countIn(el2, ev.t - ev.ms, ev.t);
        if (n && (!worst || n > worst.n)) worst = { el: el2, n };
      }
      if (worst) ev.blame = `${U.labelOf(worst.el)} ×${worst.n}`;
      Monitor.log.push(ev);
      if (Monitor.log.length > CONFIG.PERF.LOG_MAX) Monitor.log.shift();
      Monitor._event?.({
        kind: "freeze",
        at: Math.round(performance.now()),
        ms: ev.ms,
        via: ev.via,
        blame: ev.blame || null
      });
    },
    worst() {
      return Monitor.log.reduce((m, e) => Math.max(m, e.ms), 0);
    },
    start(owner, ctx) {
      if (Monitor.running) return;
      Monitor.running = true;
      Monitor._owner = owner;
      Monitor._redraw = ctx?.redraw || null;
      Monitor._event = ctx?.event || null;
      Monitor.log = [];
      Monitor.fps = null;
      Monitor.startedAt = Date.now();
      Monitor._armedAtPerf = performance.now();
      Monitor.pre = [];
      Monitor.load = readLoad();
      const types = typeof PerformanceObserver !== "undefined" && PerformanceObserver.supportedEntryTypes || [];
      const classify = (e, src) => {
        if (e.startTime + e.duration <= Monitor._armedAtPerf) {
          Monitor.pre.push({ ms: Math.round(e.duration), src });
          if (Monitor.pre.length > 10) Monitor.pre.shift();
        } else if (e.duration >= Monitor.threshold()) {
          Monitor.push({
            t: Date.now(),
            ms: Math.round(e.duration),
            src,
            via: src ? "frame" : "task"
          });
        }
      };
      if (types.includes("long-animation-frame")) {
        Monitor.tier = "frame-attribution";
        Monitor._obs = new PerformanceObserver((list) => {
          for (const e of list.getEntries()) {
            const s = e.scripts && e.scripts[0];
            const src = s && (s.sourceURL || s.invoker || s.name) || null;
            classify(e, src && String(src).split("/").pop().split("?")[0]);
          }
        });
        Monitor._obs.observe({ type: "long-animation-frame", buffered: true });
      } else if (types.includes("longtask")) {
        Monitor.tier = "long-tasks";
        Monitor._obs = new PerformanceObserver((list) => {
          for (const e of list.getEntries()) classify(e, null);
        });
        Monitor._obs.observe({ type: "longtask", buffered: true });
      } else {
        Monitor.tier = "heartbeat";
      }
      Monitor._obs2 = [];
      if (types.includes("event")) {
        const o = new PerformanceObserver((list) => {
          for (const e of list.getEntries())
            Targets.attribute(e.target, "event", Math.round(e.duration));
        });
        o.observe({ type: "event", durationThreshold: 104 });
        Monitor._obs2.push(o);
      }
      if (types.includes("layout-shift")) {
        const o = new PerformanceObserver((list) => {
          for (const e of list.getEntries())
            for (const s of e.sources || [])
              Targets.attribute(s.node, "shift", e.value);
        });
        o.observe({ type: "layout-shift" });
        Monitor._obs2.push(o);
      }
      Monitor._onVis = () => {
        Monitor._last = 0;
        Monitor._frames = 0;
        Monitor._fpsT = 0;
      };
      document.addEventListener("visibilitychange", Monitor._onVis);
      const tick = (t) => {
        if (!Monitor.running) return;
        if (Monitor._last) {
          const gap = t - Monitor._last;
          Monitor._frames++;
          if (t - Monitor._fpsT >= CONFIG.PERF.FPS_WINDOW) {
            Monitor.fps = Math.round(Monitor._frames * 1e3 / (t - Monitor._fpsT));
            Monitor._frames = 0;
            Monitor._fpsT = t;
          }
          if (Monitor.tier === "heartbeat" && gap >= Monitor.threshold() && document.visibilityState === "visible") {
            Monitor.push({ t: Date.now(), ms: Math.round(gap), src: null, via: "heartbeat" });
          }
        } else {
          Monitor._fpsT = t;
        }
        Monitor._last = t;
        const pins = State.pins;
        let same = Monitor._watch.length === pins.length + 1 && Monitor._watch[pins.length] === State.current;
        for (let i = 0; same && i < pins.length; i++)
          same = Monitor._watch[i] === pins[i].el;
        if (!same || t - Monitor._watchT >= CONFIG.PERF.RESYNC) {
          Monitor._watchT = t;
          Monitor._watch = [...pins.map((p) => p.el), State.current];
          Targets.sync(Monitor._watch);
        }
        if (Monitor._redraw && t - (Monitor._drewT || 0) >= 500 && (Targets.map.size || Monitor.log.length || State.hoverEl)) {
          Monitor._drewT = t;
          Monitor._redraw();
        }
        Monitor._raf = requestAnimationFrame(tick);
      };
      Monitor._raf = requestAnimationFrame(tick);
    },
    stop() {
      if (!Monitor.running) return;
      Monitor.running = false;
      Monitor._event = null;
      Monitor._obs?.disconnect();
      Monitor._obs = null;
      Monitor._obs2.forEach((o) => o.disconnect());
      Monitor._obs2 = [];
      Targets.clear();
      cancelAnimationFrame(Monitor._raf);
      document.removeEventListener("visibilitychange", Monitor._onVis);
      Monitor._last = 0;
    }
  };
  function fmt(ms) {
    return ms < 1e3 ? `${ms}ms` : `${(ms / 1e3).toFixed(1)}s`;
  }
  function watch3(ctx) {
    Monitor.start(this, ctx);
  }
  function unwatch3() {
    Monitor.stop();
  }
  function readLoad() {
    try {
      const nav = performance.getEntriesByType?.("navigation")?.[0];
      if (!nav) return null;
      const fcp = performance.getEntriesByType?.("paint")?.find((e) => e.name === "first-contentful-paint");
      return {
        server: Math.round(nav.responseStart - nav.startTime),
        dom: Math.round(nav.domContentLoadedEventEnd - nav.startTime),
        done: nav.loadEventEnd ? Math.round(nav.loadEventEnd - nav.startTime) : null,
        fcp: fcp ? Math.round(fcp.startTime) : null
      };
    } catch {
      return null;
    }
  }
  function timeline() {
    const out = [];
    const load = Monitor.load || readLoad();
    if (load) out.push({ kind: "load", at: 0, ...load });
    for (const p of Monitor.pre) out.push({ kind: "pre", at: null, ms: p.ms, src: p.src || null });
    const navStart = Date.now() - performance.now();
    for (const e of Monitor.log) {
      out.push({
        kind: "freeze",
        at: Math.max(0, Math.round(e.t - navStart)),
        ms: e.ms,
        via: e.via,
        blame: e.blame || null
      });
    }
    return out;
  }

  // src/tools/perf/badge.js
  function badge7(i) {
    if (!Monitor.running) return null;
    const s = Targets.stats(i.el);
    if (s) {
      const churn = Number(Tools.setting(this, "churn")) || CONFIG.PERF.CHURN;
      const mut = s.rate >= churn ? `<span class="debug-overlay-warn">mut ${s.rate}/s</span>` : `mut ${s.rate}/s`;
      const bits = [`⚡ ${mut}`];
      if (s.worstEvt) bits.push(`resp ${fmt(s.worstEvt)}`);
      if (s.shift > 5e-3) bits.push(`shift ${s.shift.toFixed(2)}`);
      return `<span class="debug-overlay-sp">${bits.join(" · ")}</span>`;
    }
    const fps = Monitor.fps == null ? "–" : Monitor.fps;
    const n = Monitor.log.length;
    return `<span class="debug-overlay-sp">⚡ ${fps}fps</span>` + (n ? ` <span class="debug-overlay-warn">${n}× worst ${fmt(Monitor.worst())}</span>` : "");
  }
  function compact7(i) {
    if (!Monitor.running) return null;
    const s = Targets.stats(i.el);
    const churn = Number(Tools.setting(this, "churn")) || CONFIG.PERF.CHURN;
    if (s && s.rate >= churn) return `<span class="debug-overlay-warn">⚡mut ${s.rate}/s</span>`;
    if (!s && Monitor.log.length) return `<span class="debug-overlay-warn">⚡${fmt(Monitor.worst())}</span>`;
    return null;
  }
  function legend7() {
    return [
      { mark: "⚡ 58fps", means: "the PAGE, not this element: frames per second while monitoring" },
      { mark: "⚡1.2s", means: "amber: the longest main-thread freeze since arming" },
      { mark: "⚡ mut 140/s", means: "a PINNED element: DOM mutations per second under it — a re-render storm reads in the hundreds" },
      { mark: "resp 380ms", means: "the slowest input this element answered (where the browser reports it)" },
      { mark: "shift 0.02", means: "layout shift this element caused (where the browser reports it)" }
    ];
  }

  // src/tools/perf/rows.js
  function listRows2() {
    const now = Date.now();
    const ago = (t) => {
      const s = Math.round((now - t) / 1e3);
      return s < 60 ? `${s}s ago` : `${Math.round(s / 60)}m ago`;
    };
    return Monitor.log.slice().reverse().map((e) => ({
      tag: "⚡",
      label: `main thread blocked ${fmt(e.ms)}`,
      detail: `${ago(e.t)}${e.src ? " · " + e.src : ""}${e.blame ? " · during: " + e.blame : ""}`
    }));
  }
  function reportTail4() {
    if (!Monitor.running && !Monitor.log.length) return [];
    const secs = Math.round((Date.now() - Monitor.startedAt) / 1e3);
    const L = [`## performance — monitored ${secs}s · tier: ${Monitor.tier}`];
    L.push(Monitor.fps == null ? "fps: (no full window yet)" : `fps: ${Monitor.fps}`);
    if (!Monitor.log.length) {
      L.push(`main thread: no blocks over the threshold`);
    } else {
      const srcs = [...new Set(Monitor.log.map((e) => e.src).filter(Boolean))];
      L.push(`main thread: ${Monitor.log.length} block${Monitor.log.length === 1 ? "" : "s"}, worst ${fmt(Monitor.worst())}` + (srcs.length ? ` — ${srcs.join(", ")}` : ""));
      if (Monitor.tier !== "frame-attribution") {
        L.push("(no script attribution on this browser — Chrome reports which script ate the frame)");
      }
      const blamed = Monitor.log.filter((e) => e.blame);
      for (const e of blamed.slice(-3))
        L.push(`  during the ${fmt(e.ms)} block: ${e.blame} mutations`);
    }
    for (const [el2] of Targets.map) {
      const s = Targets.stats(el2);
      if (!s || !document.contains(el2)) continue;
      const bits = [`mut ${s.rate}/s`];
      if (s.worstEvt) bits.push(`worst input ${fmt(s.worstEvt)}`);
      if (s.shift > 5e-3) bits.push(`layout shift ${s.shift.toFixed(2)}`);
      L.push(`watched ${U.selectorOf(el2)}: ${bits.join(" · ")}`);
    }
    if (Monitor.load || Monitor.pre.length) {
      L.push("", "## load — this navigation");
      const ld = Monitor.load;
      if (ld) {
        const bits = [`server ${fmt(ld.server)}`, `DOM ready ${fmt(ld.dom)}`];
        if (ld.done) bits.push(`loaded ${fmt(ld.done)}`);
        if (ld.fcp) bits.push(`first paint ${fmt(ld.fcp)}`);
        L.push(bits.join(" · "));
      }
      if (Monitor.pre.length) {
        const worst = Monitor.pre.reduce((m, e) => e.ms > m.ms ? e : m);
        L.push(`${Monitor.pre.length} long task${Monitor.pre.length === 1 ? "" : "s"} before arming, worst ${fmt(worst.ms)}` + (worst.src ? ` (${worst.src})` : ""));
      }
    }
    return L;
  }

  // src/tools/perf/rule.js
  function audit4(i) {
    if (!Monitor.running) return [];
    const s = Targets.stats(i.el);
    if (!s) return [];
    const out = [];
    const churn = Number(Tools.setting(this, "churn")) || CONFIG.PERF.CHURN;
    if (s.rate >= churn) {
      out.push({
        el: i.el,
        verdict: "fail",
        severity: "warn",
        rule: "perf-churn",
        message: `${s.rate} mutations/s under this element — a re-render storm`,
        key: `perf-churn:${s.rate}`
      });
    }
    if (s.worstEvt && s.worstEvt >= Monitor.threshold()) {
      out.push({
        el: i.el,
        verdict: "fail",
        severity: "warn",
        rule: "perf-input",
        message: `an input on this element took ${fmt(s.worstEvt)} to answer`,
        key: `perf-input:${s.worstEvt}`
      });
    }
    return out;
  }
  var rules5 = {
    "perf-churn": {
      help: "DOM mutations per second under a watched element, against the churn threshold in ⚙. Only elements you pinned or selected are watched, and only while ⚡ is armed.",
      why: "A component mutating the DOM hundreds of times a second is re-rendering in a loop — work the user cannot see, spent heating the main thread. It is the most common way one component eats a page."
    },
    "perf-input": {
      help: "The slowest input event a watched element answered, against the freeze threshold in ⚙. Reported where the browser supports the Event Timing API.",
      why: "An input that takes hundreds of milliseconds to answer is the stutter a user actually feels — and it names the component responsible, which a page-wide freeze cannot."
    }
  };

  // src/tools/perf/draw.js
  function draw8({ marks, found }) {
    marks(found);
  }

  // src/tools/perf/index.js
  defineTool({
    id: "perf",
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /></svg>',
    // lucide 'activity' (ISC)
    // what this tool EXAMINES. A tool in a domain folder says it with
    // family:; one that owns its subject alone says it here, and every
    // tool must say it one way or the other — the side panel prints it
    // as a column, and a column is not a column if some rows are blank.
    subject: "time",
    title: "Perf — freezes and jank while armed; the badge shows the page's pulse",
    startsOn: false,
    watch: watch3,
    unwatch: unwatch3,
    timeline,
    badge: badge7,
    compact: compact7,
    legend: legend7,
    listRows: listRows2,
    reportTail: reportTail4,
    audit: audit4,
    rules: rules5,
    draw: draw8,
    options() {
      return [
        {
          key: "freeze",
          label: "Freeze threshold",
          def: CONFIG.PERF.FREEZE_MS,
          type: "number",
          min: 100,
          max: 5e3,
          step: 50,
          suffix: "ms",
          affects: "detect"
        },
        {
          key: "churn",
          label: "Churn threshold",
          def: CONFIG.PERF.CHURN,
          type: "number",
          min: 10,
          max: 1e3,
          step: 10,
          suffix: "/s",
          affects: "detect"
        }
      ];
    }
  });

  // src/ui/styles.js
  var CSS2 = `
    /* ======================================================================
       TOKENS — the design system this file did not have.

       Audited: 47 distinct colour literals in this sheet alone and 23
       distinct dark neutrals across the four surfaces, for what are really
       a handful of roles. Two of them, #3a3a40 and #3a3a41, differ by one
       digit and do the same job — nobody chose that, each call site
       invented its own. Named here once, used everywhere below.

       Declared on our OWN root, never :root — a page's custom properties
       must not reach in, and ours must not leak out. Same reason every
       class carries the namespace.
       ====================================================================== */
    #__debug-overlay-root {
      --debug-overlay-accent: #b5e853;      /* armed · success · primary */
      --debug-overlay-on-accent: #1a1a1a;   /* text ON accent */
      --debug-overlay-warn: #ffd54f;        /* asks for a decision */
      --debug-overlay-danger: #ff5c5c;      /* destructive · failure */
      --debug-overlay-info: #58c4ff;        /* focus · in progress */
      --debug-overlay-ink: #fff;            /* primary text */
      --debug-overlay-ink-dim: #eaeaea;     /* text on raised surfaces */
      --debug-overlay-muted: #8f8f96;       /* secondary text */
      --debug-overlay-ground: rgba(18,18,20,.96);  /* the panel itself */
      --debug-overlay-surface: #1f1f24;     /* a card on the ground */
      --debug-overlay-raised: #2c2c31;      /* a control */
      --debug-overlay-raised-hi: #3a3a40;   /* a control, hovered */
      --debug-overlay-line: #2e2e34;        /* a border */
      /* RADIUS LADDER — five steps, each with a meaning. There were eleven
         values, four of them (9/10/11/12px) visually indistinguishable. */
      --debug-overlay-r-chip: 3px;          /* a chip inside a line of text */
      --debug-overlay-r-inner: 6px;         /* inside a control */
      --debug-overlay-r-control: 10px;      /* a control */
      --debug-overlay-r-card: 12px;         /* a card */
      /* 999px (pill) and 50% (circle) stay literal — both are self-evident
         and neither is a step anyone can drift off by one. */
    }

    /* NAMESPACING DEFENDS THE CLASS AXIS ONLY. A host rule on a TAG or an
       attribute — Bootstrap Reboot's hr, Tailwind Preflight's svg, the usual
       input[type=checkbox] visually-hidden trick — matches our elements no
       matter what we call them, and an INHERITED property set on <html> flows
       straight into us: the root is a child of documentElement. Specificity is
       not the defence; declaring the property is. So the root stops every
       inherited property we rely on, and each element type below re-asserts
       what a host most commonly sets on it. */
    #__debug-overlay-root { position: fixed; inset: 0; z-index: ${CONFIG.Z}; pointer-events: none;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 12px; font-style: normal; font-variant: normal; font-weight: 400;
      line-height: normal; letter-spacing: normal; word-spacing: normal;
      text-transform: none; text-indent: 0; text-shadow: none; text-align: left;
      white-space: normal; direction: ltr; visibility: visible; float: none; }
    #__debug-overlay-root * { box-sizing: border-box; float: none; }
    /* form controls take their own tag rules — a host styling the button TAG reaches
       every button we draw, whatever we called it */
    #__debug-overlay-root button, #__debug-overlay-root input, #__debug-overlay-root select {
      margin: 0; text-transform: none; letter-spacing: normal;
      word-spacing: normal; text-indent: 0; }

    .debug-overlay-box { position: fixed; pointer-events: none; }
    .debug-overlay-hover  { outline: 1.5px solid var(--debug-overlay-info); outline-offset: -1px; background: rgba(88,196,255,.06); }
    /* note pin = plain click (inspect only) · pair = Shift+click ·
       link = Ctrl/⌘+Shift+click, chained to the previous pin */
    .debug-overlay-pinbox { outline: 1.5px dashed #ff8a65; outline-offset: -1px; }
    .debug-overlay-pinbox.debug-overlay-pair { outline-style: solid; outline-color: var(--debug-overlay-accent); }
    .debug-overlay-pinbox.debug-overlay-link { outline-style: solid; outline-color: #c084fc; }
    .debug-overlay-pinbox.debug-overlay-waiting { outline-color: var(--debug-overlay-info); }
    .debug-overlay-pinbox.debug-overlay-rmtarget { outline: 2px solid var(--debug-overlay-danger); background: rgba(255,92,92,.10); }
    .debug-overlay-pinbox.debug-overlay-flash { outline: 2.5px solid var(--debug-overlay-info);
      background: rgba(88,196,255,.18); }
    @media (prefers-reduced-motion: no-preference) {
      .debug-overlay-pinbox.debug-overlay-flash { animation: debug-overlay-pulse .9s ease-out; }
    }
    @keyframes debug-overlay-pulse {
      0% { box-shadow: 0 0 0 0 rgba(88,196,255,.55); }
      100% { box-shadow: 0 0 0 16px rgba(88,196,255,0); } }

    /* pin list popover — opened from the count chip, closed for screenshots */
    /* the target menu — right-click's "what can you do with this element" */
    #__debug-overlay-menu { position: fixed; display: none; pointer-events: auto;
      min-width: 150px; background: var(--debug-overlay-ground); border-radius: var(--debug-overlay-r-control);
      padding: 4px; box-shadow: 0 6px 24px rgba(0,0,0,.6); color: #fff;
      font-size: 12px; }
    #__debug-overlay-menu.debug-overlay-open { display: block; }
    #__debug-overlay-menu button { display: block; width: 100%; text-align: left;
      padding: 7px 12px; background: transparent; border: 0; border-radius: var(--debug-overlay-r-inner);
      color: inherit; font: inherit; cursor: pointer; }
    #__debug-overlay-menu button:hover { background: var(--debug-overlay-raised-hi); }
    #__debug-overlay-list { position: fixed; display: none; pointer-events: auto;
      min-width: 250px; max-width: 460px; max-height: 60vh; overflow-y: auto;
      background: var(--debug-overlay-ground); border-radius: var(--debug-overlay-r-card); padding: 6px;
      box-shadow: 0 6px 24px rgba(0,0,0,.6); color: #fff; font-size: 12px; }
    #__debug-overlay-list.debug-overlay-open { display: block; }
    #__debug-overlay-list .debug-overlay-empty { padding: 10px 8px; color: var(--debug-overlay-muted); line-height: 1.5; }
    #__debug-overlay-list .debug-overlay-row { display: flex; align-items: center; gap: 8px;
      padding: 6px 8px; border-radius: var(--debug-overlay-r-control); }
    /* only a row that DOES something on click says so — a settings row is a
       label beside a control, and a pointer over it promised an action that
       never came */
    #__debug-overlay-list .debug-overlay-row[role="button"] { cursor: pointer; }
    #__debug-overlay-list .debug-overlay-row:hover { background: rgba(255,255,255,.08); }
    #__debug-overlay-list .debug-overlay-tag { flex: none; color: #ff8a65; font-weight: 800; }
    /* THE MESSAGE IS THE CONTENT AND MUST NOT BE THE CELL THAT COLLAPSES.
       .debug-overlay-lbl was the only shrinkable item in the row (every sibling is
       flex: none), and its overflow:hidden zeroes its automatic minimum size —
       so a long CSS selector in .debug-overlay-det ate the whole row and the finding
       rendered with NO TEXT AT ALL: measured 0px wide on 2 of 11 rows. The
       floor keeps the human-readable half; the machine-readable half is what
       truncates, with the whole of it in the row's title. */
    #__debug-overlay-list .debug-overlay-lbl { flex: 1 1 auto; min-width: 55%; overflow: hidden;
      text-overflow: ellipsis; white-space: nowrap; }
    #__debug-overlay-list .debug-overlay-det { flex: 0 1 auto; min-width: 0; overflow: hidden;
      text-overflow: ellipsis; white-space: nowrap;
      color: var(--debug-overlay-accent); font-weight: 700; }
    /* A row may carry an opaque accent; the panel copies it onto the element
       without knowing what any of the values mean. */
    #__debug-overlay-list .debug-overlay-row[data-accent="error"] .debug-overlay-tag { color: #ff6b6b; }
    #__debug-overlay-list .debug-overlay-row[data-accent="warn"]  .debug-overlay-tag { color: var(--debug-overlay-warn); }
    #__debug-overlay-list .debug-overlay-row[data-accent="info"]  .debug-overlay-tag { color: #9ad0ff; }
    /* not a verdict — something the tool could not measure and you have to
       look at yourself; italic so it never reads as a failure */
    #__debug-overlay-list .debug-overlay-row[data-accent="review"] .debug-overlay-tag { color: #8ab4f8; font-style: italic; }
    /* The verdict reads first and the selector says where to look, so a
       finding puts its message in .debug-overlay-lbl — which already takes the room and
       ellipsises — and the element in .debug-overlay-det. No direction tricks: rtl reorders
       the neutral characters in a CSS selector and prints '#id' backwards. */
    #__debug-overlay-list .debug-overlay-row[data-accent] .debug-overlay-det { color: var(--debug-overlay-muted); font-weight: 400; }
    /* A settings row's picker. font: inherit because a bare <select> takes the
       PAGE's font on some sites and the row stops lining up; the overlay must
       look the same wherever it is injected. */
    #__debug-overlay-list .debug-overlay-opt { flex: none; cursor: pointer; font: inherit;
      background: var(--debug-overlay-raised); color: var(--debug-overlay-accent); font-weight: 700; border: 0;
      border-radius: var(--debug-overlay-r-inner); padding: 3px 6px;
      width: auto; height: auto; margin: 0; position: static;
      opacity: 1; appearance: auto; text-transform: none; }
    #__debug-overlay-list .debug-overlay-opt:hover { background: var(--debug-overlay-raised-hi); }
    /* what the settings under it change — the category, not the owning tool */
    /* which of the three screens this is — one slot showed findings, pins and
       settings with no header at all, so nothing said what you were reading */
    #__debug-overlay-list .debug-overlay-viewhead { padding: 4px 8px 8px; color: #fff; font-size: 13px;
      font-weight: 800; border-bottom: 1px solid rgba(255,255,255,.10); margin-bottom: 4px; }
    #__debug-overlay-list .debug-overlay-viewhead .debug-overlay-rm { float: right; }
    #__debug-overlay-list .debug-overlay-viewhead .debug-overlay-note { display: block; margin-top: 2px; color: var(--debug-overlay-muted);
      font-size: 10px; font-weight: 400; }
    #__debug-overlay-list .debug-overlay-head { padding: 10px 8px 4px; color: var(--debug-overlay-muted);
      font-size: 10px; font-weight: 800; letter-spacing: .09em; text-transform: uppercase; }
    #__debug-overlay-list .debug-overlay-head:first-child { padding-top: 4px; }
    #__debug-overlay-list .debug-overlay-head .debug-overlay-note { display: block; margin-top: 2px;
      font-size: 10px; font-weight: 400; letter-spacing: 0; text-transform: none; }
    /* stored and waiting — the tool that reads it is switched off */
    /* .45 put the label at 2.53:1 against the popover — a permanent state,
       not a transient one, and unreadable in exactly the tool that ships a
       contrast checker. Dimmed enough to read as inactive, light enough to
       read at all. */
    #__debug-overlay-list .debug-overlay-row.debug-overlay-inert .debug-overlay-lbl, #__debug-overlay-list .debug-overlay-row.debug-overlay-inert .debug-overlay-tag { opacity: .7; }
    #__debug-overlay-list .debug-overlay-num { flex: none; display: flex; align-items: center; gap: 4px; }
    #__debug-overlay-list .debug-overlay-num .debug-overlay-opt { width: 68px; text-align: right; }
    #__debug-overlay-list .debug-overlay-unit { color: var(--debug-overlay-muted); font-weight: 400; }
    /* accent-color rather than a hand-built switch: the native control already
       knows focus, keyboard and the platform's own hit target */
    /* Declared, not defaulted: the common host pattern for hiding a native
       checkbox behind a custom one is input[type=checkbox]{position:absolute;
       opacity:0;width:1px}, and a TAG+ATTRIBUTE selector reaches straight past
       a class namespace. Unopposed is what loses, so this opposes it. */
    #__debug-overlay-list .debug-overlay-tick { width: 15px; height: 15px; padding: 0; margin: 0;
      position: static; opacity: 1; appearance: auto; accent-color: var(--debug-overlay-accent); }
    /* the row's action, when it has one: the CONTENT is the button, so the
       row's ✕ stays a sibling and no interactive element nests in another */
    #__debug-overlay-list .debug-overlay-go { flex: 1 1 auto; min-width: 0; display: flex;
      align-items: center; gap: 8px; padding: 0; border: 0; background: none;
      color: inherit; font: inherit; text-align: left; cursor: pointer; }
    #__debug-overlay-list .debug-overlay-rm { flex: none; width: 20px; height: 20px; border: 0; cursor: pointer;
      border-radius: 50%; background: var(--debug-overlay-raised); color: var(--debug-overlay-danger); font-size: 11px;
      display: flex; align-items: center; justify-content: center; }
    #__debug-overlay-list .debug-overlay-rm:hover { background: var(--debug-overlay-danger); color: #fff; }
    /* Where the findings actually are. Dashed, never filled: a mark points at
       a problem, it must not hide the thing it is pointing at.
       CORE, not one tool's: every rule may mark its own findings, and this was
       contrast's private CSS until dupid needed to mark its own too. A class
       more than one tool emits cannot live in either one's sheet. */
    /* the badge's warn ink — CORE, because grid's lens and perf's pulse both
       emit it, and a class more than one tool emits cannot live in either
       one's sheet */
    .debug-overlay-badge .debug-overlay-warn { color: var(--debug-overlay-warn); }
    .debug-overlay-flag { outline-offset: 1px; }
    .debug-overlay-flag.debug-overlay-error  { outline: 2px dashed #ff6b6b; }
    .debug-overlay-flag.debug-overlay-warn   { outline: 2px dashed var(--debug-overlay-warn); }
    .debug-overlay-flag.debug-overlay-info   { outline: 2px dashed #9ad0ff; }
    .debug-overlay-flag.debug-overlay-review { outline: 2px dotted #8ab4f8; }
    /* WHAT is wrong, not only where. A dashed box names no rule, and no
       tooltip can ever say: this layer is aria-hidden and pointer-events:none,
       so a title attribute on a mark reaches nobody. So it is painted — the
       rule's own id, one label per element however many findings it drew. */
    .debug-overlay-tip { position: fixed; pointer-events: none; font-size: 9px;
      font-weight: 700; line-height: 12px; padding: 0 3px; border-radius: var(--debug-overlay-r-chip);
      background: rgba(18,18,20,.92); white-space: nowrap; }
    .debug-overlay-tip.debug-overlay-error  { color: #ff6b6b; }
    .debug-overlay-tip.debug-overlay-warn   { color: var(--debug-overlay-warn); }
    .debug-overlay-tip.debug-overlay-info   { color: #9ad0ff; }
    .debug-overlay-tip.debug-overlay-review { color: #8ab4f8; font-style: italic; }
    /* an audit is on the page right now — distinct from .debug-overlay-armed, which only
       means the findings VIEW is the one open. No backticks in here: this
       whole sheet is a template literal. */
    #__debug-overlay-bar .debug-overlay-act.debug-overlay-swept { box-shadow: inset 0 0 0 2px var(--debug-overlay-accent); }
    /* There was no designed focus indicator anywhere in this sheet — a
       keyboard user could tab through 13 controls with nothing to show where
       they were. :focus-visible only, so a mouse click does not draw one. */
    #__debug-overlay-root :focus-visible { outline: 2px solid var(--debug-overlay-info); outline-offset: 2px; }
    /* WCAG 2.5.8 wants 24x24. These three were 18x21, 20x20 and 15x15. */
    #__debug-overlay-bar .debug-overlay-cnt { min-width: 24px; min-height: 24px; }
    /* already at the floor — kept explicit because it is DESTRUCTIVE and the
       smallest interactive thing in a scrolling list (audit S5) */
    #__debug-overlay-list .debug-overlay-rm { width: 24px; height: 24px;
      display: inline-flex; align-items: center; justify-content: center; }
    #__debug-overlay-list .debug-overlay-tick { width: 24px; height: 24px; }
    #__debug-overlay-bar .debug-overlay-cnt.debug-overlay-armed { background: #ff8a65; color: var(--debug-overlay-on-accent); }

    .debug-overlay-badge { position: fixed; pointer-events: none; max-width: 92vw;
      background: rgba(18,18,20,.94); color: #fff; border-radius: var(--debug-overlay-r-control);
      padding: 4px 9px; font-size: 12px; line-height: 1.45; white-space: nowrap;
      box-shadow: 0 2px 10px rgba(0,0,0,.45); }
    .debug-overlay-badge .debug-overlay-sz  { color: var(--debug-overlay-ink); font-weight: 700; }
    .debug-overlay-badge .debug-overlay-rad { color: #ff8a65; }
    .debug-overlay-badge .debug-overlay-sp  { color: #9ad0ff; }
    .debug-overlay-badge .debug-overlay-fnt { color: #d7c4ff; }
    .debug-overlay-badge .debug-overlay-tag { color: var(--debug-overlay-muted); }

    .debug-overlay-pin-num { position: fixed; pointer-events: none;
      min-width: 22px; height: 22px; padding: 0 5px; border-radius: var(--debug-overlay-r-control);
      background: #ff8a65; color: var(--debug-overlay-on-accent); font-size: 12px; font-weight: 800;
      display: flex; align-items: center; justify-content: center;
      box-shadow: 0 2px 8px rgba(0,0,0,.5); }
    .debug-overlay-pin-num.debug-overlay-pair { background: var(--debug-overlay-accent); color: #16200a; }
    .debug-overlay-pin-num.debug-overlay-link { background: #c084fc; color: #241333; }
    .debug-overlay-pin-num.debug-overlay-waiting { background: var(--debug-overlay-info); color: #0d1b24; }
    .debug-overlay-pin-num.debug-overlay-rmtarget { background: var(--debug-overlay-danger); color: #fff; }

    /* remove mode: ✕ chips appear only while the remove key is held */
    .debug-overlay-rmchip { position: fixed; pointer-events: none;
      width: 18px; height: 18px; border-radius: 50%; background: var(--debug-overlay-danger); color: #fff;
      font-size: 11px; font-weight: 800; line-height: 1;
      display: flex; align-items: center; justify-content: center;
      box-shadow: 0 2px 6px rgba(0,0,0,.5); transition: transform .1s ease; }
    .debug-overlay-rmchip.debug-overlay-target { transform: scale(1.3); background: #ff2f2f; }

    #__debug-overlay-bar { position: fixed; right: 14px; top: 50%;
      pointer-events: auto; display: flex; flex-direction: column; align-items: center;
      gap: 6px; background: var(--debug-overlay-ground); border-radius: 999px; padding: 8px;
      box-shadow: 0 4px 18px rgba(0,0,0,.55); user-select: none; touch-action: none;
      transition: transform .22s cubic-bezier(.2,.8,.3,1), opacity .22s ease; }
    #__debug-overlay-bar.debug-overlay-dragging { transition: none; opacity: .9; }
    /* 24px is a FLOOR, not a target (audit S5). This was 22x12 — under the
       floor on both axes, on the control that positions the entire overlay,
       while every button beside it is 34px. The hit area grows; the dots
       stay small, because ink size and target size are separate things. */
    #__debug-overlay-bar .debug-overlay-grip { width: 24px; height: 24px; cursor: grab; flex: none;
      display: flex; align-items: center; justify-content: center;
      color: var(--debug-overlay-muted); font-size: 11px; letter-spacing: 1px; line-height: 1; }
    #__debug-overlay-bar.debug-overlay-dragging .debug-overlay-grip { cursor: grabbing; }

    /* master power */
    #__debug-overlay-bar .debug-overlay-pwr { width: 36px; height: 36px; border-radius: 50%; border: 0; cursor: pointer;
      font-size: 15px; background: var(--debug-overlay-raised-hi); color: var(--debug-overlay-muted);
      display: flex; align-items: center; justify-content: center; transition: background .15s; }
    #__debug-overlay-bar.debug-overlay-on .debug-overlay-pwr { background: var(--debug-overlay-accent); color: var(--debug-overlay-on-accent); }
    /* a newer version exists — RESTS until updated, like every count that
       matters; amber because it asks for a decision, not because it burns */
    #__debug-overlay-bar .debug-overlay-pwr.debug-overlay-upd::after { content: ''; position: absolute;
      top: 1px; right: 1px; width: 9px; height: 9px; border-radius: 50%;
      background: var(--debug-overlay-warn); border: 2px solid var(--debug-overlay-ground); }
    #__debug-overlay-bar .debug-overlay-pwr { position: relative; }
    #__debug-overlay-bar .debug-overlay-st { font-size: 10px; font-weight: 800; letter-spacing: .5px; color: var(--debug-overlay-muted); }
    #__debug-overlay-bar.debug-overlay-on .debug-overlay-st { color: var(--debug-overlay-accent); }
    #__debug-overlay-bar.debug-overlay-removing .debug-overlay-pwr { background: var(--debug-overlay-danger); color: #fff; }
    #__debug-overlay-bar.debug-overlay-removing .debug-overlay-st { color: var(--debug-overlay-danger); }

    /* hidden: the SIDE PANEL is presenting this state instead, so the web
       panel's bar steps aside — the BAR, not the overlay: pins, marks and
       badges are the page's annotations and stay. display, not visibility:
       the bar must leave the tab order too, or Tab lands on invisible
       buttons. */
    #__debug-overlay-bar.debug-overlay-hidden { display: none; }

    /* THE FIRST-RUN INSTRUCTION. The empty pin list already carried this
       sentence, and it was invisible: it lived inside the popover that opens
       from the pin chip, so it only ever reached people who had already
       worked out what the pin chip was (audit C3). On the surface, once,
       until the gesture is used. pointer-events none — it teaches, it is
       not a control, and it must never eat a click meant for the page. */
    .debug-overlay-hint { position: fixed; left: 50%; transform: translateX(-50%);
      bottom: 18px; z-index: 2147483646; pointer-events: none;
      background: rgba(22, 22, 26, .92); color: var(--debug-overlay-ink-dim);
      border: 1px solid var(--debug-overlay-line); border-radius: 999px; padding: 7px 16px;
      font: 12px/1.4 system-ui, -apple-system, sans-serif;
      white-space: nowrap; max-width: 92vw; overflow: hidden;
      text-overflow: ellipsis; }

    /* things that only make sense once powered on */
    #__debug-overlay-bar .debug-overlay-whenOn { display: none; }
    #__debug-overlay-bar.debug-overlay-on .debug-overlay-whenOn { display: flex; align-items: center; justify-content: center; }
    #__debug-overlay-bar.debug-overlay-on .debug-overlay-cnt.debug-overlay-whenOn { display: block; }
    /* the family flyout: the mark sits in the bar, the members slide out
       sideways — toward the open side of the screen, read off data-side */
    #__debug-overlay-bar .debug-overlay-fam, #__debug-overlay-bar .debug-overlay-fam-btn { display: none; }
    #__debug-overlay-bar.debug-overlay-on .debug-overlay-fam { position: relative; display: flex; }
    #__debug-overlay-bar.debug-overlay-on .debug-overlay-fam-btn { width: 34px; height: 34px; border-radius: 50%; border: 0;
      cursor: pointer; background: var(--debug-overlay-raised); color: var(--debug-overlay-ink-dim); font-size: 15px;
      display: flex; align-items: center; justify-content: center; position: relative; }
    #__debug-overlay-bar .debug-overlay-fam-btn:hover { background: var(--debug-overlay-raised-hi); }
    #__debug-overlay-bar .debug-overlay-fam-btn.debug-overlay-armed { background: var(--debug-overlay-info); color: var(--debug-overlay-on-accent); }
    #__debug-overlay-bar .debug-overlay-fam-btn.debug-overlay-checks::after { content: ''; position: absolute;
      right: 1px; bottom: 1px; width: 7px; height: 7px; border-radius: 50%;
      background: var(--debug-overlay-accent); border: 2px solid var(--debug-overlay-ground); }
    /* VERTICAL, like the bar it belongs to — the flyout is a short second
       column beside the head, not a sideways pill. And SEPARATED: no capsule
       background; each member is its own circle wearing its own shadow, the
       same species of button as the bar's. */
    #__debug-overlay-bar .debug-overlay-fam .debug-overlay-flyout { position: absolute; top: 50%;
      transform: translateY(-50%) scale(.9); display: flex;
      flex-direction: column; align-items: center; gap: 6px;
      opacity: 0; pointer-events: none;
      /* VISIBILITY, not just opacity: pointer-events stops the mouse but a
         transparent button keeps its place in the TAB ORDER, so four buttons
         nobody could see answered the keyboard. Delayed to the end of the fade
         so the transition still plays; inert is not an option here — that is
         the v3.8.48 defect, and jsdom implements neither its semantics nor
         display:none inheritance. */
      visibility: hidden;
      transition: opacity .15s ease, transform .15s ease, visibility 0s linear .15s; }
    #__debug-overlay-bar .debug-overlay-fam .debug-overlay-flyout button {
      box-shadow: 0 4px 14px rgba(0,0,0,.55); }
    /* the SECOND layer: a pressed axis grows its members one more step out
       from the bar, its own column beside the head — never mixed into the
       heads' column, or two levels read as one flat run */
    #__debug-overlay-bar .debug-overlay-fam .debug-overlay-flyout .debug-overlay-sub { position: relative; display: flex; }
    #__debug-overlay-bar .debug-overlay-fam .debug-overlay-flyout .debug-overlay-subfly { position: absolute; top: 50%;
      transform: translateY(-50%); display: flex; flex-direction: column;
      align-items: center; gap: 6px; }
    #__debug-overlay-bar[data-side="right"] .debug-overlay-fam .debug-overlay-flyout .debug-overlay-subfly { right: calc(100% + 12px); }
    #__debug-overlay-bar[data-side="left"] .debug-overlay-fam .debug-overlay-flyout .debug-overlay-subfly,
    #__debug-overlay-bar[data-side="top"] .debug-overlay-fam .debug-overlay-flyout .debug-overlay-subfly,
    #__debug-overlay-bar[data-side="bottom"] .debug-overlay-fam .debug-overlay-flyout .debug-overlay-subfly { left: calc(100% + 12px); }
    #__debug-overlay-bar .debug-overlay-fam.debug-overlay-open .debug-overlay-flyout { opacity: 1; pointer-events: auto;
      visibility: visible; transition-delay: 0s;
      transform: translateY(-50%) scale(1); }
    #__debug-overlay-bar[data-side="right"] .debug-overlay-fam .debug-overlay-flyout { right: calc(100% + 12px); }
    #__debug-overlay-bar[data-side="left"] .debug-overlay-fam .debug-overlay-flyout,
    #__debug-overlay-bar[data-side="top"] .debug-overlay-fam .debug-overlay-flyout,
    #__debug-overlay-bar[data-side="bottom"] .debug-overlay-fam .debug-overlay-flyout { left: calc(100% + 12px); }
    #__debug-overlay-bar hr.debug-overlay-sep { width: 20px; height: 1px; border: 0; margin: 1px 0;
      opacity: 1; overflow: visible; color: inherit;
      background: rgba(255,255,255,.14); }
    #__debug-overlay-bar .debug-overlay-cnt { font-size: 11px; font-weight: 700; color: #ff8a65;
      border: 0; background: transparent; cursor: pointer; padding: 2px 6px;
      border-radius: 999px; font-family: inherit; }
    #__debug-overlay-bar .debug-overlay-cnt:hover { background: var(--debug-overlay-raised); }
    /* ARMED WINS OVER HOVER. The armed chip is dark text on amber; this hover
       rule is declared later at equal specificity, so it replaced the amber
       with var(--debug-overlay-raised) and left the dark text — var(--debug-overlay-on-accent) on var(--debug-overlay-raised) is 1.25:1, an
       empty-looking circle exactly while its own list is open, and you are
       always hovering the chip you just clicked. In a tool that ships a
       contrast checker. */
    #__debug-overlay-bar .debug-overlay-cnt.debug-overlay-armed:hover { background: #ff8a65; }

    /* tool + action buttons */
    /* ONE SHAPE PER ROLE CLASS (audit S3). These three used to share one
       rule, so eleven controls were the same circle and the only thing
       separating an input from a detector from a destructive action was a
       1px hairline. Same 34px box for all of them — the column rhythm and
       the 24px floor are untouched — but three silhouettes:
         circle    a DETECTOR: changes what you see, changes nothing else
         squircle  an INPUT: your clicks become pins and groups
         rounded   an ACTION: does something to the page or the session
       The role is derived from hooks where the button is built, so no tool
       id appears there or here. Two things this comment must not contain,
       both learned the hard way: a backtick (this whole sheet is one
       template literal) and a bare dotted filename (the namespace test
       reads every dot-token here as a class name). */
    #__debug-overlay-bar button.debug-overlay-tool, #__debug-overlay-bar button.debug-overlay-act, #__debug-overlay-bar button.debug-overlay-bctl {
      width: 34px; height: 34px; border-radius: 50%; border: 0; cursor: pointer;
      background: var(--debug-overlay-raised); color: #fff; font-size: 15px; }
    /* Three silhouettes, and they must be three LADDER steps apart — the
       first version of this used 11px for inputs and 9px for actions, which
       the design-system audit then flagged as one value wearing two names.
       It was right: at 34px those two radii are the same picture, so the
       distinction existed only in the source. Circle · control · inner,
       with a border on the action, is a difference the eye can actually
       make. */
    #__debug-overlay-bar button.debug-overlay-tool.debug-overlay-input {
      border-radius: var(--debug-overlay-r-control); }
    #__debug-overlay-bar button.debug-overlay-act {
      border-radius: var(--debug-overlay-r-inner);
      border: 1px solid var(--debug-overlay-line); background: #232328; }
    /* NO display here: .debug-overlay-whenOn owns display (none ↔ flex with centring), and
       a more specific display on the buttons out-guns the hider — the exact
       mistake the fam flyout already made once. One icon set (lucide, ISC),
       one size; the .debug-overlay-whenOn / .debug-overlay-pwr / .debug-overlay-fam-btn flex does the centring. */
    /* every svg we own, not just the bar's: Preflight sets display on the
       TAG, so a rule scoped to one container leaves the rest of them to it */
    #__debug-overlay-root svg { display: inline-block; vertical-align: middle; }
    #__debug-overlay-bar button svg { width: 16px; height: 16px; pointer-events: none; }
    #__debug-overlay-bar .debug-overlay-grip svg { width: 14px; height: 14px; display: block; }
    #__debug-overlay-list .debug-overlay-tag svg { width: 14px; height: 14px; vertical-align: -3px; }
    #__debug-overlay-bar button.debug-overlay-tool:hover, #__debug-overlay-bar button.debug-overlay-act:hover { background: var(--debug-overlay-raised-hi); }
    #__debug-overlay-bar button.debug-overlay-tool.debug-overlay-armed,
    #__debug-overlay-bar button.debug-overlay-bctl.debug-overlay-armed { background: var(--debug-overlay-info); color: #0d1b24; }
    /* an OPEN axis head is a drawer pulled out, not a value in force —
       a ring, not the armed fill, so the two states cannot be confused */
    #__debug-overlay-bar button.debug-overlay-bctl.debug-overlay-axis.debug-overlay-open { box-shadow: inset 0 0 0 2px var(--debug-overlay-info); }
    /* a fixed member is information: always on, takes no click */
    #__debug-overlay-bar button.debug-overlay-bctl.debug-overlay-fixed { opacity: .55; cursor: default; }
    /* A tool in the run that feeds ⌕ carries a dot. Armed or not, it is still
       swept — the dot says "this contributes findings", the fill says "this
       is drawn". They are different questions and used to look the same. */
    #__debug-overlay-bar button.debug-overlay-tool.debug-overlay-checks { position: relative; }
    #__debug-overlay-bar button.debug-overlay-tool.debug-overlay-checks::after {
      content: ''; position: absolute; right: 2px; bottom: 2px;
      width: 4px; height: 4px; border-radius: 50%; background: var(--debug-overlay-accent); }
    #__debug-overlay-bar button.debug-overlay-act.debug-overlay-armed { background: var(--debug-overlay-accent); color: var(--debug-overlay-on-accent); }

    #__debug-overlay-bar.debug-overlay-tucked { opacity: .4; }
    #__debug-overlay-bar.debug-overlay-tucked:hover { opacity: 1; }
  `;

  // src/ui/dom.js
  var root;
  var layer;
  function initDom() {
    root = document.createElement("div");
    root.id = CONFIG.ROOT_ID;
    root.setAttribute("role", "region");
    root.setAttribute("aria-label", "Debug overlay");
    const sheet = (css, owner) => {
      const s = document.createElement("style");
      if (owner) s.dataset.tool = owner;
      s.textContent = css;
      root.append(s);
    };
    sheet(CSS2);
    for (const t of Tools.ordered()) if (t.css) sheet(t.css, t.id);
    layer = document.createElement("div");
    layer.setAttribute("aria-hidden", "true");
    root.append(layer);
    document.documentElement.append(root);
  }

  // src/ui/controls.js
  var Controls = {
    /**
     * An unknown kind renders an empty span rather than guessing. A row asking
     * for something this cannot draw should be visibly missing, not silently
     * approximated by whichever branch happened to fall through.
     */
    /* `name` is the row's own label, handed down so every control has an
       ACCESSIBLE NAME. These are built on every re-render, long after the
       panel's init-time labelling pass — the same gap the badge flyout's
       buttons had. Without it a screen reader announces a bare combo box:
       the label sits in a sibling span, which no native association reaches. */
    build(c, onChange, name) {
      const fn = Controls[c.kind];
      const el2 = fn ? fn(c, onChange) : document.createElement("span");
      const field = el2.matches?.("select, input") ? el2 : el2.querySelector?.("select, input");
      if (field && name) field.setAttribute("aria-label", name);
      return el2;
    },
    choice(c, onChange) {
      const sel = document.createElement("select");
      sel.className = "debug-overlay-opt";
      c.choices.forEach((label, k) => {
        const o = document.createElement("option");
        o.value = String(k);
        o.textContent = label;
        sel.append(o);
      });
      sel.selectedIndex = c.selected || 0;
      sel.addEventListener("click", (e) => e.stopPropagation());
      sel.addEventListener("change", () => onChange(sel.selectedIndex));
      return sel;
    },
    number(c, onChange) {
      const wrap = document.createElement("span");
      wrap.className = "debug-overlay-num";
      const inp = document.createElement("input");
      inp.type = "number";
      inp.className = "debug-overlay-opt";
      inp.value = c.value;
      if (c.min !== void 0) inp.min = String(c.min);
      if (c.max !== void 0) inp.max = String(c.max);
      if (c.step !== void 0) inp.step = String(c.step);
      inp.addEventListener("click", (e) => e.stopPropagation());
      inp.addEventListener("change", () => onChange(inp.value));
      wrap.append(inp);
      if (c.suffix) {
        const u = document.createElement("span");
        u.className = "debug-overlay-unit";
        u.textContent = c.suffix;
        wrap.append(u);
      }
      return wrap;
    },
    toggle(c, onChange) {
      const inp = document.createElement("input");
      inp.type = "checkbox";
      inp.className = "debug-overlay-opt debug-overlay-tick";
      inp.checked = !!c.on;
      inp.addEventListener("click", (e) => e.stopPropagation());
      inp.addEventListener("change", () => onChange(inp.checked));
      return inp;
    }
  };

  // src/ui/list.js
  var List;
  function initList() {
    List = (() => {
      const el2 = document.createElement("div");
      el2.id = "__debug-overlay-list";
      root.append(el2);
      let open = false;
      let view = null;
      let anchor = null;
      function place() {
        if (!anchor) return;
        const r = anchor.el.getBoundingClientRect();
        const w = el2.offsetWidth, h = el2.offsetHeight;
        const G = CONFIG.LIST_GAP, P = CONFIG.LIST_PAD;
        const at = (x, y) => ({
          x: Math.max(P, Math.min(x, innerWidth - w - P)),
          y: Math.max(P, Math.min(y, innerHeight - h - P))
        });
        const beside = {
          right: () => at(r.left - w - G, r.top),
          left: () => at(r.right + G, r.top),
          below: () => at(r.left + r.width / 2 - w / 2, r.bottom + G),
          above: () => at(r.left + r.width / 2 - w / 2, r.top - h - G)
        };
        const side = anchor.side();
        const order = side === "left" ? ["left", "right", "below", "above"] : side === "right" ? ["right", "left", "below", "above"] : side === "top" ? ["below", "right", "left", "above"] : ["above", "right", "left", "below"];
        const clears = (c) => c.x + w <= r.left || c.x >= r.right || c.y + h <= r.top || c.y >= r.bottom;
        const tried = order.map((k) => beside[k]());
        const pick = tried.find(clears) || tried[0];
        el2.style.left = pick.x + "px";
        el2.style.top = pick.y + "px";
      }
      const api = {
        onOpen: null,
        onRowActivate: null,
        onRowRemove: null,
        onRowChange: null,
        /** PANEL says where it is and how to light up the button that opened us. */
        attach(a) {
          anchor = a;
        },
        isOpen: () => open,
        /**
         * One popover, several views. `view` is an opaque name off the button
         * that opened it — this carries it and hands it back, and never learns
         * what any of them mean.
         */
        view: () => view,
        place,
        toggle(v, name = "pins") {
          const same = open && view === name;
          open = v === void 0 ? !same : !!v;
          view = open ? name : null;
          el2.classList.toggle("debug-overlay-open", open);
          anchor?.mark(view);
          if (open) {
            api.onOpen?.(view);
            place();
          }
        },
        /**
         * rows: [{ tag, label, detail, removable }] — built by CONTROLLER, which
         * is also where the empty-state wording comes from, because only it
         * knows what this view is a list of.
         *
         * A row may carry a `control` description instead of a detail. This
         * draws it and hands back whatever the widget produced — an index, a
         * string, a boolean. It cannot learn what the setting is or what type
         * its value has, and so cannot start deciding any of that.
         */
        set(rows, empty = "") {
          const live = document.activeElement;
          const owner = live && el2.contains(live) ? live.closest(".debug-overlay-row") : null;
          const focus = owner ? { at: [...el2.children].indexOf(owner), cls: live.className.split(" ")[0] } : null;
          el2.textContent = "";
          const restore = () => {
            if (!focus || focus.at < 0) return;
            const row = el2.children[focus.at];
            (row?.querySelector?.("." + focus.cls) || row?.querySelector?.(".debug-overlay-go"))?.focus?.();
          };
          if (!rows.length) {
            const e = document.createElement("div");
            e.className = "debug-overlay-empty";
            e.textContent = empty;
            el2.append(e);
            place();
            return;
          }
          rows.forEach((row, i) => {
            if (row.title || row.heading) {
              const h = document.createElement("div");
              h.className = row.title ? "debug-overlay-viewhead" : "debug-overlay-head";
              h.textContent = row.title || row.heading;
              if (row.removable) {
                const rm = document.createElement("button");
                rm.className = "debug-overlay-rm";
                rm.textContent = "✕";
                rm.title = row.rmTitle || "Remove";
                rm.addEventListener("click", (e) => {
                  e.stopPropagation();
                  api.onRowRemove?.(i);
                });
                h.append(rm);
              }
              if (row.detail) {
                const n = document.createElement("span");
                n.className = "debug-overlay-note";
                n.textContent = row.detail;
                h.append(n);
              }
              el2.append(h);
              return;
            }
            const r = document.createElement("div");
            r.className = "debug-overlay-row";
            const tag = document.createElement("span");
            tag.className = "debug-overlay-tag";
            if (/^<svg[\s>]/.test(row.tag || "")) tag.innerHTML = row.tag;
            else tag.textContent = row.tag;
            const lbl = document.createElement("span");
            lbl.className = "debug-overlay-lbl";
            lbl.textContent = row.label;
            if (row.accent) r.dataset.accent = row.accent;
            if (row.inert) r.classList.add("debug-overlay-inert");
            if (row.label || row.detail) {
              r.title = [row.label, row.detail].filter(Boolean).join("\n");
            }
            if (row.control) {
              r.append(tag, lbl, Controls.build(
                row.control,
                (raw) => api.onRowChange?.(i, raw),
                row.label
              ));
            } else {
              const det = document.createElement("span");
              det.className = "debug-overlay-det";
              det.textContent = row.detail || "";
              if (row.activatable) {
                const go = document.createElement("button");
                go.className = "debug-overlay-go";
                go.append(tag, lbl, det);
                go.addEventListener("click", (e) => {
                  e.stopPropagation();
                  api.onRowActivate?.(i);
                });
                r.addEventListener("click", () => api.onRowActivate?.(i));
                r.append(go);
              } else {
                r.append(tag, lbl, det);
              }
            }
            if (row.removable) {
              const rm = document.createElement("button");
              rm.className = "debug-overlay-rm";
              rm.textContent = "✕";
              rm.title = "Remove";
              rm.addEventListener("click", (e) => {
                e.stopPropagation();
                api.onRowRemove?.(i);
              });
              r.append(rm);
            }
            el2.append(r);
          });
          restore();
          place();
        }
      };
      return api;
    })();
  }

  // src/ui/menu.js
  var el = null;
  function initMenu() {
    el = document.createElement("div");
    el.id = "__debug-overlay-menu";
    root.append(el);
    document.addEventListener("pointerdown", (e) => {
      if (Menu.isOpen() && !(e.target.closest && e.target.closest("#__debug-overlay-menu")))
        Menu.close();
    }, true);
  }
  var Menu = {
    isOpen: () => !!el && el.classList.contains("debug-overlay-open"),
    /** rows: [{ label, run }] — label is all this file reads of them. */
    open(x, y, rows) {
      el.textContent = "";
      for (const r of rows) {
        const b = document.createElement("button");
        b.textContent = r.label;
        b.addEventListener("click", () => {
          Menu.close();
          r.run();
        });
        el.append(b);
      }
      el.classList.add("debug-overlay-open");
      const w = el.offsetWidth, h = el.offsetHeight;
      let px = Math.max(4, Math.min(x, innerWidth - w - 4));
      let py = Math.max(4, Math.min(y, innerHeight - h - 4));
      const bar = document.getElementById("__debug-overlay-bar");
      if (bar) {
        const b = bar.getBoundingClientRect();
        if (px < b.right && px + w > b.left && py < b.bottom && py + h > b.top) {
          px = b.left >= w + 12 ? b.left - w - 8 : Math.min(b.right + 8, innerWidth - w - 4);
        }
      }
      el.style.left = px + "px";
      el.style.top = py + "px";
    },
    close() {
      if (!el) return;
      el.classList.remove("debug-overlay-open");
      el.textContent = "";
    }
  };

  // src/ui/web-panel.js
  var WebPanel;
  function initWebPanel() {
    WebPanel = (() => {
      const el2 = document.createElement("div");
      el2.id = "__debug-overlay-bar";
      const isInput = (t) => Tools.rolesOf(t).includes("Select");
      const toolBtn = (t) => `<button class="debug-overlay-tool debug-overlay-whenOn ${isInput(t) ? "debug-overlay-input" : ""} ${Tools.feedsAudit(t) ? "debug-overlay-checks" : ""}" data-tool="${t.id}" title="${t.family ? t.family[0].toUpperCase() + t.family.slice(1) + " › " : ""}${t.title}
${Tools.rolesOf(t).join(" · ")}${Tools.feedsAudit(t) ? " · also runs in the page audit" : ""}${t.options || t.uses ? "\nright-click for its options" : ""}">${t.icon}</button>`;
      const toolRuns = Tools.runs().map((run) => {
        const out = [];
        const done = /* @__PURE__ */ new Set();
        for (const t of run.tools) {
          const mark = t.family && Tools.familyMark(t.family);
          if (!mark) {
            out.push(toolBtn(t));
            continue;
          }
          if (done.has(t.family)) continue;
          done.add(t.family);
          const kin = run.tools.filter((x) => x.family === t.family);
          const famName = t.family[0].toUpperCase() + t.family.slice(1);
          out.push(
            `<span class="debug-overlay-fam debug-overlay-whenOn" data-fam="${t.family}"><button class="debug-overlay-fam-btn debug-overlay-whenOn ${kin.some(Tools.feedsAudit) ? "debug-overlay-checks" : ""}" aria-expanded="false" title="${famName} family — ${kin.map((x) => x.id).join(", ")}; click to open">${mark}</button><span class="debug-overlay-flyout">${kin.map(toolBtn).join("")}</span></span>`
          );
        }
        return out.join("");
      }).join('<hr class="debug-overlay-sep debug-overlay-whenOn">');
      const SWEEP_ICON = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="m21 21-4.34-4.34" /><circle cx="11" cy="11" r="8" /></svg>';
      el2.innerHTML = `
      <span class="debug-overlay-grip" title="Drag to move — snaps to the nearest edge"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><circle cx="9" cy="12" r="1" /><circle cx="9" cy="5" r="1" /><circle cx="9" cy="19" r="1" /><circle cx="15" cy="12" r="1" /><circle cx="15" cy="5" r="1" /><circle cx="15" cy="19" r="1" /></svg></span>
      <button class="debug-overlay-pwr" title="Power (Alt+Shift+D) · v${CONFIG.VERSION}"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M12 2v10" /><path d="M18.4 6.6a9 9 0 1 1-12.77.04" /></svg></button>
      <span class="debug-overlay-st" data-st>OFF</span>
      <hr class="debug-overlay-sep debug-overlay-whenOn">
      ${toolRuns}
      <!-- its own band: ⌕ and ⚙ drive the services, they are not tools -->
      <hr class="debug-overlay-sep debug-overlay-whenOn">
      <button class="debug-overlay-act debug-overlay-whenOn" data-sweep data-view="findings" title="Audit the whole page">${SWEEP_ICON}</button>
      <!-- with the tools it configures, not with the panel's own actions -->
      <button class="debug-overlay-act debug-overlay-whenOn" data-settings data-view="settings" title="Tool settings"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915" /><circle cx="12" cy="12" r="3" /></svg></button>
      <hr class="debug-overlay-sep debug-overlay-whenOn">
      <button class="debug-overlay-cnt debug-overlay-whenOn" data-c data-view="pins" title="Pinned elements — click for the list">0</button>
      <!-- 🏷 replaces ≡: same fam flyout the domain families use, members
           handed in by the controller (setBadgeControls) — this file renders
           what it is given and never learns what a view or a facet is -->
      <span class="debug-overlay-fam debug-overlay-whenOn" data-badge>
        <button class="debug-overlay-fam-btn debug-overlay-act" title="Badge — view and facets; click to open"
                aria-haspopup="true" aria-expanded="false"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z" /><circle cx="7.5" cy="7.5" r=".5" fill="currentColor" /></svg></button>
        <span class="debug-overlay-flyout" data-badge-fly></span>
      </span>
      <button class="debug-overlay-act debug-overlay-whenOn" data-copy title="Copy report"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><rect width="8" height="4" x="8" y="2" rx="1" ry="1" /><path d="M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" /><path d="M16 4h2a2 2 0 0 1 2 2v4" /><path d="M21 14H11" /><path d="m15 10-4 4 4 4" /></svg></button>
      <button class="debug-overlay-act debug-overlay-whenOn" data-clear title="Clear pins and the audit's marks"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg></button>`;
      root.append(el2);
      List.attach({
        el: el2,
        side: () => side,
        mark: (view) => el2.querySelectorAll("[data-view]").forEach(
          (b) => {
            const on = !!view && b.dataset.view === view;
            b.classList.toggle("debug-overlay-armed", on);
            b.setAttribute("aria-pressed", String(on));
          }
        )
      });
      const flashing = /* @__PURE__ */ new Map();
      let hintEl = null;
      let badgeGroups = [];
      function renderBadgeFly() {
        const fly = el2.querySelector("[data-badge-fly]");
        const open = fly.dataset.open || "";
        fly.textContent = "";
        for (const g of badgeGroups) {
          const sub = document.createElement("span");
          sub.className = "debug-overlay-sub";
          const h = document.createElement("button");
          h.className = "debug-overlay-bctl debug-overlay-whenOn debug-overlay-axis" + (open === g.key ? " debug-overlay-open" : "");
          h.innerHTML = g.glyph;
          h.title = g.title;
          h.setAttribute("aria-label", g.title);
          h.setAttribute("aria-expanded", String(open === g.key));
          h.addEventListener("click", () => {
            fly.dataset.open = open === g.key ? "" : g.key;
            renderBadgeFly();
          });
          sub.append(h);
          if (open === g.key) {
            const members = document.createElement("span");
            members.className = "debug-overlay-subfly";
            for (const r of g.rows) {
              const b = document.createElement("button");
              b.className = "debug-overlay-bctl debug-overlay-whenOn" + (r.armed ? " debug-overlay-armed" : "") + (r.fixed ? " debug-overlay-fixed" : "");
              b.innerHTML = r.glyph;
              b.title = r.title;
              b.setAttribute("aria-label", r.title);
              b.setAttribute("aria-pressed", String(!!r.armed));
              if (r.fixed) b.setAttribute("aria-disabled", "true");
              else b.addEventListener("click", () => api.onBadgeControl?.(r.key));
              members.append(b);
            }
            sub.append(members);
          }
          fly.append(sub);
        }
      }
      const api = {
        el: el2,
        onToggle: null,
        onTool: null,
        onBadgeControl: null,
        onCopy: null,
        onUpdateMenu: null,
        onClear: null,
        onListOpen: null,
        onRowActivate: null,
        onRowRemove: null,
        onSweep: null,
        onRowChange: null,
        /* The panel repeats what it is told, to whoever asks — the same
           announce-and-let-boot-decide shape as Render.onPinsPruned. This file
           never learns who listens; today it is the side panel bridge, mirroring
           the bar's state to the extension's side panel. */
        onState: null,
        /* The query twin of onListOpen: "what would that view show?" — wired by
           boot to the same rows and empty text the popover renders, asked by
           the bridge for a view the side panel holds open. A query, not a push,
           because the asker names the view. */
        onRowsFor: null,
        setOn(v) {
          el2.classList.toggle("debug-overlay-on", v);
          el2.querySelector("[data-st]").textContent = v ? "ON" : "OFF";
          if (!v) {
            api.toggleList(false);
            api.closeFlyouts();
          }
          if (v) {
            clearTimeout(tuckTimer);
            untuck();
          } else scheduleTuck();
          api.onState?.("on", v);
          api.hint?.(v);
        },
        /**
         * The one instruction a new user needs, on the surface — not behind a
         * click on a control they have no reason to press yet. The empty pin
         * list already said "click to inspect, Shift+click to measure", which
         * is exactly right and exactly invisible: it lives inside the popover
         * that opens from the pin chip, so it only ever reached people who had
         * already worked out what the pin chip was (audit C3).
         *
         * It disappears the moment the gesture is used — taught, not dismissed
         * — so it costs a returning user nothing and nobody has to find an ✕.
         */
        hint(on) {
          const msg = Store.get(CONFIG.TAUGHT_KEY) === "1" ? null : "Click any element to inspect it · Shift+click two to measure between them";
          if (!on || !msg) {
            hintEl?.remove();
            hintEl = null;
            return;
          }
          if (!hintEl) {
            hintEl = document.createElement("div");
            root.append(hintEl);
          }
          hintEl.className = "debug-overlay-hint";
          hintEl.textContent = msg;
        },
        /** The gesture was used, so the instruction has done its job. */
        taught() {
          if (Store.get(CONFIG.TAUGHT_KEY) === "1") return;
          Store.set(CONFIG.TAUGHT_KEY, "1");
          hintEl?.remove();
          hintEl = null;
        },
        /**
         * Another surface is presenting this panel's state (the extension's
         * side panel, today), so the bar steps aside — the BAR, not the
         * overlay: pins, marks and badges are the page's annotations and
         * stay. Opaque to this file like everything else: it neither knows
         * nor asks who asked.
         */
        setVisible(v) {
          el2.classList.toggle("debug-overlay-hidden", !v);
          if (!v) {
            hintEl?.remove();
            hintEl = null;
          }
          if (v) {
            api.toggleList(false);
            api.closeFlyouts();
          }
        },
        /**
         * Move the pin-count chip to sit right after one tool's button — the
         * controller says which, by an id this file hands straight back the
         * way it hands back view names. Null (no such tool registered) leaves
         * the chip where the template put it, so this cannot strand it.
         */
        attachCount(toolId) {
          const t = toolId && el2.querySelector(`[data-tool="${toolId}"]`);
          if (t) t.insertAdjacentElement("afterend", el2.querySelector("[data-c]"));
        },
        setTool(id, v) {
          const b = el2.querySelector(`[data-tool="${id}"]`);
          b?.classList.toggle("debug-overlay-armed", v);
          b?.setAttribute("aria-pressed", String(!!v));
          const fam = b?.closest(".debug-overlay-fam");
          if (fam) fam.querySelector(".debug-overlay-fam-btn").classList.toggle("debug-overlay-armed", !!fam.querySelector(".debug-overlay-tool.debug-overlay-armed"));
          api.onState?.("tool", id, v);
        },
        /**
         * The 🏷 flyout, two levels: AXIS heads at rest, and only the pressed
         * axis shows its members — four flat buttons made two different axes
         * read as one soup. Rendered from whatever the controller hands over:
         * groups of { key, glyph, title, rows: [{ key, glyph, title, armed,
         * fixed }] }. This file never learns what a view or a facet IS — keys
         * go straight back through the callback, the way data-view names do.
         *
         * Which axis is open lives on the flyout element, so re-rendering
         * after a change (armed must show the value in force) does not slam
         * the drawer shut; reopening 🏷 starts collapsed again.
         */
        setBadgeControls(groups2) {
          badgeGroups = groups2;
          renderBadgeFly();
          api.onState?.("badgeControls", groups2);
        },
        /**
         * A newer version exists. The mark RESTS (counts rest, never flash)
         * and the tooltip says both what and how — a dot with no explanation
         * is a mystery, and a mystery on the power button is worse.
         */
        setUpdate(v) {
          const b = el2.querySelector(".debug-overlay-pwr");
          b.classList.add("debug-overlay-upd");
          b.title = `Power (Alt+Shift+D) · v${CONFIG.VERSION} — v${v} available, right-click to update`;
          b.setAttribute("aria-label", `Power — update to v${v} available`);
          api.onState?.("update", v);
        },
        /* A flyout is an overlay, so Escape has to reach it — it did not, and
           the comment above the fam-btn handler claimed otherwise. Shaped like
           Menu's isOpen/close so app/ can put it in the one dismissal ladder
           without ui/ learning anything about app/. Closing collapses the badge
           drawer too: which axis is open is furniture, not a choice. */
        isFlyoutOpen: () => !!el2.querySelector(".debug-overlay-fam.debug-overlay-open"),
        closeFlyouts() {
          el2.querySelectorAll(".debug-overlay-fam.debug-overlay-open").forEach((f) => {
            f.classList.remove("debug-overlay-open");
            f.querySelector(".debug-overlay-fam-btn")?.setAttribute("aria-expanded", "false");
          });
          const fly = el2.querySelector("[data-badge-fly]");
          if (fly && fly.dataset.open) {
            fly.dataset.open = "";
            renderBadgeFly();
          }
        },
        /**
         * Whether an audit is currently showing on the page. The ⌕ flash is
         * transient by design, so once it expired the bar said "no audit has
         * run" while the page was still wearing its outlines, and nothing in
         * the bar admitted they existed or removed them. One state now drives
         * both the button and the marks.
         */
        /**
         * Whether an audit is showing, and how much it found.
         *
         * The count used to be a 1.2s flash, so once it expired the bar could not
         * answer "does this page have problems?" without opening the panel — and
         * the marks stayed on the page with nothing admitting they were there.
         * It rests on the button now. It is safe to show a bare number here only
         * because the panel header names both quantities ("N distinct problems ·
         * M occurrences"); two unlabelled numbers on one bar was the original
         * complaint, and the label is what fixed it, not hiding one of them.
         */
        setSwept(v, n) {
          const b = el2.querySelector("[data-sweep]");
          b.classList.toggle("debug-overlay-swept", !!v);
          if (v) b.textContent = String(n);
          else b.innerHTML = SWEEP_ICON;
          const what = v ? `Audit: ${n} distinct problem${n === 1 ? "" : "s"} — click to re-run` : "Audit the whole page";
          b.title = what;
          b.setAttribute("aria-label", what);
          api.onState?.("swept", !!v, n);
        },
        setRemoveMode(v) {
          el2.classList.toggle("debug-overlay-removing", v);
          const st = el2.querySelector("[data-st]");
          st.textContent = v ? "DEL" : api.isOn() ? "ON" : "OFF";
          api.onState?.("removeMode", v);
        },
        setCount(n) {
          el2.querySelector("[data-c]").textContent = String(n);
          api.onState?.("count", n);
        },
        // The popover's own surface, forwarded so CONTROLLER and BOOT still have
        // one thing to talk to. What it renders is LIST's business, not this
        // file's — that is the whole point of the split.
        isListOpen: List.isOpen,
        view: List.view,
        toggleList: List.toggle,
        setList: List.set,
        /**
         * Two flashes on one button inside the window left the message there for
         * good: the second captured the first's text as "the original" and its
         * timer, firing last, wrote that back. ⌕ twice in a second was enough,
         * and the button then read "0" forever.
         */
        flash(msg, sel = "[data-copy]") {
          api.onState?.("flash", msg, sel);
          const b = el2.querySelector(sel);
          if (!b) return;
          const live = flashing.get(b);
          const original = live ? live.original : b.innerHTML;
          if (live) clearTimeout(live.timer);
          b.textContent = msg;
          flashing.set(b, {
            original,
            timer: setTimeout(() => {
              b.innerHTML = original;
              flashing.delete(b);
            }, CONFIG.FLASH_MS)
          });
        },
        rect: () => el2.getBoundingClientRect(),
        isOn: () => el2.classList.contains("debug-overlay-on")
      };
      List.onOpen = (v) => api.onListOpen?.(v);
      List.onRowActivate = (i) => api.onRowActivate?.(i);
      List.onRowRemove = (i) => api.onRowRemove?.(i);
      List.onRowChange = (i, raw) => api.onRowChange?.(i, raw);
      el2.querySelectorAll("button").forEach((b) => {
        const name = (b.title || "").split(/[\n·—]/)[0].trim();
        if (name) b.setAttribute("aria-label", name);
      });
      el2.querySelectorAll("[data-tool], [data-view]").forEach((b) => b.setAttribute("aria-pressed", "false"));
      el2.querySelector(".debug-overlay-pwr").addEventListener("click", () => api.onToggle?.());
      el2.querySelector(".debug-overlay-pwr").addEventListener("contextmenu", (e) => {
        e.preventDefault();
        api.onUpdateMenu?.(e.clientX, e.clientY);
      });
      el2.querySelectorAll(".debug-overlay-fam-btn").forEach((b) => {
        b.addEventListener("click", () => {
          const fam = b.parentElement;
          const open = !fam.classList.contains("debug-overlay-open");
          api.closeFlyouts();
          fam.classList.toggle("debug-overlay-open", open);
          b.setAttribute("aria-expanded", String(open));
        });
      });
      document.addEventListener("pointerdown", (e) => {
        if (e.target.closest && e.target.closest(".debug-overlay-fam")) return;
        api.closeFlyouts();
      }, true);
      el2.querySelectorAll("[data-tool]").forEach((b) => {
        b.addEventListener("click", () => api.onTool?.(b.dataset.tool));
        b.addEventListener("contextmenu", (e) => {
          e.preventDefault();
          api.toggleList(void 0, `tool:${b.dataset.tool}`);
        });
      });
      el2.querySelector("[data-badge] .debug-overlay-fam-btn").addEventListener("click", () => {
        const fly = el2.querySelector("[data-badge-fly]");
        if (fly.dataset.open) {
          fly.dataset.open = "";
          renderBadgeFly();
        }
      });
      el2.querySelector("[data-c]").addEventListener("click", () => api.toggleList(void 0, "pins"));
      el2.querySelector("[data-settings]").addEventListener("click", () => api.toggleList(void 0, "settings"));
      el2.querySelector("[data-sweep]").addEventListener("click", () => api.onSweep?.());
      el2.querySelector("[data-copy]").addEventListener("click", () => api.onCopy?.());
      el2.querySelector("[data-clear]").addEventListener("click", () => api.onClear?.());
      let side = "right";
      function applyPos(x, y) {
        el2.dataset.side = side;
        const r = el2.getBoundingClientRect();
        x = Math.max(4, Math.min(x, innerWidth - r.width - 4));
        y = Math.max(4, Math.min(y, innerHeight - r.height - 4));
        el2.style.left = x + "px";
        el2.style.top = y + "px";
        el2.style.right = "auto";
        return { x, y };
      }
      function snap() {
        const r = el2.getBoundingClientRect();
        const d = { left: r.left, right: innerWidth - r.right, top: r.top, bottom: innerHeight - r.bottom };
        side = Object.keys(d).reduce((a, b) => d[a] <= d[b] ? a : b);
        let x = r.left, y = r.top;
        if (side === "left") x = CONFIG.EDGE_MARGIN;
        if (side === "right") x = innerWidth - r.width - CONFIG.EDGE_MARGIN;
        if (side === "top") y = CONFIG.EDGE_MARGIN;
        if (side === "bottom") y = innerHeight - r.height - CONFIG.EDGE_MARGIN;
        const p = applyPos(x, y);
        Store.set(CONFIG.POS_KEY, JSON.stringify({ x: p.x, y: p.y, side }));
      }
      (function restore() {
        try {
          const s = JSON.parse(Store.get(CONFIG.POS_KEY) || "null");
          if (s) {
            side = s.side || "right";
            applyPos(s.x, s.y);
            return;
          }
        } catch {
        }
        applyPos(innerWidth - 60, innerHeight / 2 - 110);
      })();
      let tuckTimer = 0;
      function untuck() {
        el2.classList.remove("debug-overlay-tucked");
        el2.style.transform = "";
      }
      function tuck() {
        untuck();
        const r = el2.getBoundingClientRect();
        let t = "";
        if (side === "right") t = `translateX(${Math.round(innerWidth - CONFIG.PEEK - r.left)}px)`;
        if (side === "left") t = `translateX(${Math.round(CONFIG.PEEK - r.right)}px)`;
        if (side === "bottom") t = `translateY(${Math.round(innerHeight - CONFIG.PEEK - r.top)}px)`;
        if (side === "top") t = `translateY(${Math.round(CONFIG.PEEK - r.bottom)}px)`;
        el2.classList.add("debug-overlay-tucked");
        el2.style.transform = t;
      }
      function scheduleTuck() {
        clearTimeout(tuckTimer);
        if (api.isOn() || List.isOpen()) {
          untuck();
          return;
        }
        tuckTimer = setTimeout(() => {
          if (!api.isOn() && !el2.matches(":hover")) tuck();
        }, CONFIG.TUCK_DELAY);
      }
      el2.addEventListener("pointerenter", () => {
        clearTimeout(tuckTimer);
        untuck();
      });
      el2.addEventListener("pointerleave", scheduleTuck);
      let drag = null;
      el2.addEventListener("pointerdown", (e) => {
        if (e.target.closest("button")) return;
        const r = el2.getBoundingClientRect();
        drag = {
          dx: e.clientX - r.left,
          dy: e.clientY - r.top,
          w: r.width,
          h: r.height,
          // fixed for the whole gesture
          ox: r.left,
          oy: r.top,
          // where it started, to translate from
          x: r.left,
          y: r.top,
          // latest wanted position
          raf: 0
        };
        untuck();
        el2.setPointerCapture(e.pointerId);
        e.preventDefault();
      });
      const wanted = (d) => ({
        x: Math.max(4, Math.min(d.x, innerWidth - d.w - 4)),
        y: Math.max(4, Math.min(d.y, innerHeight - d.h - 4))
      });
      el2.addEventListener("pointermove", (e) => {
        if (!drag) return;
        drag.x = e.clientX - drag.dx;
        drag.y = e.clientY - drag.dy;
        if (drag.raf) return;
        drag.raf = requestAnimationFrame(() => {
          if (!drag) return;
          drag.raf = 0;
          el2.classList.add("debug-overlay-dragging");
          const p = wanted(drag);
          el2.style.translate = `${p.x - drag.ox}px ${p.y - drag.oy}px`;
          if (List.isOpen()) List.place();
        });
      });
      const endDrag = () => {
        if (!drag) return;
        cancelAnimationFrame(drag.raf);
        const p = wanted(drag);
        drag = null;
        el2.style.translate = "";
        applyPos(p.x, p.y);
        el2.classList.remove("debug-overlay-dragging");
        snap();
        scheduleTuck();
        if (List.isOpen()) List.place();
      };
      el2.addEventListener("pointerup", endDrag);
      el2.addEventListener("pointercancel", endDrag);
      addEventListener("resize", () => {
        snap();
        if (List.isOpen()) List.place();
      });
      return api;
    })();
  }

  // src/services/badge/options.js
  var BadgeFace = defineService({
    id: "badge",
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z" /><circle cx="7.5" cy="7.5" r=".5" fill="currentColor" /></svg>',
    // lucide 'tag' (ISC)
    title: "Badge — view and facets",
    was: "grid",
    options() {
      return [
        {
          key: "view",
          label: "Badge view",
          def: CONFIG.BADGE_MODES[0],
          values: CONFIG.BADGE_MODES,
          glyphs: {
            compact: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M5 12h14" /></svg>',
            full: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M3 5h18" /><path d="M3 12h18" /><path d="M3 19h18" /></svg>'
          },
          // lucide minus / align-justify
          affects: "inspect"
        },
        /* Labels LEAD with the facet's family name — CURRENT · ISSUE ·
           RECOMMENDATION — because that vocabulary is how the docs and
           the architecture talk about them, and a member that does not
           say its own name sent a real user hunting for it. */
        {
          key: "issues",
          label: "Issue — mark what fails (⚠)",
          def: true,
          type: "toggle",
          glyph: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" /><path d="M12 9v4" /><path d="M12 17h.01" /></svg>',
          affects: "inspect"
        },
        // lucide triangle-alert
        {
          key: "suggest",
          label: "Recommendation — what would pass (→)",
          def: false,
          type: "toggle",
          glyph: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>',
          affects: "inspect"
        }
        // lucide arrow-right
      ];
    },
    /**
     * The 🏷 flyout, two levels deep: press the mark and you get the two
     * AXES — ◫ View and ◈ Facets — and only pressing an axis reveals its
     * members. Four flat buttons made the two axes read as one soup.
     *
     * DERIVED from options() in this same file, so the flyout and the ⚙
     * rows come from one declaration: the values option is the View
     * axis's radio, every toggle is a Facets member. CURRENT is the one
     * member with no option behind it — it is listed because the family
     * has three facets, and FIXED because switching it off would leave
     * 🏷 controlling nothing: it IS the badge.
     */
    groups() {
      const opts = this.options();
      const view = opts.find((o) => o.values);
      return [
        {
          key: "view",
          glyph: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><rect width="18" height="18" x="3" y="3" rx="2" /><path d="M12 3v18" /></svg>',
          // lucide 'columns-2'
          title: "View — how much ink; press to choose",
          /* `label` is the member's SHORT name for faces that print text
             beside the glyph (the side panel's chips) — the first clause of
             these titles is the axis name, so deriving it there printed
             "Badge view" on both members and nothing told them apart */
          rows: view.values.map((v) => ({
            key: `${view.key}:${v}`,
            glyph: (view.glyphs || {})[v] || String(v),
            title: `${view.label} — ${v}`,
            label: String(v),
            armed: Tools.setting(this, view.key) === v
          }))
        },
        {
          key: "facets",
          glyph: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41l-7.59-7.59a2.41 2.41 0 0 0-3.41 0Z" /></svg>',
          // lucide 'diamond'
          title: "Facets — which kinds of content render; press to choose",
          rows: [
            {
              fixed: true,
              glyph: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><line x1="5" x2="19" y1="9" y2="9" /><line x1="5" x2="19" y1="15" y2="15" /></svg>',
              armed: true,
              // lucide 'equal'
              title: "Current — the component's own fields. Always on: this is the badge itself",
              label: "Current"
            },
            ...opts.filter((o) => o.type === "toggle").map((o) => ({
              key: o.key,
              glyph: o.glyph || o.label,
              title: o.label,
              label: o.label.split(" — ")[0],
              armed: !!Tools.setting(this, o.key)
            }))
          ]
        }
      ];
    }
  });

  // src/services/badge/index.js
  var Badges = {
    /** The VIEW axis's live value — the renderer asks per frame. */
    view: () => Tools.setting(BadgeFace, "view"),
    /** The FACETS, as the neutral contract object build() stamps onto the
     *  info it hands the tools. Lenses read it from there (and the ISSUE
     *  gate sits in Tools.annotator), so no tool ever imports this file. */
    facets: () => ({
      issues: !!Tools.setting(BadgeFace, "issues"),
      suggest: !!Tools.setting(BadgeFace, "suggest")
    }),
    build(info, compact8) {
      info.facets = Badges.facets();
      const parts = [];
      for (const t of Tools.active()) {
        const fn = compact8 ? t.compact || null : t.badge || null;
        if (!fn) continue;
        const html = fn.call(t, info);
        if (html) parts.push(html);
      }
      return parts.join(" · ");
    }
  };

  // src/ui/placement.js
  var Place = /* @__PURE__ */ (() => {
    let taken = [];
    function put(node, x, y, w, h) {
      node.style.left = x + "px";
      node.style.top = y + "px";
      if (w != null) node.style.width = w + "px";
      if (h != null) node.style.height = h + "px";
    }
    function claim(x, y, w, h) {
      taken.push(U.rectOf(x - 2, y - 2, w + 4, h + 4));
    }
    function smart(node, anchor, opts = {}) {
      const w = opts.size ? opts.size.w : node.offsetWidth;
      const h = opts.size ? opts.size.h : node.offsetHeight;
      const M = CONFIG.BADGE_MARGIN, PAD = 4;
      const cands = [
        { x: anchor.left, y: anchor.bottom + M, cost: 0 },
        { x: anchor.left, y: anchor.top - h - M, cost: 1 },
        { x: anchor.right - w, y: anchor.bottom + M, cost: 2 },
        { x: anchor.right - w, y: anchor.top - h - M, cost: 3 },
        { x: anchor.right + M, y: anchor.top, cost: 4 },
        { x: anchor.left - w - M, y: anchor.top, cost: 5 },
        { x: anchor.left + M, y: anchor.top + M, cost: 8 }
      ];
      const NUDGES = [{ x: 0, y: 0 }];
      for (let s = 1; s <= 5; s++) {
        NUDGES.push({ x: 0, y: s * (h + PAD) }, { x: 0, y: -s * (h + PAD) });
        NUDGES.push({ x: s * (w * 0.55 + PAD), y: 0 }, { x: -s * (w * 0.55 + PAD), y: 0 });
      }
      let best = null;
      outer:
        for (const c of cands) {
          for (let n = 0; n < NUDGES.length; n++) {
            const x = Math.max(PAD, Math.min(c.x + NUDGES[n].x, innerWidth - w - PAD));
            const y = Math.max(PAD, Math.min(c.y + NUDGES[n].y, innerHeight - h - PAD));
            const r = U.rectOf(x, y, w, h);
            let score = c.cost + n * 1.5;
            for (const t of taken) score += U.overlap(r, t) / 90;
            if (opts.avoid)
              score += U.overlap(r, U.rectOf(
                opts.avoid.left,
                opts.avoid.top,
                opts.avoid.width,
                opts.avoid.height
              )) / 900;
            if (!best || score < best.score) best = { x, y, score };
            if (score < 0.5) break outer;
          }
        }
      put(node, best.x, best.y);
      claim(best.x, best.y, w, h);
      const near = best.y <= anchor.bottom + M + 2 && best.y + h >= anchor.top - M - 2 && best.x <= anchor.right + M + 2 && best.x + w >= anchor.left - M - 2;
      if (!near && opts.leader !== false) {
        const ax = Math.max(anchor.left, Math.min(best.x + w / 2, anchor.right));
        const ay = Math.max(anchor.top, Math.min(best.y + h / 2, anchor.bottom));
        const bx = Math.max(best.x, Math.min(ax, best.x + w));
        const by = Math.max(best.y, Math.min(ay, best.y + h));
        const ln = document.createElement("div");
        ln.className = "debug-overlay-leader";
        if (Math.abs(bx - ax) >= Math.abs(by - ay))
          put(ln, Math.min(ax, bx), Math.round(ay), Math.abs(bx - ax) || 1, 1);
        else put(ln, Math.round(ax), Math.min(ay, by), 1, Math.abs(by - ay) || 1);
        layer.append(ln);
      }
    }
    return {
      put,
      claim,
      smart,
      reset() {
        taken = [];
        const br = WebPanel.rect();
        taken.push(U.rectOf(br.left - 8, br.top - 8, br.width + 16, br.height + 16));
      }
    };
  })();

  // src/ui/renderer.js
  var Render = /* @__PURE__ */ (() => {
    let raf = 0;
    function now() {
      layer.textContent = "";
      Place.reset();
      if (!State.enabled) return;
      const had = State.pins.length;
      State.pins = State.pins.filter((p) => document.contains(p.el));
      if (State.pins.length !== had) Render.onPinsPruned?.();
      const pinned = new Set(State.pins.map((p) => p.el));
      let pendingIdx = -1;
      for (const t of Tools.active()) {
        const idx = t.pendingIndex?.call(t) ?? -1;
        if (idx >= 0) {
          pendingIdx = idx;
          break;
        }
      }
      const pinInfo = State.pins.map((p, idx) => {
        const waiting = idx === pendingIdx;
        const isTarget = State.removeMode && State.removeTarget === p;
        const isFlash = State.flashPins && State.flashPins.includes(p);
        const kindCls = ` debug-overlay-${p.kind}` + (waiting ? " debug-overlay-waiting" : "") + (isTarget ? " debug-overlay-rmtarget" : "") + (isFlash ? " debug-overlay-flash" : "");
        const i = U.info(p.el);
        const box = document.createElement("div");
        box.className = "debug-overlay-box debug-overlay-pinbox" + kindCls;
        Place.put(box, i.r.left, i.r.top, i.r.width, i.r.height);
        const n = document.createElement("div");
        n.className = "debug-overlay-pin-num" + kindCls;
        n.textContent = waiting ? p.id + "…" : p.id;
        layer.append(box, n);
        const onScreen = !(i.r.bottom < 0 || i.r.top > innerHeight || i.r.right < 0 || i.r.left > innerWidth);
        if (onScreen) {
          const nx = Math.max(2, i.r.left - 10), ny = Math.max(2, i.r.top - 10);
          Place.put(n, nx, ny);
          Place.claim(nx, ny, waiting ? 32 : 22, 22);
        } else {
          n.remove();
        }
        if (State.removeMode) {
          const rm = document.createElement("div");
          rm.className = "debug-overlay-rmchip" + (isTarget ? " debug-overlay-target" : "");
          rm.textContent = "✕";
          layer.append(rm);
          const rx = Math.min(innerWidth - 20, Math.max(2, i.r.right - 9));
          const ry = Math.max(2, i.r.top - 9);
          Place.put(rm, rx, ry);
          Place.claim(rx, ry, 18, 18);
        }
        return { p, i };
      });
      if (State.current && !document.contains(State.current)) State.current = null;
      const cur = !State.removeMode && State.current && !pinned.has(State.current) ? State.current : null;
      if (cur) {
        const i = U.info(cur);
        const box = document.createElement("div");
        box.className = "debug-overlay-box debug-overlay-pinbox debug-overlay-note";
        Place.put(box, i.r.left, i.r.top, i.r.width, i.r.height);
        layer.append(box);
      }
      const hoverLive = !State.removeMode && State.hoverEl && State.hoverEl !== cur && document.contains(State.hoverEl) && !pinned.has(State.hoverEl);
      if (hoverLive) {
        const i = U.info(State.hoverEl);
        const box = document.createElement("div");
        box.className = "debug-overlay-box debug-overlay-hover";
        Place.put(box, i.r.left, i.r.top, i.r.width, i.r.height);
        layer.append(box);
      }
      const marked = /* @__PURE__ */ new Map();
      const marks = (found) => {
        for (const f of found.slice(0, CONFIG.MARK_LIMIT)) {
          if (!document.contains(f.el)) continue;
          const cls = f.verdict === "review" ? "review" : f.severity;
          const at = marked.get(f.el);
          if (at) {
            at.n++;
            at.rules.add(f.rule);
            if ((CONFIG.SEVERITY[cls] || 0) > (CONFIG.SEVERITY[at.cls] || 0)) at.cls = cls;
            continue;
          }
          marked.set(f.el, {
            r: f.el.getBoundingClientRect(),
            cls,
            n: 1,
            rules: /* @__PURE__ */ new Set([f.rule])
          });
        }
      };
      const paintMarks = () => {
        const tips = [];
        for (const m of marked.values()) {
          const box = document.createElement("div");
          box.className = "debug-overlay-box debug-overlay-flag debug-overlay-" + m.cls;
          Place.put(box, m.r.left, m.r.top, m.r.width, m.r.height);
          layer.append(box);
          const r = m.r;
          if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) continue;
          const tip = document.createElement("div");
          tip.className = "debug-overlay-tip debug-overlay-" + m.cls;
          tip.textContent = label(m);
          layer.append(tip);
          tips.push({ tip, r });
        }
        for (const t of tips) t.size = { w: t.tip.offsetWidth, h: t.tip.offsetHeight };
        for (const t of tips) Place.smart(t.tip, t.r, { avoid: t.r, size: t.size });
      };
      const label = (m) => [...m.rules].join(" ") + (m.n > 1 ? ` ×${m.n}` : "");
      const ctx = { layer, Place, State, U, marks, found: [] };
      for (const t of Tools.active()) {
        ctx.found = State.sweep && State.sweep.byTool[t.id] || [];
        t.draw?.call(t, ctx);
      }
      paintMarks();
      pinInfo.forEach(({ p, i }) => {
        if (i.r.bottom < 0 || i.r.top > innerHeight || i.r.right < 0 || i.r.left > innerWidth) return;
        const full = Badges.view() === "full" || State.hoverEl === p.el;
        const html = Badges.build(i, !full);
        if (!html) return;
        const b = document.createElement("div");
        b.className = "debug-overlay-badge";
        b.innerHTML = `<span class="debug-overlay-rad">#${p.id}</span> · ${html}`;
        layer.append(b);
        Place.smart(b, i.r, { avoid: i.r });
      });
      if (cur) {
        const i = U.info(cur);
        if (!(i.r.bottom < 0 || i.r.top > innerHeight || i.r.right < 0 || i.r.left > innerWidth)) {
          const full = Badges.view() === "full" || State.hoverEl === cur;
          const html = Badges.build(i, !full);
          if (html) {
            const b = document.createElement("div");
            b.className = "debug-overlay-badge";
            b.innerHTML = html;
            layer.append(b);
            Place.smart(b, i.r, { avoid: i.r });
          }
        }
      }
      if (hoverLive) {
        const i = U.info(State.hoverEl);
        const html = Badges.build(i, false);
        if (html) {
          const b = document.createElement("div");
          b.className = "debug-overlay-badge";
          b.innerHTML = html;
          layer.append(b);
          Place.smart(b, i.r, { avoid: i.r });
        }
      }
      WebPanel.setCount(State.pins.length);
    }
    return {
      now,
      onPinsPruned: null,
      schedule() {
        cancelAnimationFrame(raf);
        raf = requestAnimationFrame(now);
      }
    };
  })();

  // src/services/findings/index.js
  var Sweep = {
    /**
     * One read-only pass. Rules only speak when something is wrong, so what
     * comes back is a list of problems, not a list of elements.
     *
     * The overlay's root is appended to documentElement, so walking body's
     * subtree already excludes it — no per-element containment check.
     *
     * EVERY tool that can judge runs, armed or not. Arming decides what is
     * drawn on screen and nothing else. Tying the two together meant one
     * control carried two meanings, and the failure was silent in the worst
     * direction: with the only rule disarmed, a page full of problems audited
     * clean. You can always narrow a list of findings; you can never find
     * what was not checked.
     */
    /**
     * Call one hook across some tools and stamp the producer onto whatever
     * comes back, so no rule has to name itself and no consumer has to guess.
     * It is what lets draw() be handed only its own findings — and the report
     * look up the rule's own documentation.
     */
    collect(tools, hook, arg) {
      const out = [];
      for (const t of tools) {
        const f = t[hook]?.call(t, arg);
        if (!f || !f.length) continue;
        for (const one of f) one.tool = t.id;
        out.push(...f);
      }
      return out;
    },
    run() {
      const perEl = Tools.withHook("audit");
      const perPage = Tools.withHook("auditPage");
      const all = [.../* @__PURE__ */ new Set([...perEl, ...perPage])];
      const result = {
        findings: [],
        rules: all.length,
        elements: 0,
        byTool: {},
        skipped: { display: 0, visibility: 0, opacity: 0 },
        shadow: 0,
        frames: 0
      };
      if (!all.length || !document.body) return result;
      for (const t of all) result.byTool[t.id] = [];
      const seen = perPage.length ? [] : null;
      const els = document.body.querySelectorAll("*");
      let since = performance.now();
      let hiddenRoot = null, hiddenWhy = "display";
      const step = (idx) => {
        for (; idx < els.length; idx++) {
          if ((idx & 255) === 255 && performance.now() - since > CONFIG.SWEEP_SLICE) {
            const at = idx;
            return new Promise((res) => setTimeout(() => {
              since = performance.now();
              res(step(at));
            }, 0));
          }
          const el2 = els[idx];
          if (hiddenRoot && !hiddenRoot.contains(el2)) hiddenRoot = null;
          if (hiddenRoot) {
            result.skipped[hiddenWhy]++;
            continue;
          }
          const cs = getComputedStyle(el2);
          if (cs.display === "none") {
            result.skipped.display++;
            hiddenRoot = el2;
            hiddenWhy = "display";
            continue;
          }
          if (cs.visibility === "hidden") {
            result.skipped.visibility++;
            continue;
          }
          if (cs.opacity === "0") {
            result.skipped.opacity++;
            hiddenRoot = el2;
            hiddenWhy = "opacity";
            continue;
          }
          result.elements++;
          if (el2.shadowRoot) result.shadow++;
          const i = U.info(el2, cs);
          if (seen) seen.push(i);
          for (const f of Sweep.collect(perEl, "audit", i)) {
            result.findings.push(f);
            result.byTool[f.tool].push(f);
          }
        }
        return finish();
      };
      const finish = () => {
        result.frames = document.querySelectorAll("iframe, frame").length;
        for (const f of Sweep.collect(perPage, "auditPage", seen || [])) {
          result.findings.push(f);
          result.byTool[f.tool].push(f);
        }
        return result;
      };
      return step(0);
    },
    /**
     * …AND WHAT IT DID NOT COVER, which is the half that was missing.
     *
     * A count of what was checked reads as the whole page. It is the whole
     * page minus everything gated out before a rule saw it, minus every
     * subtree behind a boundary this pass cannot cross. Those are different
     * kinds of absence and both change what a clean result means: hidden
     * elements may simply be a closed menu, while an iframe is a whole
     * document nobody looked at.
     *
     * Silent when there is nothing to say — a page with no frames, no shadow
     * roots and nothing hidden gets no clause, because a scope note that
     * always prints is furniture and stops being read.
     */
    unchecked(s) {
      const parts = [];
      const k = s.skipped || {};
      const hidden = (k.display || 0) + (k.visibility || 0) + (k.opacity || 0);
      if (hidden) {
        const why = [];
        if (k.display) why.push(`${k.display} display:none`);
        if (k.visibility) why.push(`${k.visibility} hidden`);
        if (k.opacity) why.push(`${k.opacity} opacity:0`);
        parts.push(`${hidden} not rendered (${why.join(", ")})`);
      }
      if (s.frames) parts.push(`${s.frames} frame${s.frames === 1 ? "" : "s"} not entered`);
      if (s.shadow) parts.push(`at least ${s.shadow} shadow root${s.shadow === 1 ? "" : "s"} not entered`);
      return parts.length ? `
   not checked: ${parts.join(" · ")}` : "";
    },
    /**
     * Collapse repeats, then rank worst-first. `key` says which findings are
     * the same problem; only the rule that produced them knows, so it supplies
     * it and this falls back to rule + message when it does not.
     *
     * This is not cosmetic. A page can hand back thousands of findings that
     * are one problem repeated — a nav of identical links, a table of
     * identical cells — and a list nobody can read is a list nobody uses.
     */
    group(findings2) {
      const by = /* @__PURE__ */ new Map();
      findings2.forEach((f, seq) => {
        const k = f.key || `${f.rule}|${f.message}`;
        const g = by.get(k);
        if (g) {
          g.n++;
          return;
        }
        by.set(k, { ...f, n: 1, seq });
      });
      const said = (g) => g.verdict === "review" ? 0 : 1;
      const rank = (g) => CONFIG.SEVERITY[g.severity] ?? 0;
      return [...by.values()].sort((a, b) => said(b) - said(a) || rank(b) - rank(a) || a.seq - b.seq);
    }
  };

  // src/services/report/index.js
  var Report = {
    text() {
      const active = Tools.active();
      const L = [
        `# UI debug report`,
        `url: ${location.href}`,
        `viewport: ${innerWidth}×${innerHeight} @ dpr ${devicePixelRatio}`,
        // sorted: this line is an INVENTORY, not a sequence — registration order
        // leaked into it once (a folder rename reordered it) and role order
        // would leak the same way. Alphabetical is immune to both.
        `tools: ${active.map((t) => t.id).sort().join(", ") || "none"}`,
        ""
      ];
      const found = [];
      if (State.current && document.contains(State.current)) {
        const i = U.info(State.current);
        L.push(`[selected] ${U.selectorOf(i.el)}`);
        for (const t of active) L.push(...t.report?.call(t, i) || []);
        found.push(...Sweep.collect(active, "audit", i));
        L.push("");
      }
      State.pins.slice().sort((a, b) => a.id - b.id).forEach((p) => {
        const i = U.info(p.el);
        L.push(`[#${p.id}] (${p.kind}) ${U.selectorOf(i.el)}`);
        for (const t of active) L.push(...t.report?.call(t, i) || []);
        found.push(...Sweep.collect(active, "audit", i));
        L.push("");
      });
      for (const t of active) {
        const tail = t.reportTail?.call(t) || [];
        if (tail.length) L.push(...tail);
      }
      const list = State.sweep ? State.sweep.findings : found;
      const groups2 = Sweep.group(list);
      if (State.sweep || groups2.length) {
        L.push("", `## findings — ${groups2.length} problem${groups2.length === 1 ? "" : "s"} · ${list.length} occurrence${list.length === 1 ? "" : "s"}${Report.scope()}`);
        for (const g of groups2) {
          const tag = g.verdict === "review" ? "review" : g.severity;
          L.push(`[${tag}] ${g.rule}${g.n > 1 ? ` ×${g.n}` : ""}: ${g.message}`);
          L.push(`    ${U.selectorOf(g.el)}`);
        }
        if (!groups2.length) L.push("(none)");
        const docs = /* @__PURE__ */ new Map();
        for (const g of groups2) {
          const d = Tools.byId(g.tool)?.rules?.[g.rule];
          if (d && !docs.has(g.rule)) docs.set(g.rule, d);
        }
        if (docs.size) {
          L.push("", "## rules");
          for (const [id, d] of docs) {
            L.push(id);
            if (d.help) L.push(`  ${d.help}`);
            if (d.why) L.push(`  ${d.why}`);
            if (d.docs) L.push(`  ${d.docs}`);
          }
        }
      }
      return L.join("\n");
    },
    /** What the findings above cover, so a zero among them can be read. */
    scope() {
      const s = State.sweep;
      if (!s) return " · pinned elements only";
      return ` · whole page · ${s.rules} rule${s.rules === 1 ? "" : "s"} · ${s.elements} elements` + // the page could not show them all; this text can
      (Object.values(s.byTool).some((f) => f.length > CONFIG.MARK_LIMIT) ? ` · marks from the first ${CONFIG.MARK_LIMIT} findings per rule` : "") + Sweep.unchecked(s);
    },
    /**
     * Put text on the clipboard. Separate from copy() because it is not only
     * the report that ever wants this — a tool that picks something off the
     * page needs the same two-step, and a second copy of the fallback is a
     * second thing to get wrong.
     */
    async toClipboard(txt) {
      try {
        await navigator.clipboard.writeText(txt);
      } catch {
        const t = document.createElement("textarea");
        t.value = txt;
        document.body.append(t);
        t.select();
        document.execCommand("copy");
        t.remove();
      }
    },
    /**
     * PREPARE, then build — the report as a string. Report.text() is
     * synchronous and every other line in this file depends on that — but a
     * tool can need something fetched before it can answer, and the
     * alternative was a report that said "ask again" the first time. Only
     * ARMED tools, only on this path: a copy is a deliberate act, which is
     * what makes it the right place to do work that a hover must never do.
     * One failing tool does not cost the report — it simply has nothing to
     * add.
     *
     * Split from copy() when a second reader arrived: the remote door hands
     * this to an AI over the worker's socket, and the clipboard is the one
     * thing that reader must never touch. copy() is build() plus the
     * clipboard, so both readers get the same text by construction.
     *
     * Returns the TEXT, or a promise of it — A PROMISE ONLY WHEN THERE IS
     * SOMETHING TO WAIT FOR, the same contract Sweep.run() keeps. An `async`
     * here would cost a microtask on every copy, including the overwhelming
     * majority that prepare nothing, and every reader of the clipboard would
     * inherit a hop it never needed: the suite reads the clipboard in the
     * same breath as the click, and the first version of this split made
     * every report-reading assertion in it see null.
     */
    build() {
      const waits = [];
      for (const t of Tools.withHook("prepare", true)) {
        try {
          const r = t.prepare.call(t);
          if (r && typeof r.then === "function") waits.push(r.catch(() => {
          }));
        } catch {
        }
      }
      if (!waits.length) return Report.text();
      return Promise.all(waits).then(() => Report.text());
    },
    copy() {
      const put = (txt) => Report.toClipboard(txt).then(() => WebPanel.flash("✓"));
      const built = Report.build();
      return built && typeof built.then === "function" ? built.then(put) : put(built);
    },
    /**
     * The take-away actions for ONE element — what the target menu offers.
     *
     * They live HERE because copying is this service's capability, always
     * on the way ⧉ is: there used to be a `pick` tool armouring exactly
     * this behind a button and a Ctrl+click, and an on/off switch for
     * "copy" guards nothing — the menu takes no click away from anyone.
     * The surface (ui/menu.js) is handed these rows by the door (app/) and
     * never learns what one does.
     *
     * Copy text only exists when there IS text — a row that copies an
     * empty string is a control that does nothing, which is worse than
     * no control.
     */
    targetActions(el2) {
      const rows = [{
        label: "Copy selector",
        run: async () => {
          await Report.toClipboard(U.selectorOf(el2));
          WebPanel.flash("✓");
        }
      }];
      const txt = (el2.textContent || "").trim();
      if (txt) rows.push({
        label: "Copy text",
        run: async () => {
          await Report.toClipboard(txt);
          WebPanel.flash("✓");
        }
      });
      return rows;
    }
  };

  // src/app/interactions.js
  var Interactions = {
    // is the user typing? then keys belong to the page, not to us
    typing(e) {
      const t = e.target;
      return t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName || ""));
    },
    // Is this pointer event ours to swallow? Alt is the page's escape hatch,
    // and the panel handles its own clicks.
    ours(e) {
      return State.enabled && !e.altKey && !root.contains(e.target);
    },
    /**
     * Offer an event to the armed tools before the overlay's own default.
     *
     * WHY: every hook until now was read-or-render — a tool could describe the
     * page and judge it, but nothing could act on it, so anything that changes
     * what you clicked had nowhere to live. This is the one place input enters,
     * so it is the one place that can hand it on, and it does so by hook: no
     * tool is named here and none ever will be.
     *
     * The first tool to say it consumed the event ends it. Two tools acting on
     * one click is a page doing two things nobody asked for, and a pin landing
     * underneath an edit is the same bug wearing the overlay's own clothes.
     */
    claimed(type, ev, el2) {
      const ctx = {
        type,
        ev,
        el: el2,
        redraw: Render.schedule,
        toClipboard: Report.toClipboard
      };
      for (const t of Tools.withHook("intercept", true))
        if (t.intercept.call(t, ctx)) return true;
      return false;
    },
    // in remove mode only pins are targetable — pick the innermost one
    pinAt(x, y) {
      let best = null, bestArea = Infinity;
      for (const p of State.pins) {
        if (!document.contains(p.el)) continue;
        const r = p.el.getBoundingClientRect();
        if (x < r.left || x > r.right || y < r.top || y > r.bottom) continue;
        const area = r.width * r.height;
        if (area < bestArea) {
          best = p;
          bestArea = area;
        }
      }
      return best;
    },
    install(ctl) {
      addEventListener("keydown", (e) => {
        const H = CONFIG.HOTKEY;
        if (e.altKey === H.alt && e.shiftKey === H.shift && e.ctrlKey === H.ctrl && e.code === H.code) {
          e.preventDefault();
          ctl.togglePower();
          return;
        }
        if (e.code === CONFIG.REMOVE_KEY && State.enabled && !State.removeMode && !e.ctrlKey && !e.metaKey && !e.altKey && !Interactions.typing(e)) {
          e.preventDefault();
          ctl.setRemoveMode(true);
          return;
        }
        if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && e.code === "KeyC" && State.enabled && !Interactions.typing(e)) {
          const t = State.hoverEl || State.current;
          if (t && document.contains(t)) {
            e.preventDefault();
            Report.toClipboard(U.selectorOf(t));
            WebPanel.flash("✓");
          }
          return;
        }
        if (e.key === "Escape" && State.enabled && !Interactions.typing(e)) {
          if (Menu.isOpen()) Menu.close();
          else if (State.removeMode) ctl.setRemoveMode(false);
          else if (WebPanel.isListOpen()) WebPanel.toggleList(false);
          else if (WebPanel.isFlyoutOpen()) WebPanel.closeFlyouts();
          else if (State.pins.length || State.current) ctl.clearPins();
        }
      }, true);
      addEventListener("keyup", (e) => {
        if (e.code === CONFIG.REMOVE_KEY && State.removeMode) ctl.setRemoveMode(false);
      }, true);
      addEventListener("blur", () => {
        if (State.removeMode) ctl.setRemoveMode(false);
      });
      addEventListener("mousemove", (e) => {
        if (!State.enabled) return;
        if (State.removeMode) {
          const p = Interactions.pinAt(e.clientX, e.clientY);
          if (p !== State.removeTarget) {
            State.removeTarget = p;
            Render.schedule();
          }
          return;
        }
        const el2 = document.elementFromPoint(e.clientX, e.clientY);
        if (!el2 || root.contains(el2)) {
          if (State.hoverEl) {
            State.hoverEl = null;
            Render.schedule();
          }
          return;
        }
        if (el2 !== State.hoverEl) {
          State.hoverEl = el2;
          Render.schedule();
        }
      }, true);
      for (const type of ["mousedown", "mouseup", "dblclick"]) {
        addEventListener(type, (e) => {
          if (e.button !== 0 || !Interactions.ours(e)) return;
          e.preventDefault();
          e.stopPropagation();
        }, true);
      }
      addEventListener("click", (e) => {
        if (!Interactions.ours(e)) return;
        e.preventDefault();
        e.stopPropagation();
        if (State.removeMode) {
          const p = Interactions.pinAt(e.clientX, e.clientY);
          if (p) ctl.removePin(p);
          return;
        }
        const el2 = document.elementFromPoint(e.clientX, e.clientY);
        if (!el2 || root.contains(el2)) return;
        if (Interactions.claimed("click", e, el2)) return;
        if (!Tools.withHook("keeps", true).length) {
          ctl.setCurrent(el2);
          return;
        }
        const grouped = e.shiftKey && Tools.withHook("groups", true).length > 0;
        const kind = !grouped ? CONFIG.PIN_KIND.PLAIN : e.ctrlKey || e.metaKey ? CONFIG.PIN_KIND.CHAIN : CONFIG.PIN_KIND.SHIFT;
        ctl.togglePin(el2, kind);
      }, true);
      addEventListener("contextmenu", (e) => {
        if (!Interactions.ours(e)) return;
        const el2 = document.elementFromPoint(e.clientX, e.clientY);
        if (!el2 || root.contains(el2)) return;
        const rows = Report.targetActions(el2);
        if (!rows.length) return;
        e.preventDefault();
        e.stopPropagation();
        Menu.open(e.clientX, e.clientY, rows);
      }, true);
      addEventListener("scroll", Render.schedule, true);
      addEventListener("resize", Render.schedule);
    }
  };

  // src/core/protocol.js
  var PROTOCOL_VERSION = 1;
  var FIELD2 = "debugOverlay";
  var LEGACY_FIELD = "dbgov";
  var STATE = {
    on: null,
    // (bool)
    tools: null,
    // (roster: [{id, icon, title, fam, roles}], coreVersion) — on hello
    tool: null,
    // (id, armed)
    count: null,
    // (n)
    swept: null,
    // (showing, n)
    removeMode: null,
    // (bool)
    update: null,
    // (version) — a KNOWN newer version exists
    checked: null,
    // (version|null) — a forced check's answer, null = current
    page: null,
    // (origin) — whose page this connection speaks for
    webPanel: null,
    // (visible) — is the on-page bar showing alongside us
    flash: null,
    // (msg, sel)
    badgeControls: (groups2) => [groups2.map(packBadgeGroup)],
    rows: (view, rows, empty) => [view, rows.map(packRow), empty],
    events: null,
    // (toolId, events[], isBacklog) — timeline entries, plain data;
    // a backlog REPLACES that tool's entries for this page visit
    bye: null
    // the page is unloading — expect a reconnect
  };
  var CMD = {
    toggle: null,
    // power
    tool: null,
    // (id) arm/disarm
    sweep: null,
    copy: null,
    clear: null,
    badgeControl: null,
    // (key)
    updateCheck: null,
    // (force)
    updateApply: null,
    webPanel: null,
    // (visible) — show/hide the on-page bar
    openView: null,
    // (view) — compute and push that view's rows
    rowActivate: null,
    // (view, i)
    rowRemove: null,
    // (view, i)
    rowChange: null,
    // (view, i, raw)
    hello: null
    // a side panel connected — push everything
  };
  function packRow(row) {
    const out = {};
    for (const k of [
      "title",
      "heading",
      "detail",
      "tag",
      "label",
      "accent",
      "inert",
      "removable",
      "rmTitle",
      "activatable",
      "control"
    ]) {
      if (row[k] !== void 0) out[k] = row[k];
    }
    if (row.pins) out.pinCount = row.pins.length;
    return out;
  }
  function packBadgeGroup(g) {
    return {
      key: g.key,
      glyph: g.glyph,
      title: g.title,
      rows: (g.rows || []).map((r) => ({
        key: r.key,
        glyph: r.glyph,
        title: r.title,
        label: r.label,
        armed: !!r.armed,
        fixed: !!r.fixed
      }))
    };
  }
  function envelope(kind, table, name, args) {
    if (!(name in table)) throw new Error(`unknown ${kind}: ${name}`);
    const pack2 = table[name];
    return {
      [FIELD2]: PROTOCOL_VERSION,
      kind,
      name,
      args: pack2 ? pack2(...args) : args
    };
  }
  var Protocol = {
    /** Build a state-push message. */
    state: (name, ...args) => envelope("state", STATE, name, args),
    /** Build a command message. */
    cmd: (name, ...args) => envelope("cmd", CMD, name, args),
    /**
     * Read a message from the wire. Returns { kind, name, args } for a
     * valid message of OUR protocol, and null for everything else —
     * the extension's worker traffic (debug-overlay-fetch and friends)
     * and any other extension's noise pass through untouched.
     */
    read(msg) {
      if (!msg || msg[FIELD2] !== PROTOCOL_VERSION) return null;
      const table = msg.kind === "state" ? STATE : msg.kind === "cmd" ? CMD : null;
      if (!table || !(msg.name in table) || !Array.isArray(msg.args)) return null;
      return { kind: msg.kind, name: msg.name, args: msg.args };
    },
    /** A different-version message of ours — worth telling the user
     *  "refresh this page" instead of silently ignoring. */
    stale: (msg) => !!msg && (LEGACY_FIELD in msg || typeof msg[FIELD2] === "number" && msg[FIELD2] !== PROTOCOL_VERSION)
  };

  // src/app/updates.js
  function newer(a, b) {
    const A = String(a).split(".").map(Number);
    const B = String(b).split(".").map(Number);
    for (let i = 0; i < Math.max(A.length, B.length); i++) {
      const d = (A[i] || 0) - (B[i] || 0);
      if (d) return d > 0;
    }
    return false;
  }
  function capable() {
    if (typeof chrome === "undefined" || !chrome.runtime?.id) return true;
    try {
      const m = chrome.runtime.getManifest();
      return !!(m.host_permissions && m.host_permissions.length);
    } catch {
      return true;
    }
  }
  function fetchText(url) {
    if (typeof chrome !== "undefined" && chrome.runtime?.id) {
      return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type: "debug-overlay-fetch", url }, (r) => {
          if (chrome.runtime.lastError || !r?.ok) reject(new Error(r?.error || "no worker"));
          else resolve(r.text);
        });
      });
    }
    return fetch(url, { cache: "no-store" }).then((r) => {
      if (!r.ok) throw new Error("http " + r.status);
      return r.text();
    });
  }
  var Updates = {
    latest: null,
    // a KNOWN newer version, or null
    applied: false,
    // the user pressed Update THIS page-session
    capable: capable(),
    // can this build reach the update host AT ALL
    async check(force) {
      if (!Updates.capable) return null;
      let saved = {};
      try {
        saved = JSON.parse(Store.get("__debug_overlay_upd") || "{}") || {};
      } catch {
      }
      if (!force && Date.now() - (saved.t || 0) < CONFIG.UPDATE.EVERY) {
        if (saved.v && newer(saved.v, CONFIG.VERSION)) Updates.found(saved.v);
        return Updates.latest;
      }
      try {
        const v = JSON.parse(await fetchText(CONFIG.VERSION_URL)).version;
        Store.set("__debug_overlay_upd", JSON.stringify({ t: Date.now(), v: v || null }));
        if (v && newer(v, CONFIG.VERSION)) Updates.found(v);
        else Updates.latest = null;
      } catch {
      }
      return Updates.latest;
    },
    found(v) {
      Updates.latest = v;
      WebPanel.setUpdate(v);
    },
    /** What pressing Update DOES, per gate. The extension's self-updater
     *  lives on its options page, and the worker opens it. Everywhere else
     *  there is no installer to hand off to, so it opens the instructions
     *  a person reads — never a bare download. */
    apply(x, y) {
      Updates.applied = true;
      if (typeof chrome !== "undefined" && chrome.runtime?.id) {
        try {
          chrome.runtime.sendMessage({ type: "debug-overlay-open-options" });
        } catch {
        }
      } else {
        window.open(`${CONFIG.REPO_URL}#install`, "_blank");
      }
      if (x != null) Updates.menu(x, y, true);
    },
    /** The ⏻ menu — the same cursor menu right-click already speaks.
     *  A manual check REOPENS the menu with its answer where the question
     *  was asked: "✓ current" was being flashed into the round ⏻ button,
     *  where a sentence cannot fit, and painted as smear. */
    menu(x, y, answered) {
      const rows = [];
      if (!Updates.capable) {
        rows.push({
          label: "This build cannot check for updates — see the ZIP page",
          run: () => {
          }
        });
        Menu.open(x, y, rows);
        return;
      }
      if (Updates.applied && Updates.latest) {
        rows.push({
          label: `↻ Refresh page — activate v${Updates.latest}`,
          run: () => location.reload()
        });
        rows.push({
          label: "Open the install page again",
          run: () => Updates.apply(x, y)
        });
      } else if (Updates.latest) {
        rows.push({ label: `Update to v${Updates.latest}`, run: () => Updates.apply(x, y) });
      } else if (answered) {
        rows.push({ label: `✓ current — v${CONFIG.VERSION}`, run: () => {
        } });
      }
      rows.push({
        label: answered ? "Check again" : "Check for updates now",
        run: async () => {
          await Updates.check(true);
          Updates.menu(x, y, true);
        }
      });
      Menu.open(x, y, rows);
    },
    schedule() {
      setTimeout(() => Updates.check(false), CONFIG.UPDATE.BOOT_DELAY);
    }
  };

  // src/app/bridge.js
  var port = null;
  var watching = null;
  var rowsTimer = 0;
  var last = /* @__PURE__ */ new Map();
  var toolLast = /* @__PURE__ */ new Map();
  function send(name, ...args) {
    if (!port) return;
    try {
      port.postMessage(Protocol.state(name, ...args));
    } catch {
      port = null;
      WebPanel.setVisible(true);
    }
  }
  function roster() {
    const one = (t) => ({
      id: t.id,
      icon: t.icon,
      title: t.title,
      // what it EXAMINES — its family, or the subject it owns alone. Declared
      // by the tool and required by the audit, so a new tool cannot arrive
      // with this blank the way it could when the side panel kept the list.
      fam: t.family || t.subject || null,
      roles: Tools.rolesOf(t)
    });
    return Tools.runs().map((run) => ({ name: run.name, tools: run.tools.map(one) }));
  }
  function backlogs() {
    for (const t of Tools.withHook("timeline", false)) {
      try {
        send("events", t.id, t.timeline.call(t) || [], true);
      } catch {
      }
    }
  }
  var wantsWebPanel = () => Store.get(CONFIG.WEBPANEL_KEY) === "1";
  function hello() {
    send("tools", roster(), CONFIG.VERSION);
    send("page", location.origin);
    send("webPanel", wantsWebPanel());
    for (const [id, v] of toolLast) send("tool", id, v);
    for (const [name, args] of last) send(name, ...args);
    backlogs();
  }
  function pushRows() {
    if (!watching) return;
    const q = WebPanel.onRowsFor?.(watching);
    if (q) send("rows", watching, q.rows, q.empty);
  }
  function queueRows() {
    if (!watching) return;
    clearTimeout(rowsTimer);
    rowsTimer = setTimeout(pushRows, 30);
  }
  function command({ name, args }) {
    switch (name) {
      case "hello":
        hello();
        break;
      case "toggle":
        WebPanel.onToggle?.();
        break;
      case "tool":
        WebPanel.onTool?.(args[0]);
        break;
      case "sweep":
        WebPanel.onSweep?.();
        break;
      case "copy":
        WebPanel.onCopy?.();
        break;
      case "clear":
        WebPanel.onClear?.();
        break;
      case "badgeControl":
        WebPanel.onBadgeControl?.(args[0]);
        break;
      /* the side panel's list: the view travels with every row command, so the
         index resolves against the list the SIDE PANEL rendered — never against
         whatever the in-page popover happens to show */
      case "openView":
        watching = args[0] || null;
        break;
      case "rowActivate":
        WebPanel.onRowActivate?.(args[1], args[0]);
        break;
      case "rowRemove":
        WebPanel.onRowRemove?.(args[1], args[0]);
        break;
      case "rowChange":
        WebPanel.onRowChange?.(args[1], args[2], args[0]);
        break;
      /* a found update announces itself through WebPanel.setUpdate as ever; the
         explicit 'checked' answer exists because "you are current" has no
         announcement, and a button that does nothing visible is worse than
         no button */
      case "updateCheck":
        Promise.resolve(Updates.check(true)).then((v) => send("checked", v || null));
        break;
      case "updateApply":
        Updates.apply();
        break;
      // per gate; no cursor, no menu
      /* SHOW BOTH, on purpose. Hiding the bar is the default because two
         controls claiming one state is a lie about which one is in charge —
         but a screenshot for an AI wants the bar IN the picture, and the side
         panel is not in the picture. So it is a choice, and it persists. */
      case "webPanel":
        Store.set(CONFIG.WEBPANEL_KEY, args[0] ? "1" : "0");
        WebPanel.setVisible(!!args[0]);
        send("webPanel", !!args[0]);
        break;
    }
    pushRows();
  }
  var Bridge = {
    /** Wired by boot as WebPanel.onState — cache everything, forward when live. */
    state(name, ...args) {
      if (name === "tool") toolLast.set(args[0], args[1]);
      else if (name !== "flash") last.set(name, args);
      send(name, ...args);
      if (name === "tool" && args[1]) setTimeout(backlogs, 0);
      queueRows();
    },
    /** Wired by boot as Controller.onToolEvent — a runtime's moment becomes a
     *  side panel timeline entry the instant it happens. */
    toolEvent(id, e) {
      send("events", id, [e], false);
    },
    init() {
      const runtime = typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onConnect ? chrome.runtime : null;
      if (!runtime) return;
      runtime.onConnect.addListener((p) => {
        if (p.name !== "debug-overlay-side-panel" && p.name !== "debug-overlay-cockpit") return;
        try {
          port?.disconnect();
        } catch {
        }
        port = p;
        watching = null;
        WebPanel.setVisible(wantsWebPanel());
        p.onMessage.addListener((msg) => {
          const m = Protocol.read(msg);
          if (m && m.kind === "cmd") command(m);
        });
        p.onDisconnect.addListener(() => {
          if (port !== p) return;
          port = null;
          watching = null;
          WebPanel.setVisible(true);
        });
      });
    }
  };

  // src/services/settings/index.js
  var Settings = {
    carried: {},
    // saved values whose owner this build does not know
    /**
     * ONE row builder, so the two doors into these settings cannot drift.
     * ⚙ shows every row grouped by what it changes; right-clicking a tool
     * shows that tool's subset. The second is a FILTER of the first, never a
     * copy — same options() call, same control, same value.
     */
    row(t, o) {
      return {
        tag: t.icon,
        label: o.label,
        control: Settings.controlFor(o, Tools.setting(t, o.key)),
        /* A tool's own option does nothing while that tool is disarmed —
           stored and waiting, not live. Hiding the row would be wrong, since
           the value applies the moment you arm it; looking active was the
           confusion, so it is dimmed. A SUBJECT has no armed state: its
           settings feed the sweep, which runs every rule either way. */
        inert: Tools.all.includes(t) && !State.tools.has(t.id),
        tool: t,
        opt: o
      };
    },
    /**
     * This one tool's rows — the per-tool door.
     *
     * INCLUDING the subjects it consults. "Grid step" is obviously grid's
     * setting to anyone using it; that it is owned by the `scale` subject so
     * the lens and the rule cannot disagree about it is an internal matter,
     * and right-clicking ▦ to be told "nothing to configure" was the panel
     * lying about the most configurable tool it has.
     *
     * The tool declares what it consults with `uses:`, which is a dependency
     * it already has — grid literally calls Scale.off(). A subject is not a
     * tool, so this is not one tool naming another.
     */
    rowsFor(id) {
      const t = Tools.byId(id);
      if (!t) return [];
      return Settings.rows(/* @__PURE__ */ new Set([t, ...t.uses || []]));
    },
    /**
     * One row per option, under a heading for what that option CHANGES.
     *
     * Grouped by category, not by owning tool. Ordered by filename, the list
     * read as one flat run of six unrelated knobs: how clicks pair up sat next
     * to a WCAG threshold sat next to what lands on the clipboard, and nothing
     * said they were different kinds of thing. The tool's icon still labels
     * every row, so which tool owns what is not lost — it is just no longer
     * the only structure on offer.
     *
     * An empty category prints no heading. A tool that adds the first ACT
     * option makes that section appear, and nothing here changes.
     */
    /**
     * `only`: restrict to a set of owners — that is the per-tool door. One
     * loop builds both views, THROUGH Settings.row (the inline duplicate that
     * used to live here is the drift the "one row builder" rule exists to
     * prevent), so grouping, headings and ORDER cannot differ between doors.
     * KEYS stays ⚙-only: gestures are nobody's options.
     */
    rows(only) {
      const out = [];
      for (const r of ROLES) {
        const rows = [];
        for (const t of Tools.settingOwners()) {
          if (only && !only.has(t)) continue;
          for (const o of t.options.call(t)) {
            if (o.affects !== r.key) continue;
            rows.push(Settings.row(t, o));
          }
        }
        if (!rows.length) continue;
        out.push({ heading: r.label, detail: r.note });
        out.push(...rows);
      }
      const keys = only ? [] : Settings.gestureRows();
      if (keys.length) {
        out.push({ heading: "Keys", detail: "the parts of this that are not buttons" });
        out.push(...keys);
      }
      const legend8 = only ? [] : Settings.legendRows();
      if (legend8.length) {
        out.push({ heading: "Legend", detail: "what the marks and short names mean" });
        out.push(...legend8);
      }
      return out;
    },
    /**
     * WHAT THE BADGE IS SAYING. `p 4 8`, `r 13`, `12/16 400`, an amber ⚠, a
     * red ratio — the whole diagnosis is abbreviations and colour, and none of
     * it was written down anywhere in the running overlay. A first reader had
     * to guess or read the source.
     *
     * Collected through a hook for the same reason `gestures` is: each tool
     * declares the vocabulary it invented, beside the code that prints it, so
     * no core file holds a table of another tool's colours — and a tool
     * shipped tomorrow documents itself with nothing installed here.
     */
    legendRows() {
      const rows = [];
      for (const t of Tools.withHook("legend"))
        for (const g of t.legend.call(t) || []) rows.push([g.mark, g.means]);
      return rows.map(([mark, means]) => ({ tag: mark, label: means, detail: "" }));
    },
    /**
     * THE GESTURES. Three of them — Alt+click, the remove key, Escape — existed
     * nowhere in the running UI at all: a user who had not read the source
     * could not find them, which for Alt+click meant the pass-through everyone
     * asks for looked like a missing feature.
     *
     * Key NAMES come from CONFIG so they cannot drift from what is bound, and a
     * tool that claims a gesture of its own declares it, so nothing central has
     * to keep a list of what the tools do.
     */
    gestureRows() {
      const H = CONFIG.HOTKEY;
      const hot = [
        H.ctrl && "Ctrl",
        H.alt && "Alt",
        H.shift && "Shift",
        H.code.replace("Key", "")
      ].filter(Boolean).join("+");
      const rows = [
        ["Click", "select an element — 📌 armed, it is kept as a pin"],
        ["Shift+click", "pair it with your next Shift+click"],
        ["Right-click a target", "its menu — copy its selector or text"],
        ["Ctrl/⌘+C", "copy the hovered target's selector"],
        ["Alt+click", "let the click through to the page"],
        ["Alt+right-click", "the page's own context menu"],
        [`Hold ${CONFIG.REMOVE_KEY.replace("Key", "")}`, "show ✕ on every pin"],
        ["Esc", "close the panel, then the pins"],
        ["Right-click a tool", "its own options, without the others"],
        ["Right-click ⏻", "updates — check now, or install the one waiting"],
        [hot, "power on and off"]
      ];
      for (const t of Tools.withHook("gestures"))
        for (const g of t.gestures.call(t) || []) rows.push([g.keys, g.does]);
      return rows.map(([keys, does]) => ({ tag: keys, label: does, detail: "" }));
    },
    /**
     * How one option wants drawing. An option with `values` is a choice; the
     * two typed kinds are for the settings a list cannot express — a threshold
     * somebody has to type, a thing that is simply on or off.
     */
    controlFor(o, cur) {
      if (o.type === "number") {
        return {
          kind: "number",
          value: String(cur),
          suffix: o.suffix || "",
          min: o.min,
          max: o.max,
          step: o.step
        };
      }
      if (o.type === "toggle") return { kind: "toggle", on: !!cur };
      const values = o.values.includes(cur) ? o.values : [cur, ...o.values];
      return {
        kind: "choice",
        values,
        choices: values.map((v) => `${v}${o.suffix || ""}`),
        selected: values.indexOf(cur)
      };
    },
    /** Is `v` something this option could actually be set to? */
    valid(o, v) {
      if (v === void 0 || v === null) return false;
      if (o.type === "number") {
        return typeof v === "number" && Number.isFinite(v) && v >= (o.min ?? -Infinity) && v <= (o.max ?? Infinity);
      }
      if (o.type === "toggle") return typeof v === "boolean";
      return o.values.includes(v);
    },
    /**
     * Whatever the panel's widget produced, turned back into the option's own
     * value. Returns null for anything that is not a legal setting — a number
     * field accepts empty and "e", and neither may reach a rule.
     */
    fromControl(row, raw) {
      const o = row.opt;
      if (o.type === "number") {
        const n = Number(raw);
        if (raw === "" || !Number.isFinite(n)) return null;
        return Math.min(o.max ?? Infinity, Math.max(o.min ?? -Infinity, n));
      }
      if (o.type === "toggle") return !!raw;
      const v = row.control.values[raw];
      return v === void 0 ? null : v;
    },
    /** Write one option through, and persist the lot. */
    apply(row, v) {
      var _a, _b;
      ((_a = State.settings)[_b = row.tool.id] || (_a[_b] = {}))[row.opt.key] = v;
      Store.set(CONFIG.SETTINGS_KEY, JSON.stringify({ ...Settings.carried, ...State.settings }));
    },
    /**
     * Every option's default comes from the tool, and a saved value only
     * overrides it if the tool still offers it. Resolved once, here, so that
     * Tools.setting() stays a lookup: grid asks for its step once per number
     * on a page that has thousands of them.
     */
    load() {
      let saved = {};
      try {
        saved = JSON.parse(Store.get(CONFIG.SETTINGS_KEY) || "{}") || {};
      } catch {
      }
      const out = {};
      for (const t of Tools.settingOwners()) {
        const prev = saved[t.id] || t.was && saved[t.was] || null;
        out[t.id] = {};
        for (const o of t.options.call(t)) {
          const was = prev?.[o.key];
          out[t.id][o.key] = Settings.valid(o, was) ? was : o.def;
        }
      }
      Settings.carried = {};
      for (const id of Object.keys(saved)) if (!(id in out)) Settings.carried[id] = saved[id];
      State.settings = out;
    }
  };

  // src/app/controller.js
  var Controller = {
    /**
     * The RUNTIME lifecycle — the first hook pair with a tense. Every hook
     * before this was called at a moment (a click, a frame, a sweep); a
     * MONITOR is on duty for a span of time, so something has to say when
     * the span starts and ends. watch() when a tool becomes active (armed
     * AND powered), unwatch() when it stops being either — asked by hook,
     * no tool named, so the next monitor ships without touching this file.
     */
    _running: /* @__PURE__ */ new Set(),
    /* Announce-and-let-boot-decide, for tool events: syncRuntimes hands each
       runtime an `event` capability that lands here. Today the side panel
       bridge listens; nothing here knows that. */
    onToolEvent: null,
    syncRuntimes() {
      for (const t of Tools.withHook("watch", false)) {
        const should = State.enabled && State.tools.has(t.id);
        const is = Controller._running.has(t);
        if (should && !is) {
          Controller._running.add(t);
          t.watch.call(t, {
            redraw: Render.schedule,
            event: (e) => Controller.onToolEvent?.(t.id, e),
            /* KEEPING is core's, and a tool that selects many
               at once has no other way to say so: it may not
               import app/, and togglePin is one element at a
               time through the input layer. Handed in like
               redraw, so the capability travels and the id
               does not. */
            pin: Controller.pinMany
          });
        } else if (!should && is) {
          Controller._running.delete(t);
          t.unwatch?.call(t);
        }
      }
    },
    setPower(v) {
      State.enabled = v;
      Store.set(`${CONFIG.POWER_KEY}:${location.origin}`, v ? "1" : "0");
      if (!v) Menu.close();
      if (!v) State.hoverEl = null;
      if (v) {
        try {
          getSelection()?.removeAllRanges();
        } catch {
        }
      }
      if (!v) State.sweep = null;
      WebPanel.setSwept(!!State.sweep, 0);
      WebPanel.setOn(v);
      Controller.syncRuntimes();
      Render.schedule();
    },
    togglePower() {
      Controller.setPower(!State.enabled);
    },
    /**
     * Audit the whole page rather than the elements under the cursor. The
     * result is kept so the report and any findings surface read the same
     * pass — sweeping again per reader would give two different answers on a
     * page that moved in between.
     */
    sweep() {
      if (!State.enabled || Controller._sweeping) return Promise.resolve(null);
      Controller._sweeping = true;
      const r = Sweep.run();
      if (r && typeof r.then === "function") return r.then(Controller._swept, Controller._swept);
      return Promise.resolve(Controller._swept(r));
    },
    /** The half that runs once the pass has actually finished. */
    _swept(result) {
      Controller._sweeping = false;
      if (!State.enabled || !result || !result.findings) return null;
      State.sweep = result;
      WebPanel.setSwept(true, Sweep.group(State.sweep.findings).length);
      WebPanel.toggleList(true, "findings");
      Render.schedule();
      return result;
    },
    /** Rows for whichever view the panel is showing. */
    rows(view) {
      const body = view === "settings" ? Settings.rows() : Controller.toolOf(view) ? Settings.rowsFor(Controller.toolOf(view)) : view === "findings" ? Controller.findingRows() : Controller.pinList();
      if (!body.length) return body;
      for (const r of body) if (r.pins || r.el) r.activatable = true;
      const t = Controller.viewTitle(view, body);
      return t ? [t, ...body] : body;
    },
    /**
     * One popover shows three unrelated screens with no header, so nothing on
     * screen said what you were looking at — or that opening one destroyed the
     * last. It also labels the two numbers an audit produces: the ⌕ flash
     * counts distinct problems and the report counts occurrences, and neither
     * said which it was.
     */
    /** The tool a `tool:<id>` view names, or null. No id is written here — it
     *  arrives from the button that was clicked. */
    toolOf: (view) => String(view || "").startsWith("tool:") ? view.slice(5) : null,
    viewTitle(view, body) {
      const owned = Controller.toolOf(view);
      if (owned) {
        const t = Tools.byId(owned);
        return t && {
          title: (t.family ? t.family[0].toUpperCase() + t.family.slice(1) + " › " : "") + t.title.split(/[—·]/)[0].trim(),
          detail: "its own options — ⚙ has these and everyone else's"
        };
      }
      if (view === "settings") return { title: "Settings", detail: "what each tool checks and shows" };
      if (view === "pins") {
        const n = State.pins.length;
        return {
          title: "Pins",
          detail: `${n} pinned element${n === 1 ? "" : "s"}` + (Controller._lost ? ` · ${Controller._lost} did not survive the reload` : ""),
          removable: n > 0,
          rmTitle: "Clear all pins — the audit's marks stay",
          pins: State.pins.slice()
        };
      }
      const s = State.sweep;
      if (!s) return { title: "Findings", detail: "no audit has run" };
      const groups2 = body.filter((r) => !r.heading && !r.title).length;
      return {
        title: "Findings",
        detail: `${groups2} distinct problem${groups2 === 1 ? "" : "s"} · ${s.findings.length} occurrence${s.findings.length === 1 ? "" : "s"}`
      };
    },
    /**
     * A row changed. Which row depends on the view showing, so this asks for
     * that view's rows — indexing settings by a number that came from the pin
     * list would write the wrong setting entirely.
     */
    /* The `view` parameter on the three row handlers: the in-page list never
       passes it (the popover's own view is the default, as ever), but the
       side panel's rows live in another window and name their view explicitly —
       resolving its index against whatever the POPOVER happens to show would
       be the off-by-a-list bug with extra steps. */
    changeRow(i, raw, view = WebPanel.view()) {
      const row = Controller.rows(view)[i];
      if (!row) return;
      if (row.onChange) {
        row.onChange(raw);
        Render.schedule();
        Controller.refreshList();
        return;
      }
      if (!row.opt) return;
      const v = Settings.fromControl(row, raw);
      if (v === null) {
        Controller.refreshList();
        return;
      }
      Settings.apply(row, v);
      if (row.opt.affects === "detect") {
        State.sweep = null;
        WebPanel.setSwept(false, 0);
      }
      Render.schedule();
      Controller.refreshList();
    },
    /** One row per distinct problem, worst first. No pin, so nothing to remove. */
    findingRows() {
      const rows = Sweep.group(State.sweep ? State.sweep.findings : []).map((g) => ({
        tag: (g.verdict === "review" ? "review" : g.severity) + (g.n > 1 ? ` ×${g.n}` : ""),
        label: g.message,
        // the leaf, not the whole path: a row has to be scannable, and the
        // full ancestor chain is in the copied report where there is room
        detail: U.selectorOf(g.el).split(" > ").pop(),
        accent: g.verdict === "review" ? "review" : g.severity,
        el: g.el
      }));
      const capped = State.sweep ? Tools.withHook("draw", true).map((t) => (State.sweep.byTool[t.id] || []).length).filter((n) => n > CONFIG.MARK_LIMIT) : [];
      if (capped.length) {
        rows.unshift({
          heading: `${Math.max(...capped)} found by one rule`,
          detail: `the page marks the first ${CONFIG.MARK_LIMIT} findings of each — this list is complete`
        });
      }
      return rows;
    },
    /**
     * Three different silences, and they must not share a sentence. Nobody has
     * asked yet; nothing could ask, because no rule exists; or every rule ran
     * and had nothing to say. Only the third is good news.
     */
    emptyFor(view) {
      if (Controller.toolOf(view)) return "This one has nothing to configure.";
      if (view === "settings") return "No tool has anything to configure.";
      if (view !== "findings") {
        const keeper = Tools.withHook("keeps", false)[0];
        if (keeper && !Tools.withHook("keeps", true).length)
          return `Nothing keeps selections — clicks choose one element at a time. Arm ${keeper.title.split(/[—·]/)[0].trim()} to keep them as pins.`;
        return "No pins yet — click to inspect, Shift+click to measure.";
      }
      const s = State.sweep;
      if (!s) return "Press ⌕ to audit the page.";
      if (!s.rules) return "No rules are installed, so nothing was checked.";
      return `No findings — ${s.rules} rule${s.rules === 1 ? "" : "s"} over ${s.elements} elements.` + Sweep.unchecked(s).replace("\n   ", " ");
    },
    toggleTool(id) {
      if (!Tools.byId(id)) return;
      State.tools.has(id) ? State.tools.delete(id) : State.tools.add(id);
      WebPanel.setTool(id, State.tools.has(id));
      Store.set(CONFIG.TOOLS_KEY, JSON.stringify([...State.tools]));
      Controller.syncRuntimes();
      Render.schedule();
      Controller.refreshList();
    },
    /**
     * Which tools are armed. A saved set wins; failing that, each tool decides
     * for itself with `startsOn`. Ids only ever come from the registry or from
     * something the registry already vouched for, so no core file spells one.
     */
    loadTools() {
      const registered = TOOLS.map((t) => t.id);
      let ids = TOOLS.filter((t) => t.startsOn).map((t) => t.id);
      let seen = null;
      try {
        const s = JSON.parse(Store.get(CONFIG.SEEN_KEY) || "null");
        if (Array.isArray(s)) seen = s;
      } catch {
      }
      try {
        const saved = JSON.parse(Store.get(CONFIG.TOOLS_KEY) || "null");
        if (Array.isArray(saved)) {
          const known = seen || registered;
          ids = saved.filter((id) => Tools.byId(id));
          for (const t of TOOLS) if (t.startsOn && !known.includes(t.id)) ids.push(t.id);
        }
      } catch {
      }
      Store.set(CONFIG.SEEN_KEY, JSON.stringify([...registered].sort()));
      State.tools = new Set(ids.filter((id) => Tools.byId(id)));
      TOOLS.forEach((t) => WebPanel.setTool(t.id, State.tools.has(t.id)));
      WebPanel.attachCount(Tools.withHook("keeps", false)[0]?.id ?? null);
      Controller.syncRuntimes();
    },
    /**
     * Every path that adds or removes a pin ends here.
     *
     * A pin's NUMBER is stable while it exists: removing #2 must not renumber
     * #3, or a screenshot taken a moment earlier stops matching the report
     * beside it. But once nothing is pinned there is no numbering left to be
     * stable about, and the counter kept climbing — pin, unpin, pin and you
     * were looking at "#9" beside a count chip reading 1, a number that
     * referred to nothing and could not be read off a screenshot.
     */
    pinsChanged() {
      if (State.pins.length) WebPanel.taught?.();
      Controller.persistPins();
      Render.schedule();
      Controller.refreshList();
    },
    /**
     * THE SESSION SURVIVES THE REFRESH — by address, honestly. A pin holds a
     * live element and the reload destroys the document, so what persists is
     * each pin's SELECTOR, re-resolved against the new page at boot. Keyed by
     * origin+path: a pin on /live-map is not a pin on /settings. A selector
     * that no longer matches is DROPPED and the Pins header says how many —
     * an element that is gone is gone, and a silent loss is how ✕ deleted
     * the wrong pin once. The honest limit, stated: a selector is an address,
     * and on a changed page it can name a different element.
     */
    _pinsKey: () => `${CONFIG.PINS_KEY}:${location.origin}${location.pathname}`,
    _lost: 0,
    persistPins() {
      Controller._lost = 0;
      const cur = State.current && document.contains(State.current) ? U.selectorOf(State.current) : null;
      const pins = State.pins.filter((p) => document.contains(p.el)).map((p) => ({ s: U.selectorOf(p.el), id: p.id, kind: p.kind }));
      Store.set(
        Controller._pinsKey(),
        pins.length || cur ? JSON.stringify({ pins, cur }) : ""
      );
    },
    restorePins() {
      let saved = null;
      try {
        saved = JSON.parse(Store.get(Controller._pinsKey()) || "null");
      } catch {
      }
      if (!saved) return;
      const seen = /* @__PURE__ */ new Set();
      for (const p of saved.pins || []) {
        let el2 = null;
        try {
          el2 = document.querySelector(p.s);
        } catch {
        }
        if (!el2 || seen.has(el2)) {
          Controller._lost++;
          continue;
        }
        seen.add(el2);
        State.pins.push({ el: el2, id: p.id, kind: p.kind });
      }
      if (saved.cur) {
        try {
          const el2 = document.querySelector(saved.cur);
          if (el2 && !seen.has(el2)) State.current = el2;
        } catch {
        }
      }
      Render.schedule();
      Controller.refreshList();
    },
    /**
     * The number a new pin gets: the SMALLEST one not currently in use.
     *
     * It was a counter that only climbed, so four pins on the page could read
     * #1 #2 #6 #9 — numbers with no relation to what you were looking at, on a
     * tool whose point is reading values off a screenshot. Resetting it when
     * the list emptied fixed only the trivial case; unpin and re-pin with
     * anything else still pinned and it kept going.
     *
     * Derived from the live pins rather than stored, so there is no counter
     * left to drift. Existing pins keep their numbers — renumbering #3 to #2
     * because #1 went away would break the screenshot you took a second ago —
     * and the gap that leaves is exactly what the next pin fills.
     */
    nextPinId() {
      const taken = new Set(State.pins.map((p) => p.id));
      let n = 1;
      while (taken.has(n)) n++;
      return n;
    },
    /** The renderer dropped pins whose element left the page; it is mid-frame,
     *  so this must not ask for another one. */
    pinsPruned() {
      Controller.refreshList();
    },
    // kind: CONFIG.PIN_KIND.PLAIN → a note: inspect only, groups with nothing
    //       CONFIG.PIN_KIND.SHIFT → a pair pin: joins whatever grouping is armed
    togglePin(el2, kind = CONFIG.PIN_KIND.PLAIN) {
      State.current = null;
      const i = State.pins.findIndex((p) => p.el === el2);
      if (i >= 0) {
        if (State.pins[i].kind === kind) State.pins.splice(i, 1);
        else State.pins[i].kind = kind;
      } else {
        State.pins.push({ el: el2, id: Controller.nextPinId(), kind });
      }
      Controller.pinsChanged();
    },
    /**
     * KEEP SEVERAL AT ONCE — one change, one announcement.
     *
     * Pinning in a loop would fire pinsChanged (a persist, a render and a list
     * rebuild) once per element, which for a lasso over forty of them is
     * forty of each. Elements already pinned are left exactly as they are:
     * a selection that swept over something twice must not unpin it, which is
     * what togglePin would do.
     */
    pinMany(els, kind = CONFIG.PIN_KIND.PLAIN) {
      let added = 0;
      for (const el2 of els) {
        if (!el2 || !document.contains(el2)) continue;
        if (State.pins.some((p) => p.el === el2)) continue;
        State.pins.push({ el: el2, id: Controller.nextPinId(), kind });
        added++;
      }
      if (!added) return 0;
      State.current = null;
      Controller.pinsChanged();
      return added;
    },
    /**
     * SELECTION chooses; PIN keeps. This is the choosing half on its own:
     * with no armed keeper, a click selects ONE element — outline and badge,
     * no number — and the next click lets it go and selects the next thing.
     * Clicking the selected element again deselects it. The page never
     * accumulates anything; only an armed keeper turns choices into pins.
     */
    setCurrent(el2) {
      State.current = State.current === el2 ? null : el2;
      Render.schedule();
    },
    setRemoveMode(v) {
      State.removeMode = v;
      if (!v) State.removeTarget = null;
      if (v) State.hoverEl = null;
      WebPanel.setRemoveMode(v);
      Render.schedule();
    },
    removePin(pin) {
      const i = State.pins.indexOf(pin);
      if (i >= 0) State.pins.splice(i, 1);
      State.removeTarget = null;
      Controller.pinsChanged();
    },
    /**
     * The panel's pin list. Active tools claim the pins they own (measure
     * claims its pairs); whatever is left over gets a plain row. The panel
     * itself never learns what a "pair" is.
     */
    pinList() {
      const rows = [];
      const claimed = /* @__PURE__ */ new Set();
      for (const t of Tools.active()) {
        for (const row of t.listRows?.call(t) || []) {
          row.pins?.forEach((p) => claimed.add(p));
          rows.push(row);
        }
      }
      for (const p of State.pins) {
        if (claimed.has(p)) continue;
        if (!document.contains(p.el)) continue;
        const r = p.el.getBoundingClientRect();
        rows.push({
          tag: `#${p.id}`,
          label: U.labelOf(p.el),
          detail: `${Math.round(r.width)}×${Math.round(r.height)}`,
          pins: [p]
        });
      }
      const first = (row) => row.pins?.length ? Math.min(...row.pins.map((p) => p.id)) : Infinity;
      rows.forEach((r) => {
        if (r.pins?.length) r.removable = true;
      });
      return rows.sort((a, b) => first(a) - first(b));
    },
    refreshList() {
      if (!WebPanel.isListOpen()) return;
      const view = WebPanel.view();
      WebPanel.setList(Controller.rows(view), Controller.emptyFor(view));
    },
    revealRow(i, view = WebPanel.view()) {
      const row = Controller.rows(view)[i];
      if (!row) return;
      let pins = row.pins;
      if (!pins || !pins.length) {
        if (!row.el || !document.contains(row.el)) return;
        const had = State.pins.find((p) => p.el === row.el);
        if (!had) Controller.togglePin(row.el, CONFIG.PIN_KIND.PLAIN);
        pins = [State.pins.find((p) => p.el === row.el)];
      }
      const el2 = pins[0].el;
      el2.scrollIntoView({ block: "center", inline: "center", behavior: "smooth" });
      State.flashPins = pins;
      Render.schedule();
      clearTimeout(Controller._flash);
      Controller._flash = setTimeout(() => {
        State.flashPins = null;
        Render.schedule();
      }, 900);
    },
    removeRow(i, view = WebPanel.view()) {
      const row = Controller.rows(view)[i];
      if (!row || !row.pins) return;
      row.pins.forEach((p) => {
        const k = State.pins.indexOf(p);
        if (k >= 0) State.pins.splice(k, 1);
      });
      Controller.pinsChanged();
    },
    /**
     * Clears everything the overlay has put ON the page — pins and the audit's
     * outlines. It used to clear pins only, so an audit's 200 outlines had no
     * exit at all: the ⌕ flash expired, the bar looked idle, and the page
     * stayed covered with no control that admitted it.
     */
    clearPins() {
      State.pins = [];
      State.current = null;
      State.sweep = null;
      WebPanel.setSwept(false, 0);
      Controller.pinsChanged();
    },
    /**
     * The 🏷 flyout's axes and members come from the face itself (it derives
     * them from its own options(), one declaration for flyout and ⚙ alike);
     * this is only the hand-over. Writes still go through Settings.apply —
     * the same store the ⚙ row writes — so the two surfaces re-read one
     * value and can never disagree.
     */
    refreshBadge() {
      WebPanel.setBadgeControls(BadgeFace.groups());
    },
    badgeControl(key) {
      const [k, v] = key.split(":");
      const opt = BadgeFace.options().find((o) => o.key === k);
      if (!opt) return;
      const next = opt.values ? v : !Tools.setting(BadgeFace, k);
      Settings.apply({ tool: BadgeFace, opt }, next);
      Controller.refreshBadge();
      Controller.refreshList();
      Render.schedule();
    }
  };

  // src/app/remote.js
  function pack(p) {
    return {
      id: p.id,
      kind: p.kind,
      selector: U.selectorOf(p.el),
      label: U.labelOf(p.el),
      rect: rectOf(p.el)
    };
  }
  function rectOf(el2) {
    const r = el2.getBoundingClientRect();
    return {
      x: Math.round(r.left),
      y: Math.round(r.top),
      w: Math.round(r.width),
      h: Math.round(r.height)
    };
  }
  function under(x, y) {
    const el2 = document.elementFromPoint(x, y);
    if (!el2) throw new Error(`nothing at (${x}, ${y}) — outside the viewport?`);
    return el2;
  }
  function pointer(type, x, y, mods = {}) {
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      clientX: x,
      clientY: y,
      button: 0,
      buttons: type.endsWith("up") ? 0 : 1,
      shiftKey: !!mods.shift,
      ctrlKey: !!mods.ctrl,
      metaKey: !!mods.meta,
      altKey: !!mods.alt
    };
    const P = typeof PointerEvent === "function" ? PointerEvent : null;
    return P && type.startsWith("pointer") ? new P(type, { ...init, pointerId: 1, pointerType: "mouse", isPrimary: true }) : new MouseEvent(type, init);
  }
  function select(sel) {
    let el2 = null;
    try {
      el2 = document.querySelector(sel);
    } catch {
      throw new Error(`not a CSS selector: ${sel}`);
    }
    if (!el2) throw new Error(`nothing matches ${sel}`);
    return el2;
  }
  function findings() {
    const s = State.sweep;
    const groups2 = Sweep.group(s ? s.findings : []);
    return {
      swept: !!s,
      problems: groups2.length,
      occurrences: s ? s.findings.length : 0,
      elements: s ? s.elements : 0,
      findings: groups2.map((g) => ({
        rule: g.rule,
        severity: g.severity,
        verdict: g.verdict || "fail",
        message: g.message,
        count: g.n,
        selector: U.selectorOf(g.el),
        rect: rectOf(g.el)
      }))
    };
  }
  var commands = {
    /** What a person sees on the bar and under ⚙, as data. Call it first:
     *  the ids here are what `arm` and `set` take. */
    state() {
      return {
        version: CONFIG.VERSION,
        url: location.href,
        title: document.title,
        on: State.enabled,
        viewport: {
          w: innerWidth,
          h: innerHeight,
          dpr: devicePixelRatio,
          scrollX: Math.round(scrollX),
          scrollY: Math.round(scrollY)
        },
        tools: Tools.runs().flatMap((run) => run.tools.map((t) => ({
          id: t.id,
          title: t.title,
          armed: State.tools.has(t.id),
          roles: Tools.rolesOf(t),
          family: t.family || t.subject || null,
          band: run.name
        }))),
        settings: Settings.rows().filter((r) => r.opt).map((r) => ({
          owner: r.tool.id,
          key: r.opt.key,
          label: r.opt.label,
          affects: r.opt.affects,
          value: Tools.setting(r.tool, r.opt.key),
          ...r.opt.type === "number" ? { type: "number", min: r.opt.min, max: r.opt.max, step: r.opt.step } : r.opt.type === "toggle" ? { type: "toggle" } : { values: r.opt.values }
        })),
        pins: State.pins.length,
        swept: !!State.sweep
      };
    },
    power([on]) {
      if (!!on !== State.enabled) WebPanel.onToggle?.();
      return { on: State.enabled };
    },
    /** Arm or disarm by id — through the bar's own slot, so a runtime starts
     *  and stops exactly as it does from a button. */
    arm([id, on]) {
      if (!Tools.byId(id)) {
        throw new Error(`no tool '${id}' — the ids are: ${Tools.all.map((t) => t.id).join(", ")}`);
      }
      const want = on == null ? !State.tools.has(id) : !!on;
      if (want !== State.tools.has(id)) WebPanel.onTool?.(id);
      return { id, armed: State.tools.has(id) };
    },
    /** One setting, by owner and key, through the same row the ⚙ view edits —
     *  so the affects-driven sweep invalidation and the redraw happen exactly
     *  as they do for a person. The index resolves against rows('settings'),
     *  the standing rule for every row callback. */
    set([owner, key, value]) {
      const rows = Controller.rows("settings");
      const i = rows.findIndex((r) => r.opt && r.tool.id === owner && r.opt.key === key);
      if (i < 0) throw new Error(`no setting ${owner}.${key} — state lists them`);
      const row = rows[i];
      let raw;
      if (row.opt.type === "number") {
        if (!Settings.valid(row.opt, value)) {
          throw new Error(`${owner}.${key} takes a number` + (row.opt.min != null || row.opt.max != null ? ` from ${row.opt.min ?? "-∞"} to ${row.opt.max ?? "∞"}` : ""));
        }
        raw = value;
      } else if (row.opt.type === "toggle") {
        raw = !!value;
      } else {
        raw = row.control.values.indexOf(value);
        if (raw < 0) throw new Error(`${owner}.${key} takes one of: ${row.opt.values.join(", ")}`);
      }
      Controller.changeRow(i, raw, "settings");
      return { owner, key, value: Tools.setting(row.tool, key) };
    },
    /** Pin by selector. Reaches what a click cannot, the way the lasso does:
     *  it asks the DOM, not the hit test. */
    pin([selector]) {
      const el2 = select(selector);
      Controller.pinMany([el2]);
      const p = State.pins.find((x) => x.el === el2);
      return p ? pack(p) : null;
    },
    unpin([which]) {
      const p = typeof which === "number" ? State.pins.find((x) => x.id === which) : State.pins.find((x) => x.el === select(which));
      if (!p) throw new Error(`no pin ${which}`);
      Controller.removePin(p);
      return { removed: p.id, pins: State.pins.length };
    },
    pins() {
      return State.pins.filter((p) => document.contains(p.el)).map(pack);
    },
    /** A click, as a hand makes one — so whatever is armed answers, and a
     *  modifier means what it means at the keyboard. */
    click([x, y, mods]) {
      const el2 = under(x, y);
      for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
        el2.dispatchEvent(pointer(type, x, y, mods));
      }
      return {
        at: [x, y],
        target: U.selectorOf(el2),
        pins: State.pins.length,
        current: State.current ? U.selectorOf(State.current) : null
      };
    },
    /** Press, drag, release. The browser sends a click after any press, so
     *  this does too — the runtime that owns the drag is the one that claims
     *  it, exactly as it would after a hand let go. */
    drag([x1, y1, x2, y2]) {
      const from = under(x1, y1);
      from.dispatchEvent(pointer("pointerdown", x1, y1));
      const to = under(x2, y2);
      to.dispatchEvent(pointer("pointermove", x2, y2));
      to.dispatchEvent(pointer("pointerup", x2, y2));
      to.dispatchEvent(pointer("click", x2, y2));
      return { from: [x1, y1], to: [x2, y2], pins: State.pins.length };
    },
    /** Move the pointer without pressing. The hover badge follows, and so
     *  does any runtime that watches the pointer — paint's probe, for one. */
    point([x, y]) {
      const el2 = under(x, y);
      el2.dispatchEvent(pointer("pointermove", x, y));
      el2.dispatchEvent(pointer("mousemove", x, y));
      return { at: [x, y], target: U.selectorOf(el2) };
    },
    /** ⌕, awaited. The sweep may yield on a large page; the answer is the
     *  grouped findings once it has actually finished. */
    audit() {
      if (!State.enabled) throw new Error("powered off — call power(true) first");
      if (Controller._sweeping) throw new Error("a sweep is already running");
      return Controller.sweep().then(findings);
    },
    findings() {
      return findings();
    },
    /** The report ⧉ copies — prepared, so a tool that fetches first gets to,
     *  and never on the clipboard. */
    report() {
      return Report.build();
    },
    clear() {
      WebPanel.onClear?.();
      return { pins: State.pins.length };
    }
  };
  function answer(fn, args, respond) {
    let r;
    try {
      r = fn(Array.isArray(args) ? args : []);
    } catch (e) {
      respond({ ok: false, error: String(e && e.message || e) });
      return false;
    }
    if (r && typeof r.then === "function") {
      r.then(
        (v) => respond({ ok: true, result: v ?? null }),
        (e) => respond({ ok: false, error: String(e && e.message || e) })
      );
      return true;
    }
    respond({ ok: true, result: r ?? null });
    return false;
  }
  var Remote = {
    /** The vocabulary, for anything that wants to say what it can do. */
    commands: () => Object.keys(commands),
    init() {
      const runtime = typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage ? chrome.runtime : null;
      if (!runtime) return;
      runtime.onMessage.addListener((msg, sender, respond) => {
        if (!msg || msg.type !== "debug-overlay-remote") return;
        if (sender && sender.id && runtime.id && sender.id !== runtime.id) return;
        const fn = commands[msg.cmd];
        if (!fn) {
          respond({ ok: false, error: `unknown command '${msg.cmd}' — one of: ${Object.keys(commands).join(", ")}` });
          return;
        }
        return answer(fn, msg.args, respond);
      });
    }
  };

  // src/boot.js
  function start() {
    initDom();
    initList();
    initMenu();
    initWebPanel();
    WebPanel.onToggle = Controller.togglePower;
    WebPanel.onTool = Controller.toggleTool;
    WebPanel.onBadgeControl = Controller.badgeControl;
    WebPanel.onUpdateMenu = Updates.menu;
    WebPanel.onCopy = Report.copy;
    WebPanel.onSweep = Controller.sweep;
    WebPanel.onClear = Controller.clearPins;
    WebPanel.onListOpen = (view) => WebPanel.setList(Controller.rows(view), Controller.emptyFor(view));
    WebPanel.onRowActivate = Controller.revealRow;
    WebPanel.onRowRemove = Controller.removeRow;
    WebPanel.onRowChange = Controller.changeRow;
    WebPanel.onRowsFor = (view) => ({ rows: Controller.rows(view), empty: Controller.emptyFor(view) });
    Render.onPinsPruned = Controller.pinsPruned;
    WebPanel.onState = Bridge.state;
    Controller.onToolEvent = Bridge.toolEvent;
    Bridge.init();
    Remote.init();
    Settings.load();
    Controller.refreshBadge();
    Controller.loadTools();
    Interactions.install(Controller);
    Controller.restorePins();
    Controller.setPower(Store.get(`${CONFIG.POWER_KEY}:${location.origin}`) === "1");
    Updates.schedule();
  }
  var deferred = Store.init();
  if (deferred) deferred.then(start);
  else start();
})();
})();
